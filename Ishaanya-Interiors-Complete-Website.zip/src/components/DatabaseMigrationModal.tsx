// @ts-nocheck
import React, { useState, useEffect } from 'react';
import { 
  checkDedicatedTablesAvailability, 
  migrateLegacyToDedicatedTables, 
  BUSINESS_MODULES_SQL_SCHEMA 
} from '../lib/business-records';
import { recordAuditLog } from '../lib/audit-logs';

interface DatabaseMigrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  supabase: any;
  currentActorEmail?: string;
  onMigrationSuccess?: () => void;
}

export const DatabaseMigrationModal: React.FC<DatabaseMigrationModalProps> = ({
  isOpen,
  onClose,
  supabase,
  currentActorEmail = 'himanshukanswal323@gmail.com',
  onMigrationSuccess,
}) => {
  const [checking, setChecking] = useState(false);
  const [tablesStatus, setTablesStatus] = useState<Record<string, boolean>>({});
  const [allReady, setAllReady] = useState(false);
  const [migrating, setMigrating] = useState(false);
  const [migrationResult, setMigrationResult] = useState<any>(null);
  const [copiedSql, setCopiedSql] = useState(false);

  const checkStatus = async () => {
    setChecking(true);
    try {
      const res = await checkDedicatedTablesAvailability(supabase);
      setTablesStatus(res.tables);
      setAllReady(res.allAvailable);
    } catch (err) {
      console.warn('Error checking tables:', err);
    } finally {
      setChecking(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      checkStatus();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const copySql = () => {
    navigator.clipboard.writeText(BUSINESS_MODULES_SQL_SCHEMA);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2500);
  };

  const handleRunMigration = async () => {
    setMigrating(true);
    setMigrationResult(null);
    try {
      const res = await migrateLegacyToDedicatedTables(supabase);
      setMigrationResult(res);
      if (res.success) {
        recordAuditLog(
          supabase,
          currentActorEmail,
          'DATABASE_PROGRESSIVE_MIGRATION_EXECUTED',
          'SYSTEM',
          { migratedCounts: res.migratedCounts }
        );
        onMigrationSuccess && onMigrationSuccess();
      }
    } catch (err: any) {
      setMigrationResult({ success: false, message: err?.message || 'Migration execution failed.' });
    } finally {
      setMigrating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[300] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl border border-[#C8A96A]/40 max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl text-[#1A1A1A] max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-gray-200 pb-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-bold uppercase mb-1">
              Zero Data Loss Migration
            </div>
            <h3 className="text-xl font-serif font-bold text-[#0F0F0F]">Supabase Database Migration Assistant</h3>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-700 p-1 text-sm cursor-pointer">
            ✕
          </button>
        </div>

        <p className="text-xs text-gray-600 leading-relaxed">
          The application currently operates with a resilient <strong>hybrid storage layer</strong>: business modules (Projects, Employees, Finance, Inventory, Calendar) write to Supabase safely. You can progressively migrate these into dedicated SQL tables for advanced querying without losing any existing records.
        </p>

        {/* Tables Health Status */}
        <div className="bg-gray-50 p-4 rounded-xl border border-gray-200 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-gray-800 uppercase tracking-wider">Dedicated SQL Tables Status</span>
            <button
              onClick={checkStatus}
              disabled={checking}
              className="text-xs text-[#8E733E] hover:underline font-semibold cursor-pointer disabled:opacity-50"
            >
              {checking ? 'Checking...' : '🔄 Re-check Status'}
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs">
            {Object.entries({
              audit_logs: 'Audit Logs',
              projects: 'Projects',
              employees: 'Employees',
              finance_records: 'Finance',
              inventory_items: 'Inventory',
              calendar_events: 'Calendar',
              ai_generations: 'AI Generations',
            }).map(([tableKey, label]) => {
              const ready = tablesStatus[tableKey];
              return (
                <div
                  key={tableKey}
                  className={`p-2.5 rounded-lg border flex items-center justify-between ${
                    ready
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                      : 'bg-neutral-100 border-neutral-200 text-neutral-600'
                  }`}
                >
                  <span className="font-semibold text-[11px]">{label}</span>
                  <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                    ready ? 'bg-emerald-600 text-white' : 'bg-gray-300 text-gray-700'
                  }`}>
                    {ready ? 'Dedicated' : 'JSON Store'}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Step 1: SQL Schema */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-gray-800 uppercase tracking-wider">
              Step 1: Execute SQL in Supabase Dashboard
            </span>
            <button
              onClick={copySql}
              className="gold-gradient-bg text-[#0F0F0F] font-bold text-xs px-3 py-1 rounded-md hover:brightness-110 shadow-sm cursor-pointer transition-all"
            >
              {copiedSql ? '✓ Copied!' : '📋 Copy All SQL'}
            </button>
          </div>
          <pre className="bg-[#0F0F0F] text-[#C8A96A] p-3.5 rounded-xl text-xs font-mono overflow-x-auto max-h-48 border border-neutral-800 select-all leading-relaxed">
            {BUSINESS_MODULES_SQL_SCHEMA}
          </pre>
        </div>

        {/* Step 2: Run Migration */}
        <div className="space-y-2">
          <span className="text-xs font-bold text-gray-800 uppercase tracking-wider block">
            Step 2: Sync Existing Records to Dedicated Tables
          </span>
          <p className="text-xs text-gray-600">
            Clicking migration copies all existing data from <code className="bg-gray-100 px-1 py-0.5 rounded text-gray-800">site_content.dashboard_records</code> into your dedicated SQL tables. Existing data is <strong>never overwritten or deleted</strong>.
          </p>
          <div className="pt-1">
            <button
              onClick={handleRunMigration}
              disabled={migrating}
              className="w-full bg-[#0F0F0F] hover:bg-neutral-800 text-white font-bold text-xs py-3 rounded-xl shadow-md transition-all cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {migrating ? '⏳ Migrating records...' : '🚀 Execute Safe Migration to Dedicated Tables'}
            </button>
          </div>

          {migrationResult && (
            <div className={`p-3.5 rounded-xl text-xs font-medium border ${
              migrationResult.success
                ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                : 'bg-rose-50 border-rose-200 text-rose-800'
            }`}>
              {migrationResult.message}
            </div>
          )}
        </div>

        <div className="flex justify-end pt-2 border-t border-gray-200">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg text-xs font-semibold text-gray-700 cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
