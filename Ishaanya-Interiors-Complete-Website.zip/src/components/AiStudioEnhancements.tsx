// @ts-nocheck
import React, { useState, useEffect } from 'react';
import { 
  persistAiRenderToGallery, 
  fetchAiGenerations, 
  AiGenerationItem 
} from '../lib/ai-studio-persistence';
import { recordAuditLog } from '../lib/audit-logs';

interface AiStudioSaveModalProps {
  isOpen: boolean;
  onClose: () => void;
  imageUrl: string;
  prompt: string;
  supabase: any;
  onSuccess: () => void;
  currentActorEmail?: string;
}

export const AiStudioSaveModal: React.FC<AiStudioSaveModalProps> = ({
  isOpen,
  onClose,
  imageUrl,
  prompt,
  supabase,
  onSuccess,
  currentActorEmail = 'himanshukanswal323@gmail.com',
}) => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Modular Kitchen');
  const [showModular, setShowModular] = useState(true);
  const [showHome, setShowHome] = useState(true);
  const [showPackages, setShowPackages] = useState(false);
  const [packageTag, setPackageTag] = useState('none');
  const [saving, setSaving] = useState(false);
  const [statusMsg, setStatusMsg] = useState('');

  useEffect(() => {
    if (prompt) {
      const clean = prompt
        .split(',')[0]
        .replace(/^(Luxury|Modern|Photorealistic|8K|Render|Design of)\s+/i, '')
        .trim();
      setTitle(clean.charAt(0).toUpperCase() + clean.slice(1) || 'Luxury Modular Kitchen Design');
    }
  }, [prompt]);

  if (!isOpen) return null;

  const handleSave = async () => {
    if (!title.trim()) {
      alert('Please enter a descriptive title for this photo.');
      return;
    }
    setSaving(true);
    setStatusMsg('Uploading to Supabase Storage ("gallery" bucket)...');

    try {
      const res = await persistAiRenderToGallery(supabase, {
        imageBase64OrUrl: imageUrl,
        title: title.trim(),
        prompt,
        category,
        showOnModularKitchen: showModular,
        showOnHomepage: showHome,
        showInPackages: showPackages,
        packageTag: showPackages ? packageTag : 'none',
      });

      if (res.success) {
        setStatusMsg('✓ Successfully saved to Supabase Storage and published to Gallery!');
        recordAuditLog(
          supabase,
          currentActorEmail,
          'AI_RENDER_PERSISTED_TO_STORAGE',
          'AI',
          { title, storagePath: res.storagePath, category }
        );
        setTimeout(() => {
          onSuccess();
          onClose();
        }, 1200);
      } else {
        setStatusMsg(`Failed: ${res.error || 'Could not upload image.'}`);
      }
    } catch (err: any) {
      setStatusMsg(`Error: ${err?.message || 'Upload failed'}`);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[300] bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl border border-[#C8A96A]/40 max-w-lg w-full p-6 space-y-4 shadow-2xl text-[#1A1A1A]">
        <div className="flex items-center justify-between border-b border-gray-200 pb-3">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#8E733E]">Supabase Storage & Portfolio</span>
            <h3 className="text-base font-serif font-bold text-[#0F0F0F]">Save Render to Website Gallery</h3>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-700 p-1 text-sm cursor-pointer">
            ✕
          </button>
        </div>

        {/* Thumbnail Preview */}
        <div className="flex gap-3 items-center bg-gray-50 p-2.5 rounded-xl border border-gray-200">
          <img src={imageUrl} alt="AI Render" className="w-20 h-16 object-cover rounded-lg border border-gray-300" />
          <div className="text-xs text-gray-600 space-y-0.5 truncate">
            <p className="font-semibold text-gray-900 truncate">{title || 'Modular Kitchen 3D Render'}</p>
            <p className="text-[11px] text-gray-500 font-mono">Bucket: gallery/ai_renders/</p>
            <p className="text-[10px] text-emerald-700 font-semibold">✓ Permanent Cloud Storage</p>
          </div>
        </div>

        {/* Form Fields */}
        <div className="space-y-3 text-xs">
          <div>
            <label className="block font-bold text-gray-800 uppercase text-[10px] mb-1">Image Title</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Italian Charcoal Fluted Kitchen Island"
              className="w-full bg-[#F5F5F5] border border-gray-200 rounded-lg px-3 py-2 text-xs focus:outline-none focus:border-[#C8A96A]"
            />
          </div>

          <div>
            <label className="block font-bold text-gray-800 uppercase text-[10px] mb-1">Category</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full bg-[#F5F5F5] border border-gray-200 rounded-lg px-3 py-2 text-xs focus:outline-none focus:border-[#C8A96A]"
            >
              <option value="Modular Kitchen">Modular Kitchen</option>
              <option value="Luxury Homes">Luxury Homes</option>
              <option value="Turnkey Interiors">Turnkey Interiors</option>
              <option value="Wardrobes">Wardrobes & Walk-in Closets</option>
              <option value="Living Room">Living Room & Lounges</option>
            </select>
          </div>

          {/* Placements */}
          <div className="bg-gray-50 p-3 rounded-xl border border-gray-200 space-y-2">
            <span className="block font-bold text-gray-800 uppercase text-[10px]">Website Placements</span>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={showModular}
                onChange={(e) => setShowModular(e.target.checked)}
                className="rounded border-gray-300 text-[#C8A96A] focus:ring-[#C8A96A]"
              />
              <span className="text-gray-700">Display on <strong>/modular-kitchen-dehradun</strong> page</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={showHome}
                onChange={(e) => setShowHome(e.target.checked)}
                className="rounded border-gray-300 text-[#C8A96A] focus:ring-[#C8A96A]"
              />
              <span className="text-gray-700">Display on Homepage <strong>Portfolio Gallery</strong></span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={showPackages}
                onChange={(e) => setShowPackages(e.target.checked)}
                className="rounded border-gray-300 text-[#C8A96A] focus:ring-[#C8A96A]"
              />
              <span className="text-gray-700">Feature as Kitchen Package Header Image</span>
            </label>
            {showPackages && (
              <div className="pl-6 pt-1">
                <select
                  value={packageTag}
                  onChange={(e) => setPackageTag(e.target.value)}
                  className="bg-white border border-gray-300 rounded px-2.5 py-1 text-xs"
                >
                  <option value="essential">Essential Modular</option>
                  <option value="royale">Royale Luxe</option>
                  <option value="imperial">Imperial Bespoke</option>
                </select>
              </div>
            )}
          </div>

          {statusMsg && (
            <p className={`text-xs font-semibold p-2 rounded-lg ${statusMsg.startsWith('✓') ? 'bg-emerald-50 text-emerald-800' : 'bg-amber-50 text-amber-800'}`}>
              {statusMsg}
            </p>
          )}
        </div>

        <div className="flex justify-end gap-2 pt-2 border-t border-gray-200">
          <button
            onClick={onClose}
            disabled={saving}
            className="px-4 py-2 rounded-lg text-xs font-semibold text-gray-600 hover:bg-gray-100 cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={saving}
            className="gold-gradient-bg text-[#0F0F0F] font-bold text-xs px-5 py-2 rounded-lg hover:brightness-110 shadow-md transition-all cursor-pointer disabled:opacity-50 flex items-center gap-2"
          >
            {saving ? '⏳ Uploading...' : '💾 Save to Supabase & Publish'}
          </button>
        </div>
      </div>
    </div>
  );
};

interface AiGenerationsHistoryGridProps {
  supabase: any;
  onSelectForEdit?: (item: AiGenerationItem) => void;
  onSaveToGallery?: (item: AiGenerationItem) => void;
}

export const AiGenerationsHistoryGrid: React.FC<AiGenerationsHistoryGridProps> = ({
  supabase,
  onSelectForEdit,
  onSaveToGallery,
}) => {
  const [history, setHistory] = useState<AiGenerationItem[]>([]);
  const [loading, setLoading] = useState(false);

  const loadHistory = async () => {
    setLoading(true);
    try {
      const data = await fetchAiGenerations(supabase);
      setHistory(data);
    } catch (err) {
      console.warn('Failed to load AI history:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadHistory();
  }, [supabase]);

  if (loading && history.length === 0) {
    return <div className="text-center py-6 text-gray-400 text-xs">Loading generation library from Supabase...</div>;
  }

  if (history.length === 0) {
    return null;
  }

  return (
    <div className="bg-white p-6 rounded-2xl border border-gray-200/80 shadow-sm space-y-4">
      <div className="flex items-center justify-between border-b border-gray-100 pb-3">
        <div>
          <h3 className="text-base font-serif font-bold text-[#0F0F0F]">Saved AI Renders Library</h3>
          <p className="text-xs text-gray-500">Persisted in Supabase records and cloud storage.</p>
        </div>
        <button
          onClick={loadHistory}
          className="text-xs text-[#8E733E] hover:underline font-semibold cursor-pointer"
        >
          🔄 Refresh Library
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {history.map(item => (
          <div key={item.id} className="group relative bg-[#0F0F0F] rounded-xl overflow-hidden border border-neutral-800 shadow-sm flex flex-col">
            <div className="aspect-video relative overflow-hidden bg-neutral-900">
              <img
                src={item.imageUrl}
                alt={item.prompt}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <span className="absolute top-2 right-2 bg-black/70 backdrop-blur-sm text-[#C8A96A] text-[9px] font-bold px-2 py-0.5 rounded uppercase">
                {item.aspectRatio || '16:9'}
              </span>
            </div>

            <div className="p-3 text-white flex-1 flex flex-col justify-between space-y-2">
              <p className="text-[11px] text-gray-300 line-clamp-2 leading-relaxed">
                {item.prompt}
              </p>

              <div className="pt-2 border-t border-neutral-800 flex items-center justify-between text-[10px]">
                <span className="text-gray-500">
                  {new Date(item.timestamp).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })}
                </span>

                <div className="flex items-center gap-2">
                  <a
                    href={item.imageUrl}
                    download={`ai-render-${item.id}.png`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#C8A96A] hover:underline font-semibold"
                  >
                    Download
                  </a>
                  {onSelectForEdit && (
                    <button
                      onClick={() => onSelectForEdit(item)}
                      className="text-sky-400 hover:underline font-semibold cursor-pointer"
                    >
                      Edit
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
