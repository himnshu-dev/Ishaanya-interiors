// @ts-nocheck
import React, { useState } from 'react';
import { 
  Sparkles, 
  Check, 
  ShieldCheck, 
  Clock, 
  Layers, 
  IndianRupee, 
  ChevronRight, 
  Sliders, 
  Star,
  Award,
  Wrench,
  X
} from 'lucide-react';

interface PackageCollectionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenConfigurator?: (pkg: 'essential' | 'royale' | 'imperial') => void;
  onBookPackage?: (pkgName: string) => void;
}

export const PackageCollectionsModal: React.FC<PackageCollectionsModalProps> = ({
  isOpen,
  onClose,
  onOpenConfigurator,
  onBookPackage
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'comparison'>('overview');
  const [selectedPkg, setSelectedPkg] = useState<'essential' | 'royale' | 'imperial'>('royale');

  const PACKAGES = [
    {
      id: 'essential',
      badge: 'High Durability',
      title: 'Essential Luxury Collection',
      tagline: 'High-Pressure Anti-Scratch Laminate',
      idealFor: 'Modern 2BHK / 3BHK homes requiring extreme scratch-resistance and zero maintenance.',
      startingPrice: '₹1.45 Lakhs',
      warranty: '5 Years Comprehensive',
      turnaround: '30 - 35 Working Days',
      color: '#5C4033',
      features: [
        '100% BWP Grade IS:710 Marine Plywood carcass',
        '1mm Heavy-Duty High-Pressure Textured Laminate',
        'Machine-pressed 2mm zero-gap PVC edge-banding',
        'Hettich/Hafele soft-close clip-on concealed hinges',
        'Grade-304 Stainless steel wire baskets & cutlery tray',
        'Jet Black Granite or Solid Surface countertop option',
        'Moisture-shield calibrated core boards'
      ],
      specHardware: 'Hettich / Hafele Soft-Close Hinges',
      specCore: 'BWP Marine Ply (IS:710)',
      specFinish: '1mm High Pressure Gloss/Textured Laminate',
      specEdge: '2mm Seamless PVC Edgebanding',
      specLoad: '30 kg per tandem drawer'
    },
    {
      id: 'royale',
      badge: 'Most Popular in Dehradun',
      title: 'Premium Royale Collection',
      tagline: 'Optical High-Gloss Glass-Like Acrylic',
      idealFor: 'Luxury residences and contemporary apartments demanding mirror reflection and deep rich color saturation.',
      startingPrice: '₹2.35 Lakhs',
      warranty: '10 Years Comprehensive',
      turnaround: '35 - 40 Working Days',
      color: '#C8A96A',
      isPopular: true,
      features: [
        'BWP Marine Grade & HDHMR calibrated core carcass',
        '2mm Seamless Optical Grade High-Gloss Acrylic',
        'Gola Profile Handleless Channel System (Brushed Gold/Black)',
        'Hettich InnoTech Atira or Blum Tandembox drawer runners',
        'Italian Statuario Quartz Stone countertop integration',
        'Integrated warm LED profile strip illumination',
        'Anti-fingerprint nano surface coat option'
      ],
      specHardware: 'Blum Tandembox / Hettich InnoTech Runners',
      specCore: 'Calibrated BWP Marine Ply + HDHMR',
      specFinish: '2mm Optical High-Gloss Scratch-Resistant Acrylic',
      specEdge: 'PUR Waterproof Zero-Joint Laser Edge',
      specLoad: '50 kg per drawer box'
    },
    {
      id: 'imperial',
      badge: 'Ultra Luxury Statement',
      title: 'Bespoke Imperial Collection',
      tagline: 'Italian 7-Layer Super-Matte PU Lacquer',
      idealFor: 'Grand villas, penthouses, and bespoke residences seeking seamless zero-edge architectural elegance.',
      startingPrice: '₹3.85 Lakhs',
      warranty: '12 Years Lifetime Support',
      turnaround: '40 - 45 Working Days',
      color: '#D4AF37',
      features: [
        'German-Grade E0 Low-Emission BWP Marine Plywood',
        '7-Layer Polyurethane (PU) Lacquer in Silk Matte / Gloss',
        'Zero-joint seamless molded shutter edges (No tape banding)',
        'Blum Aventos motorized bi-fold lift-up wall units',
        'Exotic Brazilian Quartzite / Nanowhite stone slab',
        'Concealed automatic sensor LED cabinet lighting',
        'Custom pantry pull-out larder with tempered glass rails'
      ],
      specHardware: 'Blum Aventos Bi-Fold + Motorized Servo-Drive',
      specCore: 'German Grade E0 Ultra-Calibrated BWP Ply',
      specFinish: '7-Layer Italian Polyurethane (PU) Lacquer',
      specEdge: '100% Seamless Monolithic Lacquered Zero Edge',
      specLoad: '65 kg Heavy-Duty Runners'
    }
  ];

  return (
    <div 
      id="package-collections-modal-root" 
      data-component="PackageCollectionsModal"
      data-mounted="true" 
      data-open={isOpen ? "true" : "false"}
      className={isOpen ? "fixed inset-0 z-[250] bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto" : "hidden"}
    >
      {isOpen && (
        <div className="relative w-full max-w-5xl bg-[#0D0D11] text-white border border-[#C8A96A]/40 rounded-2xl shadow-2xl overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-200">
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-[#14141A]">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#C8A96A]/20 border border-[#C8A96A]/40 flex items-center justify-center text-[#C8A96A]">
                <Award className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-[#C8A96A]">
                  Ishaanya Signature Collections
                </span>
                <h2 className="text-xl sm:text-2xl font-serif font-bold text-white">
                  Modular Kitchen Finish Packages
                </h2>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {/* View Switcher */}
              <div className="flex items-center bg-black/50 p-1 rounded-xl border border-white/10 text-xs">
                <button
                  onClick={() => setActiveTab('overview')}
                  className={`px-3 py-1.5 rounded-lg font-semibold transition-all cursor-pointer ${
                    activeTab === 'overview'
                      ? 'bg-[#C8A96A] text-black shadow'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  Cards View
                </button>
                <button
                  onClick={() => setActiveTab('comparison')}
                  className={`px-3 py-1.5 rounded-lg font-semibold transition-all cursor-pointer ${
                    activeTab === 'comparison'
                      ? 'bg-[#C8A96A] text-black shadow'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  Spec Comparison
                </button>
              </div>

              <button
                onClick={onClose}
                className="p-2 text-gray-400 hover:text-white hover:bg-white/10 rounded-xl transition-all cursor-pointer text-lg font-bold ml-2"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Modal Body */}
          <div className="p-6 max-h-[75vh] overflow-y-auto space-y-6">
            {activeTab === 'overview' ? (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                {PACKAGES.map(pkg => (
                  <div
                    key={pkg.id}
                    className={`rounded-2xl p-5 border flex flex-col justify-between transition-all relative ${
                      pkg.isPopular
                        ? 'bg-gradient-to-b from-[#1C1A14] to-[#121217] border-[#C8A96A] shadow-xl shadow-[#C8A96A]/10'
                        : 'bg-[#121216] border-white/10 hover:border-white/20'
                    }`}
                  >
                    {pkg.isPopular && (
                      <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#C8A96A] text-black text-[10px] font-bold uppercase tracking-wider px-3 py-0.5 rounded-full shadow-md flex items-center gap-1">
                        <Star className="w-3 h-3 fill-current" />
                        <span>{pkg.badge}</span>
                      </div>
                    )}

                    <div>
                      <div className="mb-3">
                        <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-widest block">
                          {pkg.tagline}
                        </span>
                        <h3 className="text-xl font-serif font-bold text-white mt-1">
                          {pkg.title}
                        </h3>
                      </div>

                      <div className="bg-black/40 rounded-xl p-3 border border-white/5 mb-4 flex items-baseline justify-between">
                        <div>
                          <span className="text-[10px] text-gray-400 uppercase block">Starting from</span>
                          <span className="text-xl font-bold font-serif text-[#C8A96A]">{pkg.startingPrice}</span>
                        </div>
                        <div className="text-right">
                          <span className="text-[10px] text-gray-400 block">{pkg.warranty}</span>
                          <span className="text-[11px] text-emerald-400 font-medium">BWP IS:710 Core</span>
                        </div>
                      </div>

                      <p className="text-xs text-gray-300 leading-relaxed mb-4">
                        {pkg.idealFor}
                      </p>

                      <div className="space-y-2 mb-6">
                        <div className="text-[11px] font-bold uppercase tracking-wider text-neutral-300">
                          Package Specifications:
                        </div>
                        {pkg.features.map((feat, idx) => (
                          <div key={idx} className="flex items-start gap-2 text-xs text-gray-300">
                            <Check className="w-3.5 h-3.5 text-[#C8A96A] shrink-0 mt-0.5" />
                            <span>{feat}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-2 pt-2 border-t border-white/10">
                      <button
                        onClick={() => {
                          onClose();
                          if (onOpenConfigurator) onOpenConfigurator(pkg.id as any);
                        }}
                        className="w-full py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/15 text-white font-semibold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer border border-white/10"
                      >
                        <Sliders className="w-3.5 h-3.5 text-[#C8A96A]" />
                        <span>Configure in 3D Studio</span>
                      </button>

                      <button
                        onClick={() => {
                          onClose();
                          if (onBookPackage) onBookPackage(pkg.title);
                        }}
                        className={`w-full py-2.5 px-3 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                          pkg.isPopular
                            ? 'gold-gradient-bg text-black hover:brightness-110 shadow-md'
                            : 'bg-[#C8A96A]/20 text-[#C8A96A] border border-[#C8A96A]/40 hover:bg-[#C8A96A]/30'
                        }`}
                      >
                        <span>Book Free Site Visit</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              /* Comparison Table */
              <div className="overflow-x-auto rounded-xl border border-white/10">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-[#181820] text-gray-300 border-b border-white/10">
                      <th className="p-3.5 font-bold uppercase tracking-wider text-[11px] text-[#C8A96A]">Feature Parameter</th>
                      <th className="p-3.5 font-bold text-white">Essential Luxury (Laminate)</th>
                      <th className="p-3.5 font-bold text-[#C8A96A] bg-[#C8A96A]/10">Premium Royale (Acrylic)</th>
                      <th className="p-3.5 font-bold text-white">Bespoke Imperial (PU Lacquer)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/10 text-gray-300">
                    <tr>
                      <td className="p-3 font-semibold text-white">Base Core Material</td>
                      <td className="p-3">IS:710 Marine Grade BWP Plywood</td>
                      <td className="p-3 bg-[#C8A96A]/5 font-medium text-white">Calibrated BWP Marine Ply + HDHMR</td>
                      <td className="p-3">German-Grade E0 Low-Emission BWP Ply</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-semibold text-white">Shutter Finish Technology</td>
                      <td className="p-3">1mm High-Pressure Scratch-Resistant Laminate</td>
                      <td className="p-3 bg-[#C8A96A]/5 font-medium text-white">2mm Optical High-Gloss Seamless Acrylic</td>
                      <td className="p-3">7-Layer Italian Polyurethane (PU) Matte/Gloss</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-semibold text-white">Edge Sealing</td>
                      <td className="p-3">2mm Machine-Pressed PVC Edgeband</td>
                      <td className="p-3 bg-[#C8A96A]/5 font-medium text-white">PUR Waterproof Zero-Joint Laser Edge</td>
                      <td className="p-3">Monolithic Zero-Joint Lacquer Edge</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-semibold text-white">Hardware Runners & Hinges</td>
                      <td className="p-3">Hafele / Hettich Soft-Close Clip-on</td>
                      <td className="p-3 bg-[#C8A96A]/5 font-medium text-white">Hettich InnoTech Atira / Blum Tandembox</td>
                      <td className="p-3">Blum Aventos Bi-fold + Motorized Touch</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-semibold text-white">Drawer Weight Load</td>
                      <td className="p-3">30 kg / drawer</td>
                      <td className="p-3 bg-[#C8A96A]/5 font-medium text-white">50 kg / drawer</td>
                      <td className="p-3">65 kg / drawer</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-semibold text-white">Water & Termite Protection</td>
                      <td className="p-3">100% Waterproof Core + Anti-Boring Termite</td>
                      <td className="p-3 bg-[#C8A96A]/5 font-medium text-white">100% Boiling Waterproof with PUR seal</td>
                      <td className="p-3">100% Sealed Monolithic Marine Carcass</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-semibold text-white">Countertop Integration</td>
                      <td className="p-3">Jet Black Granite / Solid Surface</td>
                      <td className="p-3 bg-[#C8A96A]/5 font-medium text-white">Italian Statuario Quartz Stone</td>
                      <td className="p-3">Exotic Brazilian Quartzite / Nanowhite</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-semibold text-white">Warranty</td>
                      <td className="p-3">5 Years Comprehensive</td>
                      <td className="p-3 bg-[#C8A96A]/5 font-bold text-[#C8A96A]">10 Years Comprehensive</td>
                      <td className="p-3 font-bold text-amber-300">12 Years Lifetime Support</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            )}

            {/* Bottom Founder Note */}
            <div className="bg-[#141419] rounded-xl p-4 border border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <img
                  src="/images/himanshu_kanswal_founder.jpg"
                  alt="Himanshu Kanswal"
                  className="w-12 h-12 rounded-full object-cover border-2 border-[#C8A96A]"
                  onError={(e: any) => {
                    e.target.src = 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80';
                  }}
                />
                <div>
                  <h4 className="text-sm font-bold text-white">Free Doorstep Site Measurement & Laser Estimation</h4>
                  <p className="text-xs text-gray-400">Founder Himanshu Kanswal visits every site in Dehradun personally.</p>
                </div>
              </div>

              <button
                onClick={() => {
                  onClose();
                  if (onBookPackage) onBookPackage('Custom Modular Kitchen Dehradun');
                }}
                className="py-2.5 px-6 rounded-xl gold-gradient-bg text-black font-bold text-xs transition-all hover:brightness-110 cursor-pointer shrink-0"
              >
                Book Free Site Visit
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
