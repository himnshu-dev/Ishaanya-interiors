// @ts-nocheck
import React from 'react';
import { ThreeKitchenConfigurator } from './ThreeKitchenConfigurator';
import { Box, Sparkles, Award, ShieldCheck, CheckCircle2, ArrowRight } from 'lucide-react';

interface InPage3DStudioProps {
  onBookDesign?: (config: any) => void;
  onExplorePackages?: () => void;
}

export const InPage3DStudio: React.FC<InPage3DStudioProps> = ({
  onBookDesign,
  onExplorePackages
}) => {
  return (
    <section id="kitchen-3d-configurator" className="relative py-16 sm:py-24 bg-[#0A0A0E] text-white border-y border-white/10 overflow-hidden">
      {/* Background radial glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] bg-[radial-gradient(ellipse_at_center,rgba(200,169,106,0.1)_0%,transparent_70%)] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#C8A96A]/20 border border-[#C8A96A]/40 text-[#C8A96A] text-xs font-semibold uppercase tracking-wider">
            <Box className="w-3.5 h-3.5 animate-spin [animation-duration:8s]" />
            <span>Virtual 3D Design Experience</span>
          </div>

          <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif font-bold text-white tracking-tight">
            Configure Your Kitchen in 3D Real-Time
          </h2>

          <p className="text-xs sm:text-sm text-gray-300 leading-relaxed max-w-2xl mx-auto">
            Rotate in 360°, inspect L-Shape vs Island layouts, switch between High-Gloss Acrylic, Italian Super-Matte PU and Warm Walnut Laminate, test Statuario quartz countertops, and preview under-cabinet LED illumination.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4 pt-2 text-xs text-gray-400">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              100% BWP IS:710 Marine Plywood Core
            </span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#C8A96A]" />
              Blum & Hettich German Hardware
            </span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              Free Dehradun Laser Measurement
            </span>
          </div>
        </div>

        {/* The Live Three.js 3D Configurator */}
        <div className="w-full shadow-2xl">
          <ThreeKitchenConfigurator
            initialLayout="l-shape"
            initialPackage="royale"
            onBookDesign={(config) => {
              if (onBookDesign) {
                onBookDesign(config);
              } else if (window.openKitchenBooking) {
                window.openKitchenBooking({
                  layout: config.layout === 'l-shape' ? 'L-Shaped Kitchen' : config.layout === 'u-shape' ? 'U-Shaped Kitchen' : config.layout === 'parallel' ? 'Parallel (Galley) Kitchen' : config.layout === 'island' ? 'Island Kitchen' : 'Straight-Line Kitchen',
                  packageTier: config.packageTier === 'essential' ? 'Essential Luxury (Laminate)' : config.packageTier === 'royale' ? 'Premium Royale (Acrylic)' : 'Bespoke Imperial (Super Matte PU)',
                  finishName: config.finishName,
                  countertopName: config.countertopName,
                  estimatedPrice: config.estimatedPrice,
                  ledLighting: config.ledLighting
                });
              }
            }}
          />
        </div>

        {/* Feature Highlights Grid beneath 3D canvas */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-8">
          <div className="p-4 rounded-xl bg-[#121217] border border-white/5 flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#C8A96A]/20 flex items-center justify-center text-[#C8A96A] shrink-0 mt-0.5">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">3 Finish Collections</h4>
              <p className="text-[11px] text-gray-400 mt-0.5">
                Essential Laminate (₹1.45L+), Premium Royale Acrylic (₹2.35L+), and Bespoke Imperial PU (₹3.85L+).
              </p>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-[#121217] border border-white/5 flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0 mt-0.5">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">Up to 12-Year Warranty</h4>
              <p className="text-[11px] text-gray-400 mt-0.5">
                Calibrated marine carcasses built specifically for Dehradun moisture and temperature variation.
              </p>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-[#121217] border border-white/5 flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 flex items-center justify-center text-amber-300 shrink-0 mt-0.5">
              <Award className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">Doorstep Laser Visit</h4>
              <p className="text-[11px] text-gray-400 mt-0.5">
                Founder Himanshu Kanswal visits your home for precision 3D CAD modeling and an exact quotation.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
