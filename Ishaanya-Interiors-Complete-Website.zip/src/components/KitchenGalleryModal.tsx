// @ts-nocheck
import React from 'react';
import { X, MapPin, Tag, Calendar, ExternalLink, ChevronLeft, ChevronRight } from 'lucide-react';

export interface GalleryItem {
  id: string;
  title: string;
  category: string;
  imageUrl: string;
  location?: string;
  packageTag?: string;
  finishType?: string;
  description?: string;
}

interface KitchenGalleryModalProps {
  item: GalleryItem | null;
  onClose: () => void;
  onInquire?: (item: GalleryItem) => void;
  onPrev?: () => void;
  onNext?: () => void;
}

export const KitchenGalleryModal: React.FC<KitchenGalleryModalProps> = ({
  item,
  onClose,
  onInquire,
  onPrev,
  onNext
}) => {
  if (!item) return null;

  return (
    <div className="fixed inset-0 z-[270] bg-black/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl bg-[#0F0F12] border border-[#C8A96A]/40 rounded-2xl shadow-2xl overflow-hidden my-auto flex flex-col md:flex-row">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 z-30 p-2 rounded-full bg-black/60 hover:bg-black/90 text-gray-300 hover:text-white transition-all cursor-pointer border border-white/10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Prev / Next Nav Buttons */}
        {onPrev && (
          <button
            onClick={onPrev}
            className="absolute left-3 top-1/2 -translate-y-1/2 z-30 p-2 rounded-full bg-black/60 hover:bg-black/90 text-gray-300 hover:text-white transition-all cursor-pointer border border-white/10"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
        )}
        {onNext && (
          <button
            onClick={onNext}
            className="absolute right-3 md:right-[380px] top-1/2 -translate-y-1/2 z-30 p-2 rounded-full bg-black/60 hover:bg-black/90 text-gray-300 hover:text-white transition-all cursor-pointer border border-white/10"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        )}

        {/* Image Container */}
        <div className="md:w-3/5 bg-black flex items-center justify-center relative min-h-[320px] md:min-h-[480px]">
          <img
            src={item.imageUrl}
            alt={item.title}
            className="w-full h-full object-cover max-h-[520px]"
            onError={(e: any) => {
              e.target.src = '/images/luxury_modular_kitchen.jpg';
            }}
          />
          <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/80 via-transparent to-transparent p-4 flex items-center justify-between text-xs text-gray-300">
            <span className="bg-black/60 backdrop-blur px-2.5 py-1 rounded border border-white/10">
              {item.category}
            </span>
            {item.location && (
              <span className="flex items-center gap-1 bg-black/60 backdrop-blur px-2.5 py-1 rounded border border-white/10 text-amber-200">
                <MapPin className="w-3 h-3 text-[#C8A96A]" />
                {item.location}
              </span>
            )}
          </div>
        </div>

        {/* Details Sidebar */}
        <div className="md:w-2/5 p-6 flex flex-col justify-between bg-[#141419] border-t md:border-t-0 md:border-l border-white/10">
          <div className="space-y-4">
            <div>
              <span className="text-[10px] uppercase font-bold tracking-widest text-[#C8A96A] block">
                Dehradun Project Showcase
              </span>
              <h3 className="text-xl font-serif font-bold text-white mt-1">
                {item.title}
              </h3>
            </div>

            {item.description && (
              <p className="text-xs text-gray-300 leading-relaxed">
                {item.description}
              </p>
            )}

            <div className="space-y-2 pt-2 border-t border-white/10 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Finish Specification:</span>
                <span className="font-semibold text-white">{item.finishType || 'Seamless High-Gloss / PU'}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Carcass Core:</span>
                <span className="font-semibold text-emerald-400">100% BWP IS:710 Marine Ply</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Hardware Grade:</span>
                <span className="font-semibold text-[#C8A96A]">Hettich / Blum Soft-Close</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Execution by:</span>
                <span className="font-semibold text-white">Ishaanya Factory Unit</span>
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-white/10 space-y-2.5">
            <button
              onClick={() => {
                onClose();
                if (onInquire) onInquire(item);
                else if (window.openKitchenBooking) window.openKitchenBooking({ notes: `Inquiry for design: ${item.title}` });
              }}
              className="w-full py-3 px-4 rounded-xl gold-gradient-bg text-black font-bold text-xs tracking-wider uppercase transition-all hover:brightness-110 shadow-lg cursor-pointer flex items-center justify-center gap-2"
            >
              <Calendar className="w-4 h-4" />
              <span>Get Quote For This Design</span>
            </button>

            <button
              onClick={() => {
                onClose();
                if (window.open3DConfigurator) window.open3DConfigurator('royale');
              }}
              className="w-full py-2.5 px-4 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 font-semibold text-xs border border-white/10 transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <span>Customize Similar in 3D</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
