// @ts-nocheck
import React, { useState, useMemo } from 'react';
import { 
  computeExecutiveReport, 
  downloadReportCSV, 
  triggerExecutiveReportPrint, 
  DATE_PRESETS, 
  ReportDateRange 
} from '../lib/reports-analytics';
import { recordAuditLog } from '../lib/audit-logs';

interface ExecutiveReportsViewProps {
  inquiries: any[];
  liveProjects: any[];
  financeRecords: any[];
  supabase?: any;
  currentActorEmail?: string;
}

export const ExecutiveReportsView: React.FC<ExecutiveReportsViewProps> = ({
  inquiries = [],
  liveProjects = [],
  financeRecords = [],
  supabase,
  currentActorEmail = 'himanshukanswal323@gmail.com',
}) => {
  const [dateRange, setDateRange] = useState<ReportDateRange>({
    preset: 'all',
  });
  const [customStart, setCustomStart] = useState('');
  const [customEnd, setCustomEnd] = useState('');

  // Compute report data dynamically based on selected date range
  const reportData = useMemo(() => {
    const range: ReportDateRange = {
      preset: dateRange.preset,
      startDate: dateRange.preset === 'custom' ? customStart : undefined,
      endDate: dateRange.preset === 'custom' ? customEnd : undefined,
    };
    return computeExecutiveReport(inquiries, liveProjects, financeRecords, range);
  }, [inquiries, liveProjects, financeRecords, dateRange, customStart, customEnd]);

  const handleExportCSV = () => {
    downloadReportCSV(reportData);
    recordAuditLog(
      supabase,
      currentActorEmail,
      'REPORT_EXPORTED_CSV',
      'REPORTS',
      { range: reportData.rangeLabel, totalLeads: reportData.leads.total, totalProjects: reportData.projects.total }
    );
  };

  const handleExportPDF = () => {
    triggerExecutiveReportPrint(reportData);
    recordAuditLog(
      supabase,
      currentActorEmail,
      'REPORT_EXPORTED_PDF',
      'REPORTS',
      { range: reportData.rangeLabel, totalLeads: reportData.leads.total, totalProjects: reportData.projects.total }
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-gray-200/80 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#C8A96A]/15 border border-[#C8A96A]/40 text-[#8E733E] text-xs font-semibold mb-2">
            <span>📊</span> Executive Business Analytics
          </div>
          <h2 className="text-2xl font-serif font-bold text-[#0F0F0F]">Performance & Revenue Reports</h2>
          <p className="text-xs text-gray-600 mt-1">
            Aggregated in real-time from Supabase leads, active projects, and financial ledgers.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={handleExportCSV}
            className="px-4 py-2.5 text-xs font-semibold rounded-lg border border-gray-300 hover:border-gray-400 bg-white text-gray-800 transition-all flex items-center gap-2 shadow-sm cursor-pointer"
          >
            <span>📥</span> Export CSV Data
          </button>
          <button
            onClick={handleExportPDF}
            className="gold-gradient-bg text-[#0F0F0F] font-bold text-xs px-5 py-2.5 rounded-lg hover:brightness-110 shadow-md transition-all flex items-center gap-2 cursor-pointer"
          >
            <span>🖨️</span> Print / Save PDF
          </button>
        </div>
      </div>

      {/* Date Filter Bar */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-gray-200/80 shadow-sm space-y-3">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-gray-700 uppercase tracking-wider">Date Filter:</span>
            <span className="text-xs font-semibold text-[#8E733E] bg-[#C8A96A]/15 px-2.5 py-0.5 rounded-full">
              {reportData.rangeLabel}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            {DATE_PRESETS.map(preset => {
              const active = dateRange.preset === preset.id;
              return (
                <button
                  key={preset.id}
                  onClick={() => setDateRange({ preset: preset.id as any })}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                    active
                      ? 'bg-[#0F0F0F] text-[#C8A96A] font-bold shadow-sm'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {preset.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Custom Date Pickers */}
        {dateRange.preset === 'custom' && (
          <div className="pt-3 border-t border-gray-100 flex flex-wrap items-center gap-3 text-xs">
            <div className="flex items-center gap-2">
              <label className="font-semibold text-gray-700">From:</label>
              <input
                type="date"
                value={customStart}
                onChange={(e) => setCustomStart(e.target.value)}
                className="bg-[#F5F5F5] border border-gray-200 rounded-lg px-3 py-1.5 focus:outline-none focus:border-[#C8A96A]"
              />
            </div>
            <div className="flex items-center gap-2">
              <label className="font-semibold text-gray-700">To:</label>
              <input
                type="date"
                value={customEnd}
                onChange={(e) => setCustomEnd(e.target.value)}
                className="bg-[#F5F5F5] border border-gray-200 rounded-lg px-3 py-1.5 focus:outline-none focus:border-[#C8A96A]"
              />
            </div>
          </div>
        )}
      </div>

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Inquiries */}
        <div className="bg-white p-5 rounded-2xl border border-gray-200/80 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-xs text-gray-500 font-semibold uppercase">
            <span>Total Inquiries</span>
            <span className="text-sky-600">Leads Funnel</span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold font-serif text-[#0F0F0F]">{reportData.leads.total}</span>
            <span className="text-xs text-emerald-600 font-medium">({reportData.leads.won} Won)</span>
          </div>
          <div className="w-full bg-gray-100 h-1.5 rounded-full overflow-hidden">
            <div
              className="bg-emerald-500 h-full rounded-full"
              style={{ width: `${Math.min(100, reportData.leads.conversionRate)}%` }}
            ></div>
          </div>
          <p className="text-[11px] text-gray-500">
            Conversion Rate: <strong className="text-gray-800">{reportData.leads.conversionRate}%</strong> • {reportData.leads.hotProspects} Hot
          </p>
        </div>

        {/* Live Projects */}
        <div className="bg-white p-5 rounded-2xl border border-gray-200/80 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-xs text-gray-500 font-semibold uppercase">
            <span>Live Projects</span>
            <span className="text-amber-600">Execution</span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold font-serif text-[#0F0F0F]">{reportData.projects.total}</span>
            <span className="text-xs text-gray-500">({reportData.projects.active} Active on site)</span>
          </div>
          <div className="w-full bg-gray-100 h-1.5 rounded-full overflow-hidden">
            <div
              className="bg-[#C8A96A] h-full rounded-full"
              style={{
                width: `${reportData.projects.total > 0 ? (reportData.projects.completed / reportData.projects.total) * 100 : 0}%`,
              }}
            ></div>
          </div>
          <p className="text-[11px] text-gray-500">
            Completed: <strong className="text-gray-800">{reportData.projects.completed}</strong> • In Planning: <strong className="text-gray-800">{reportData.projects.planning}</strong>
          </p>
        </div>

        {/* Contracted Value */}
        <div className="bg-white p-5 rounded-2xl border border-gray-200/80 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-xs text-gray-500 font-semibold uppercase">
            <span>Contract Pipeline</span>
            <span className="text-purple-600">Total Value</span>
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold font-serif text-[#0F0F0F]">
              ₹{reportData.projects.totalContractValue.toLocaleString('en-IN')}
            </span>
          </div>
          <p className="text-[11px] text-gray-500 pt-2">
            Avg Project Ticket: <strong className="text-gray-800">₹{reportData.projects.avgTicketSize.toLocaleString('en-IN')}</strong>
          </p>
          <p className="text-[10px] text-gray-400">
            Pipeline Budget: ₹{reportData.leads.estimatedPipelineValue.toLocaleString('en-IN')}
          </p>
        </div>

        {/* Recorded Revenue & Margin */}
        <div className="bg-white p-5 rounded-2xl border border-gray-200/80 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-xs text-gray-500 font-semibold uppercase">
            <span>Operating Revenue</span>
            <span className="text-emerald-600">Finance</span>
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold font-serif text-emerald-700">
              ₹{reportData.financials.totalRevenue.toLocaleString('en-IN')}
            </span>
          </div>
          <p className="text-[11px] text-gray-500 pt-2">
            Pending Receivables: <strong className="text-amber-600">₹{reportData.financials.pendingReceivables.toLocaleString('en-IN')}</strong>
          </p>
          <p className="text-[10px] text-gray-400">
            Net Margin: ₹{reportData.financials.netMargin.toLocaleString('en-IN')} ({reportData.financials.netMarginPercent}%)
          </p>
        </div>
      </div>

      {/* Analytics Breakdown Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Lead Stage Funnel */}
        <div className="bg-white p-6 rounded-2xl border border-gray-200/80 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-gray-100 pb-3">
            <h3 className="text-base font-serif font-bold text-[#0F0F0F]">Pipeline Conversion Funnel</h3>
            <span className="text-xs text-gray-500 font-medium">{reportData.leads.total} total prospects</span>
          </div>

          <div className="space-y-3 text-xs">
            {[
              { label: 'New / Untouched', count: reportData.leads.new, color: 'bg-sky-500' },
              { label: 'Contacted Outreach', count: reportData.leads.contacted, color: 'bg-indigo-500' },
              { label: 'Follow-up Discussion', count: reportData.leads.followUp, color: 'bg-amber-500' },
              { label: 'Site Visit / Laser Measurement', count: reportData.leads.siteVisit, color: 'bg-purple-500' },
              { label: '3D Quotation & BOQ Shared', count: reportData.leads.quotation, color: 'bg-[#C8A96A]' },
              { label: 'Won & Executing (Signed)', count: reportData.leads.won, color: 'bg-emerald-600' },
              { label: 'Lost / Closed Without Deal', count: reportData.leads.lost, color: 'bg-rose-500' },
            ].map(stage => {
              const pct = reportData.leads.total > 0 
                ? Math.round((stage.count / reportData.leads.total) * 100) 
                : 0;

              return (
                <div key={stage.label} className="space-y-1">
                  <div className="flex justify-between items-center text-[11px]">
                    <span className="font-semibold text-gray-700">{stage.label}</span>
                    <span className="text-gray-500">
                      <strong>{stage.count}</strong> ({pct}%)
                    </span>
                  </div>
                  <div className="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
                    <div className={`${stage.color} h-full rounded-full transition-all`} style={{ width: `${pct}%` }}></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Service Demand & Locality Distribution */}
        <div className="bg-white p-6 rounded-2xl border border-gray-200/80 shadow-sm space-y-5">
          <div className="flex items-center justify-between border-b border-gray-100 pb-3">
            <h3 className="text-base font-serif font-bold text-[#0F0F0F]">Service Demand Breakdown</h3>
            <span className="text-xs text-[#8E733E] font-semibold">Dehradun Focus</span>
          </div>

          {/* Services List */}
          <div className="space-y-2.5 text-xs">
            {Object.keys(reportData.serviceBreakdown).length === 0 ? (
              <p className="text-gray-400 text-center py-4">No service data in this timeframe.</p>
            ) : (
              Object.entries(reportData.serviceBreakdown).map(([svc, count]) => {
                const pct = reportData.leads.total > 0 
                  ? Math.round((count / reportData.leads.total) * 100) 
                  : 0;

                return (
                  <div key={svc} className="space-y-1">
                    <div className="flex justify-between items-center text-[11px]">
                      <span className="font-semibold text-gray-800">{svc}</span>
                      <span className="text-gray-500">{count} inquiries ({pct}%)</span>
                    </div>
                    <div className="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
                      <div className="bg-[#C8A96A] h-full rounded-full" style={{ width: `${pct}%` }}></div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Top Localities Badges */}
          <div className="pt-2 border-t border-gray-100">
            <h4 className="text-xs font-bold text-gray-700 uppercase tracking-wider mb-2">Prime Locality Inquiries</h4>
            <div className="flex flex-wrap gap-1.5">
              {Object.entries(reportData.localityBreakdown).slice(0, 8).map(([loc, cnt]) => (
                <span
                  key={loc}
                  className="bg-neutral-100 text-neutral-700 px-2.5 py-1 rounded-full text-[11px] font-medium"
                >
                  {loc}: <strong>{cnt}</strong>
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Filtered Registry Previews */}
      <div className="bg-white p-6 rounded-2xl border border-gray-200/80 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-serif font-bold text-[#0F0F0F]">Filtered Projects in Reporting Scope</h3>
            <p className="text-xs text-gray-500">Live projects active during {reportData.rangeLabel}.</p>
          </div>
          <span className="text-xs font-semibold text-gray-500">{reportData.filteredProjects.length} projects</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-neutral-50 text-gray-500 font-semibold uppercase text-[10px] tracking-wider border-b border-gray-200">
                <th className="py-2.5 px-3">Code / ID</th>
                <th className="py-2.5 px-3">Client</th>
                <th className="py-2.5 px-3">Locality</th>
                <th className="py-2.5 px-3">Type</th>
                <th className="py-2.5 px-3">Phase</th>
                <th className="py-2.5 px-3 text-right">Contract Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 text-gray-700">
              {reportData.filteredProjects.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-6 text-gray-400">
                    No project records in this period.
                  </td>
                </tr>
              ) : (
                reportData.filteredProjects.map(p => (
                  <tr key={p.id || p.projectCode} className="hover:bg-neutral-50">
                    <td className="py-2.5 px-3 font-mono font-semibold text-gray-900">{p.projectCode || p.id}</td>
                    <td className="py-2.5 px-3 font-medium">{p.clientName || 'Client'}</td>
                    <td className="py-2.5 px-3">{p.clientLocality || 'Dehradun'}</td>
                    <td className="py-2.5 px-3">{p.projectType || 'Modular Kitchen'}</td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded bg-gray-100 text-gray-700 text-[10px] font-semibold">
                        {p.currentPhase || 'Planning'}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono font-bold text-gray-900">
                      ₹{parseFloat(String(p.contractAmount).replace(/[^0-9.]/g, '') || '0').toLocaleString('en-IN')}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
