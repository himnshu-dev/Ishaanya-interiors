// @ts-nocheck
import React, { useState, useEffect } from 'react';
import { 
  Phone, 
  Mail, 
  MapPin, 
  Calendar, 
  Clock, 
  Check, 
  CheckCircle2, 
  ShieldCheck, 
  Sparkles, 
  Box, 
  Sliders, 
  ChevronRight, 
  ArrowRight, 
  ChevronDown, 
  Layers, 
  Award, 
  MessageSquare, 
  Menu, 
  X, 
  Star,
  Compass,
  Hammer,
  Eye,
  Maximize2,
  Wrench,
  Shield,
  Droplets,
  Cpu,
  Send,
  Loader2
} from 'lucide-react';
import { ThreeKitchenConfigurator } from './ThreeKitchenConfigurator';
import { KitchenGalleryModal, GalleryItem } from './KitchenGalleryModal';

interface IshaanyaLuxuryWebsiteProps {
  onOpen3DConfigurator?: (pkg?: string) => void;
  onOpenBookingModal?: (prefill?: any) => void;
  onOpenPackagesModal?: () => void;
}

export const IshaanyaLuxuryWebsite: React.FC<IshaanyaLuxuryWebsiteProps> = ({
  onOpen3DConfigurator,
  onOpenBookingModal,
  onOpenPackagesModal
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [selectedGalleryItem, setSelectedGalleryItem] = useState<GalleryItem | null>(null);
  const [galleryFilter, setGalleryFilter] = useState<'all' | 'l-shape' | 'parallel' | 'island' | 'peninsula' | 'cabinetry'>('all');
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);
  
  // Inquiry form state
  const [formState, setFormState] = useState({
    name: '',
    phone: '',
    locality: 'Rajpur Road',
    service: 'Modular Kitchen (Bespoke 3D Design)',
    preferred_date: '',
    notes: ''
  });
  const [formSubmitting, setFormSubmitting] = useState(false);
  const [formSuccess, setFormSuccess] = useState(false);

  const COMPANY_PHONE = '+919068377690';
  const COMPANY_PHONE_DISPLAY = '+91 90683 77690';
  const COMPANY_EMAIL = 'contact.ishaanya.interiors@gmail.com';
  const FOUNDER_NAME = 'Himanshu Kanswal';

  // Exact Manus Uploaded Kitchen Photographs & Layout Realizations
  const GALLERY_ITEMS: GalleryItem[] = [
    {
      id: 'gal-lshape-1',
      title: 'High-Gloss Quartz L-Shaped Modular Kitchen',
      category: 'l-shape',
      imageUrl: '/images/lshape-kitchen.png',
      location: 'Jakhan, Dehradun',
      packageTag: 'royale',
      finishType: '2mm Seamless Optical Acrylic',
      description: 'Corner-optimized ergonomic L-shaped kitchen featuring Blum tandem drawers, concealed LED profile channels, tall pantry unit, and quartz countertop.'
    },
    {
      id: 'gal-island-1',
      title: 'Architectural Central Island & Breakfast Bar Suite',
      category: 'island',
      imageUrl: '/images/island-kitchen.jpg',
      location: 'Mussoorie Road Villa, Dehradun',
      packageTag: 'imperial',
      finishType: 'Natural Walnut Veneer & Super-Matte PU',
      description: 'Monumental central island with waterfall quartz countertop, integrated hob with downdraft ventilation, and under-counter warm LED accent lighting.'
    },
    {
      id: 'gal-parallel-1',
      title: 'Professional Chef Parallel Galley Kitchen',
      category: 'parallel',
      imageUrl: '/images/parallel-galley-kitchen.jpg',
      location: 'Vasant Vihar, Dehradun',
      packageTag: 'essential',
      finishType: '1mm High-Pressure Anti-Scratch Laminate',
      description: 'Dual-counter galley kitchen with clear separation of wet preparation and hot cooking zones. Built with 100% BWP Marine IS:710 plywood.'
    },
    {
      id: 'gal-peninsula-1',
      title: 'Modern Peninsula Kitchen with Casual Dining Bar',
      category: 'peninsula',
      imageUrl: '/images/peninsula-kitchen.jpg',
      location: 'Sahastradhara Road, Dehradun',
      packageTag: 'royale',
      finishType: 'Champagne Metallic Acrylic & Black Granite',
      description: 'Fluid peninsula layout seamlessly dividing cooking and open living spaces. Equipped with Hettich InnoTech soft-close drawer organizers.'
    },
    {
      id: 'gal-imperial-1',
      title: 'Bespoke Imperial Italian PU Lacquer Kitchen',
      category: 'island',
      imageUrl: '/images/bespoke_imperial_kitchen.jpg',
      location: 'Rajpur Road Enclave, Dehradun',
      packageTag: 'imperial',
      finishType: '7-Layer Italian Monolithic PU Lacquer',
      description: 'Monochrome cashmere and silk-matte black cabinetry with motorized touch-open Blum Aventos bi-fold lift-ups and Statuario quartz.'
    },
    {
      id: 'gal-lshape-2',
      title: 'Nordic Minimalist Pure White L-Shaped Suite',
      category: 'l-shape',
      imageUrl: '/images/essential-01.jpg',
      location: 'Dalanwala, Dehradun',
      packageTag: 'royale',
      finishType: 'High-Gloss Pearl Acrylic with Gola Profile',
      description: 'Handleless minimalist cabinetry with integrated chimney niche, corner magic carousel, and moisture-resistant PUR edge-banding.'
    },
    {
      id: 'gal-parallel-2',
      title: 'Warm Scandinavian Parallel Kitchen Suite',
      category: 'parallel',
      imageUrl: '/images/parallel-kitchen.jpg',
      location: 'Canal Road, Dehradun',
      packageTag: 'essential',
      finishType: 'High-Pressure Matte Woodgrain Laminate',
      description: 'Deep woodgrain texture matched with crisp ivory overhead storage, spice rack pull-outs, and durable stainless steel 304 baskets.'
    },
    {
      id: 'gal-tv-1',
      title: 'Bespoke Fluted Living Room TV Unit & Console',
      category: 'cabinetry',
      imageUrl: '/images/luxury_tv_unit.jpg',
      location: 'Pacific Golf Estate, Dehradun',
      packageTag: 'imperial',
      finishType: 'Architectural Charcoal Fluting & Brass Trims',
      description: 'Integrated living room entertainment console with floating marble-look ledge, acoustic fluted backing, and concealed cable management.'
    },
    {
      id: 'gal-wall-1',
      title: 'Architectural Acoustic Wall Paneling & Louvers',
      category: 'cabinetry',
      imageUrl: '/images/luxury_wall_panels.jpg',
      location: 'EC Road Residence, Dehradun',
      packageTag: 'imperial',
      finishType: 'Precision CNC Veneered Acoustic Louvers',
      description: 'Custom-crafted luxury wall cladding with integrated warm ambient backlighting for master suites and modern living areas.'
    }
  ];

  const filteredGallery = galleryFilter === 'all' 
    ? GALLERY_ITEMS 
    : GALLERY_ITEMS.filter(item => {
        if (galleryFilter === 'l-shape') return item.category === 'l-shape';
        if (galleryFilter === 'parallel') return item.category === 'parallel';
        if (galleryFilter === 'island') return item.category === 'island';
        if (galleryFilter === 'peninsula') return item.category === 'peninsula';
        if (galleryFilter === 'cabinetry') return item.category === 'cabinetry';
        return true;
      });

  // Exact 9 Steps from Manus
  const MANUS_9_STEPS = [
    {
      step: '01',
      title: 'Consultation',
      desc: 'Initial lifestyle and cooking habit discovery with founder Himanshu Kanswal or senior design consultant.'
    },
    {
      step: '02',
      title: 'Site Visit & Measurement',
      desc: 'Comprehensive millimeter laser measurement of your kitchen walls, civil openings, plumbing lines, and electrical conduits.'
    },
    {
      step: '03',
      title: 'Kitchen Planning',
      desc: 'Ergonomic layout zoning (cooking, washing, storage) optimized for workflow and kitchen geometry.'
    },
    {
      step: '04',
      title: '2D/3D Design',
      desc: 'Architectural elevations and photorealistic 3D visual renders allowing you to experience materials, lighting, and finishes.'
    },
    {
      step: '05',
      title: 'Material & Finish Selection',
      desc: 'Hands-on selection of BWR/HDHMR substrates, shutters (Laminate, Acrylic, PU), countertops, and German fittings.'
    },
    {
      step: '06',
      title: 'Factory-Made Execution',
      desc: 'Precision modular fabrication using calibrated CNC panel saws, multi-bore joinery, and PUR edge banding.'
    },
    {
      step: '07',
      title: 'Delivery',
      desc: 'Secure flat-packed transit directly to your Dehradun residence with protective bubble wrapping and corner guards.'
    },
    {
      step: '08',
      title: 'Installation',
      desc: 'Structured on-site installation by experienced technicians, ensuring level alignment and clean fitment.'
    },
    {
      step: '09',
      title: 'Final Inspection & Handover',
      desc: 'Comprehensive hardware calibration, alignment check, handover documentation, and walkthrough.'
    }
  ];

  // Exact 4 Climate-Proof Engineering Pillars from Manus
  const ENGINEERING_PILLARS = [
    {
      title: 'Moisture-Resistant Materials',
      icon: Droplets,
      desc: 'We prioritize high-grade BWP Marine Ply (IS:710) and Grade-1 HDHMR for carcass durability, engineered to resist moisture and dampness during Dehradun monsoons.'
    },
    {
      title: 'Anti-Termite Protection',
      icon: Shield,
      desc: "Dehradun's climate requires proactive protection against wood-boring pests. We select treated boards with high borer and termite resistance."
    },
    {
      title: 'PUR Edge Sealing',
      icon: Layers,
      desc: 'Hot-melt PUR edge banding creates a tight moisture barrier along panel edges, helping prevent moisture ingress from steam and everyday cooking.'
    },
    {
      title: 'Precision CNC Fabrication',
      icon: Cpu,
      desc: 'Crafted with calibrated CNC precision and factory-made execution. Pre-drilled panels arrive flat-packed for efficient, organized on-site assembly.'
    }
  ];

  // Exact 10 FAQ Items from Manus
  const MANUS_FAQS = [
    {
      q: 'How does Ishaanya Interiors plan and customize a modular kitchen?',
      a: 'Every modular kitchen is custom-engineered based on your room dimensions, layout (L-shaped, U-shaped, parallel, island), selected finish (high-pressure laminate, seamless acrylic, or luxury PU), and internal fittings (Hettich or Blum). Ishaanya Interiors provides transparent, itemized BOQs with zero hidden charges following a complimentary site visit.'
    },
    {
      q: 'How are modular kitchen packages structured?',
      a: 'We offer three tailored kitchen finish collections: Essential Luxury (Laminate), Premium Royale (Acrylic), and Bespoke Imperial (Super Matte PU). Each collection includes factory-made fabrication, 100% moisture-resistant core materials, precision edge-banding, and soft-close German hardware.'
    },
    {
      q: 'How long does a modular kitchen take?',
      a: 'From the final sign-off of 2D/3D design drawings and site measurements, precision modular fabrication is carried out off-site, followed by clean, structured on-site installation at your Dehradun home with clear milestone updates.'
    },
    {
      q: 'Do you provide site measurement in Dehradun?',
      a: 'Yes. We provide complimentary on-site measurement across Dehradun including Rajpur Road, Jakhan, Vasant Vihar, Sahastradhara Road, Balliwala, Prem Nagar, Clement Town, and surrounding sectors. Our team uses precision laser measuring tools to record exact civil, electrical, and plumbing dimensions.'
    },
    {
      q: 'Do you provide 2D/3D kitchen design?',
      a: 'Yes. Every homeowner receives detailed 2D layout planning and photorealistic 3D kitchen design renders before factory-made execution begins. This allows you to preview colours, storage configurations, appliance cutouts, and lighting with complete clarity.'
    },
    {
      q: 'What materials and finishes are available?',
      a: 'We use 100% Boiling Waterproof (BWP IS:710) Marine Plywood and Grade-1 High-Density Moisture-Resistant (HDHMR) boards for carcasses to withstand Dehradun mountain humidity. Available shutter finishes include High-Pressure Gloss Laminate, Anti-Scratch High-Gloss Acrylic, and Super Matte PU Lacquer. Countertops include Jet Black Granite, Quartz, and Nanowhite.'
    },
    {
      q: 'Do you provide delivery and installation?',
      a: 'Yes. Ishaanya Interiors handles end-to-end delivery and professional on-site installation anywhere in Dehradun and Uttarakhand. Our trained assembly technicians mount, level, align, and calibrate all soft-close hinges, drawer runners, and accessories.'
    },
    {
      q: 'Can I customise the kitchen layout?',
      a: 'Absolutely. Every kitchen is custom-engineered to your civil space. We design L-shaped, U-shaped, Parallel (galley), Straight-line, and Island kitchen configurations with tailored heights, tall pantry units, corner carousels, and integrated chimney/hob niches.'
    },
    {
      q: 'What is the difference between laminate, acrylic and PU finish?',
      a: 'Laminate is cost-effective, durable, scratch-resistant, and low maintenance. Acrylic offers a glass-like high-gloss reflection with rich color depth and UV stability. PU (Polyurethane) is a seamless lacquer finish that delivers a luxurious silky matte or high-gloss texture with zero visible edge joints.'
    },
    {
      q: 'How can I book a modular kitchen consultation?',
      a: 'You can book a free consultation by submitting the form on our website, calling founder Himanshu Kanswal directly at +91 90683 77690, or messaging us on WhatsApp. We will schedule a convenient doorstep site visit anywhere in Dehradun.'
    }
  ];

  // Exact Dehradun Localities from Manus
  const DEHRADUN_LOCALITIES = [
    'Dehradun', 'Rajpur Road', 'Vasant Vihar', 'Balliwala', 'Prem Nagar', 
    'Sudhowala', 'Bhauwala', 'Shimla Bypass', 'Dalanwala', 'Clement Town', 
    'Sahastradhara Road', 'IT Park', 'Jakhan', 'GMS Road', 'Chakrata Road'
  ];

  const handleLaunch3D = (pkg = 'royale') => {
    if (onOpen3DConfigurator) onOpen3DConfigurator(pkg);
    else if (window.open3DConfigurator) window.open3DConfigurator(pkg);
  };

  const handleBookVisit = (prefill = {}) => {
    if (onOpenBookingModal) onOpenBookingModal(prefill);
    else if (window.openKitchenBooking) window.openKitchenBooking(prefill);
  };

  const handleOpenPackages = () => {
    if (onOpenPackagesModal) onOpenPackagesModal();
    else if (window.openPackageCollections) window.openPackageCollections();
  };

  const handleInquirySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formState.phone.trim()) return;

    setFormSubmitting(true);
    try {
      const res = await fetch('/api/inquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: formState.name || 'Valued Homeowner',
          phone: formState.phone,
          locality: formState.locality,
          service: formState.service,
          preferred_date: formState.preferred_date || null,
          notes: formState.notes,
          source: 'website_manus_showroom',
          landing_page: window.location.pathname
        })
      });

      if (res.ok) {
        setFormSuccess(true);
      }
    } catch (err) {
      console.error('Error submitting inquiry:', err);
    } finally {
      setFormSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-[#F5F5F5] font-sans selection:bg-[#C8A96A] selection:text-black">
      {/* 1. STICKY LUXURY SHOWROOM NAVBAR */}
      <header className="sticky top-0 z-50 bg-[#0A0A0A]/95 backdrop-blur-md border-b border-white/10 transition-all duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          {/* Brand Logo & Name */}
          <a href="/" className="flex items-center gap-3.5 group cursor-pointer">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[#1C1A14] to-[#121215] border border-[#C8A96A]/60 flex items-center justify-center p-2 shadow-lg shadow-[#C8A96A]/10 group-hover:border-[#C8A96A] transition-all">
              <img 
                src="/images/ishaanya_logo_dark.svg" 
                alt="Ishaanya Interiors" 
                className="w-full h-full object-contain"
                onError={(e: any) => {
                  e.target.src = '/images/ishaanya_logo.svg';
                }}
              />
            </div>
            <div>
              <span className="text-lg sm:text-xl font-serif font-bold tracking-wider text-white group-hover:text-[#F3E5AB] transition-colors block leading-tight">
                ISHAANYA INTERIORS
              </span>
              <span className="text-[10px] tracking-[0.2em] uppercase text-[#C8A96A] font-medium block">
                DEHRADUN • BESPOKE KITCHEN STUDIO
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-7 text-xs font-medium text-gray-300">
            <a href="/" className="hover:text-[#C8A96A] transition-colors">Home</a>
            <a href="/modular-kitchen-dehradun" className="hover:text-[#C8A96A] transition-colors flex items-center gap-1.5 text-white">
              <span>Modular Kitchen</span>
              <span className="text-[9px] font-bold uppercase tracking-wider text-[#0F0F0F] bg-[#C8A96A] px-1.5 py-0.2 rounded">
                Dehradun
              </span>
            </a>
            <a href="#kitchen-3d-configurator" className="hover:text-[#C8A96A] transition-colors flex items-center gap-1.5 text-white">
              <span className="w-1.5 h-1.5 rounded-full bg-[#C8A96A] animate-ping" />
              <span>3D Configurator</span>
            </a>
            <a href="#kitchen-packages" className="hover:text-[#C8A96A] transition-colors">Packages</a>
            <a href="#kitchen-gallery" className="hover:text-[#C8A96A] transition-colors">Kitchen Designs</a>
            <a href="#kitchen-process" className="hover:text-[#C8A96A] transition-colors">9-Step Process</a>
            <a href="#kitchen-engineering" className="hover:text-[#C8A96A] transition-colors">Engineering</a>
            <a href="#kitchen-inquiry" className="hover:text-[#C8A96A] transition-colors">Contact</a>
          </nav>

          {/* Header Action Buttons */}
          <div className="hidden sm:flex items-center gap-3">
            <a
              href={`tel:${COMPANY_PHONE}`}
              className="px-3.5 py-2 rounded-xl bg-neutral-900 border border-white/10 text-xs font-semibold text-gray-300 hover:text-white hover:border-[#C8A96A]/50 transition-all flex items-center gap-2"
            >
              <Phone className="w-3.5 h-3.5 text-[#C8A96A]" />
              <span className="hidden xl:inline">{COMPANY_PHONE_DISPLAY}</span>
            </a>

            <button
              onClick={() => handleBookVisit({})}
              className="px-5 py-2.5 rounded-xl gold-gradient-bg text-black font-bold text-xs tracking-wider uppercase transition-all hover:brightness-110 shadow-lg shadow-[#C8A96A]/20 cursor-pointer"
            >
              Book Site Visit
            </button>
          </div>

          {/* Mobile Hamburger Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 text-gray-300 hover:text-white rounded-lg focus:outline-none"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Slide-Down Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-[#0F0F0F] border-b border-white/10 px-6 py-6 space-y-4">
            <nav className="flex flex-col space-y-3 text-sm font-medium text-gray-300">
              <a href="/" onClick={() => setMobileMenuOpen(false)} className="hover:text-[#C8A96A] py-1">
                Home
              </a>
              <a href="/modular-kitchen-dehradun" onClick={() => setMobileMenuOpen(false)} className="hover:text-[#C8A96A] py-1 flex items-center justify-between">
                <span>Modular Kitchen in Dehradun</span>
                <span className="text-[10px] font-bold text-black bg-[#C8A96A] px-2 py-0.5 rounded">Featured</span>
              </a>
              <a href="#kitchen-3d-configurator" onClick={() => setMobileMenuOpen(false)} className="hover:text-[#C8A96A] py-1 flex items-center gap-2 text-white font-semibold">
                <Box className="w-4 h-4 text-[#C8A96A]" />
                <span>3D Kitchen Configurator</span>
              </a>
              <a href="#kitchen-packages" onClick={() => setMobileMenuOpen(false)} className="hover:text-[#C8A96A] py-1">
                Kitchen Packages (Laminate, Acrylic, PU)
              </a>
              <a href="#kitchen-gallery" onClick={() => setMobileMenuOpen(false)} className="hover:text-[#C8A96A] py-1">
                Kitchen Designs & Photographs
              </a>
              <a href="#kitchen-process" onClick={() => setMobileMenuOpen(false)} className="hover:text-[#C8A96A] py-1">
                Our 9-Step Process
              </a>
              <a href="#kitchen-engineering" onClick={() => setMobileMenuOpen(false)} className="hover:text-[#C8A96A] py-1">
                Climate-Proof Engineering
              </a>
              <a href="#kitchen-inquiry" onClick={() => setMobileMenuOpen(false)} className="hover:text-[#C8A96A] py-1">
                Book Consultation
              </a>
              <a href="/owner" onClick={() => setMobileMenuOpen(false)} className="text-xs text-neutral-500 hover:text-neutral-400 py-1 pt-2 border-t border-white/10">
                Owner Portal Access
              </a>
            </nav>

            <div className="pt-4 border-t border-white/10 flex flex-col gap-2.5">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  handleBookVisit({});
                }}
                className="w-full py-3 rounded-xl gold-gradient-bg text-black font-bold text-xs uppercase tracking-wider"
              >
                Book Free Consultation
              </button>

              <a
                href={`tel:${COMPANY_PHONE}`}
                className="w-full py-2.5 rounded-xl bg-neutral-900 text-gray-300 font-medium text-xs flex items-center justify-center gap-2 border border-white/10"
              >
                <Phone className="w-3.5 h-3.5 text-[#C8A96A]" />
                <span>Call Himanshu Kanswal ({COMPANY_PHONE_DISPLAY})</span>
              </a>
            </div>
          </div>
        )}
      </header>

      <main>
        {/* 2. EXACT MANUS FULL-BLEED LUXURY KITCHEN HERO SECTION */}
        <section id="kitchen-hero" className="relative min-h-[85vh] sm:min-h-[92vh] flex items-center justify-center overflow-hidden pt-12 pb-20">
          {/* Full-bleed Luxury Kitchen Hero Image from Uploaded Assets */}
          <div className="absolute inset-0 z-0">
            <img
              src="/images/ishaanya_luxury_hero.jpg"
              alt="Bespoke Luxury Modular Kitchen in Dehradun"
              className="w-full h-full object-cover object-center scale-105 filter brightness-85 contrast-105"
            />
            {/* Dramatic Dark Showroom Vignette & Radial Gold Glow */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A] via-[#0A0A0A]/75 to-[#0A0A0A]/40" />
            <div className="absolute inset-0 bg-gradient-to-r from-[#0A0A0A] via-[#0A0A0A]/70 to-transparent" />
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_25%_35%,rgba(200,169,106,0.18)_0%,transparent_65%)] pointer-events-none" />
          </div>

          {/* Hero Content */}
          <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6 sm:space-y-8">
            {/* Top Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#1A1813]/90 border border-[#C8A96A]/60 text-[#C8A96A] text-xs font-semibold uppercase tracking-widest backdrop-blur-md shadow-2xl">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Modular Kitchen Design & Execution in Dehradun</span>
            </div>

            {/* Main Headline (Cormorant Garamond) */}
            <h1 className="text-4xl sm:text-6xl md:text-7xl font-serif font-bold text-white tracking-tight leading-[1.1] max-w-4xl mx-auto drop-shadow-2xl">
              Modular Kitchen in Dehradun
            </h1>

            {/* Subheading (Poppins) */}
            <p className="text-sm sm:text-base md:text-lg text-gray-200 max-w-3xl mx-auto font-normal leading-relaxed drop-shadow">
              Custom-designed and factory-manufactured modular kitchens for Dehradun residences. Built with <span className="text-white font-semibold">100% Boiling Waterproof Marine Plywood (IS:710)</span>, German soft-close fittings (Blum & Hettich), and durable climate-proof engineering by founder Himanshu Kanswal.
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 pt-2">
              <button
                onClick={() => handleBookVisit({})}
                className="w-full sm:w-auto px-8 py-4 rounded-xl gold-gradient-bg text-black font-bold text-xs sm:text-sm tracking-wider uppercase transition-all hover:brightness-110 shadow-2xl shadow-[#C8A96A]/30 cursor-pointer flex items-center justify-center gap-2.5"
              >
                <Calendar className="w-4 h-4" />
                <span>Book Free On-Site Consultation</span>
              </button>

              <a
                href="#kitchen-3d-configurator"
                className="w-full sm:w-auto px-7 py-4 rounded-xl bg-[#141419]/90 hover:bg-[#1C1C24] text-white border border-[#C8A96A]/60 hover:border-[#C8A96A] font-semibold text-xs sm:text-sm backdrop-blur-md transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <Box className="w-4 h-4 text-[#C8A96A]" />
                <span>Explore 3D Kitchen Studio</span>
              </a>

              <a
                href={`tel:${COMPANY_PHONE}`}
                className="w-full sm:w-auto px-6 py-4 rounded-xl bg-neutral-900/80 hover:bg-neutral-800 text-gray-300 font-medium text-xs sm:text-sm border border-white/10 transition-colors flex items-center justify-center gap-2"
              >
                <Phone className="w-4 h-4 text-[#C8A96A]" />
                <span>Call Himanshu ({COMPANY_PHONE_DISPLAY})</span>
              </a>
            </div>

            {/* Quick Trust Badges */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 pt-6 max-w-4xl mx-auto border-t border-white/10 text-left">
              <div className="p-3.5 rounded-xl bg-black/50 backdrop-blur border border-white/10 flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#C8A96A] shrink-0" />
                <div>
                  <div className="text-xs font-bold text-white">8+ Years Experience</div>
                  <div className="text-[10px] text-gray-400">150+ Handed Over</div>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-black/50 backdrop-blur border border-white/10 flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#C8A96A] shrink-0" />
                <div>
                  <div className="text-xs font-bold text-white">100% Waterproof</div>
                  <div className="text-[10px] text-gray-400">BWP IS:710 Marine Ply</div>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-black/50 backdrop-blur border border-white/10 flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#C8A96A] shrink-0" />
                <div>
                  <div className="text-xs font-bold text-white">German Fittings</div>
                  <div className="text-[10px] text-gray-400">Blum & Hettich Systems</div>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-black/50 backdrop-blur border border-white/10 flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#C8A96A] shrink-0" />
                <div>
                  <div className="text-xs font-bold text-white">10-Year Warranty</div>
                  <div className="text-[10px] text-gray-400">Branded Hardware</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 3. FOUNDER & PERSONAL SUPERVISION SECTION */}
        <section id="kitchen-founder" className="py-16 sm:py-20 bg-[#0F0F0F] text-white border-y border-white/5">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="bg-[#14120E] rounded-2xl border border-[#C8A96A]/40 p-8 sm:p-12 flex flex-col md:flex-row items-center gap-8 shadow-2xl">
              <div className="w-36 h-36 sm:w-44 sm:h-44 rounded-2xl overflow-hidden shrink-0 border-2 border-[#C8A96A] shadow-2xl">
                <img
                  src="/images/himanshu_kanswal_founder.jpg"
                  alt="Himanshu Kanswal, Founder of Ishaanya Interiors"
                  className="w-full h-full object-cover object-top"
                  onError={(e: any) => {
                    e.target.src = '/images/assets/himanshu_kanswal_founder.jpg';
                  }}
                />
              </div>

              <div className="space-y-4 text-center md:text-left">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#C8A96A]/20 text-[#C8A96A] text-xs font-semibold uppercase tracking-wider">
                  <span>Founder's Direct Commitment</span>
                </div>

                <h3 className="text-2xl sm:text-3xl font-serif font-bold text-white">
                  "Every kitchen in Dehradun is engineered as if it were for my own family."
                </h3>

                <p className="text-xs sm:text-sm text-gray-300 leading-relaxed">
                  I founded Ishaanya Interiors in Dehradun to eliminate middleman markups, poor-quality particle boards that rot in monsoon humidity, and unaccountable local carpenters. By combining 100% genuine BWP Marine Grade IS:710 plywood with German hardware and off-site CNC factory fabrication, we deliver luxury modular kitchens built to endure mountain climates.
                </p>

                <div className="pt-2 flex flex-wrap items-center justify-center md:justify-start gap-4 text-xs text-gray-300">
                  <span className="font-semibold text-white">Himanshu Kanswal</span>
                  <span className="text-[#C8A96A]">•</span>
                  <span>Founder & Managing Director</span>
                  <span className="text-[#C8A96A]">•</span>
                  <span>Dehradun, Uttarakhand</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 4. EMBEDDED THREE.JS 3D KITCHEN CONFIGURATOR (MATCHING MANUS LUXURY DESIGN) */}
        <section id="kitchen-3d-configurator" className="py-20 bg-[#0A0A0A] text-white relative border-b border-white/5">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto mb-10 space-y-3">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#C8A96A]/15 border border-[#C8A96A]/40 text-[#C8A96A] text-xs font-semibold uppercase tracking-wider">
                <Box className="w-3.5 h-3.5" />
                <span>Interactive 3D Kitchen Configurator</span>
              </div>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif font-semibold text-white">
                Configure Your Dream Kitchen in Real-Time 3D
              </h2>
              <p className="text-xs sm:text-sm text-gray-300 max-w-2xl mx-auto leading-relaxed">
                Rotate 360°, inspect cabinetry internals, customize finishes (Laminate, Acrylic, Italian PU), select Statuario Quartz countertops, and calculate an estimated quotation for your Dehradun home.
              </p>
            </div>

            {/* Embedded Live 3D Studio Canvas */}
            <div className="rounded-2xl overflow-hidden border border-[#C8A96A]/30 shadow-2xl bg-[#0F0F0F]">
              <ThreeKitchenConfigurator
                initialLayout="l-shape"
                initialPackage="royale"
                onBookDesign={(config) => handleBookVisit({
                  notes: `3D Configurator Selection: ${config.layout.toUpperCase()} Layout, ${config.packageTier.toUpperCase()} Collection, Shutter: ${config.finishName}, Countertop: ${config.countertopName}, Est: ₹${config.estimatedPrice.toLocaleString('en-IN')}`
                })}
              />
            </div>
          </div>
        </section>

        {/* 5. EXACT MANUS PACKAGE COLLECTIONS SECTION */}
        <section id="kitchen-packages" className="py-20 bg-[#0F0F0F] text-white relative">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
              <span className="text-xs font-bold uppercase tracking-wider text-[#C8A96A] bg-white/5 border border-[#C8A96A]/30 px-3 py-1 rounded">
                Curated Collections
              </span>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif font-semibold text-white">
                Modular Kitchen Packages in Dehradun
              </h2>
              <p className="text-xs sm:text-sm text-gray-300 max-w-xl mx-auto leading-relaxed">
                Every package is engineered specifically to withstand the humidity and temperature variations of Dehradun's climate.
              </p>
            </div>

            {/* 3 Exact Manus Package Cards */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch">
              {/* Card 1: Essential Luxury */}
              <div className="rounded-2xl overflow-hidden transition-all duration-300 flex flex-col justify-between bg-[#14120E] border border-white/10 hover:border-[#C8A96A] shadow-md hover:shadow-xl">
                <div>
                  <div className="relative aspect-[16/10] overflow-hidden bg-black">
                    <img
                      src="/images/laminate-essential.jpg"
                      alt="Essential Luxury Modular Kitchen Dehradun"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                      onError={(e: any) => { e.target.src = '/images/essential-01.jpg'; }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" />
                    <div className="absolute top-3.5 left-3.5">
                      <span className="gold-gradient-bg text-[#0F0F0F] text-[10px] font-bold uppercase tracking-wider px-3 py-1 rounded-md shadow-md">
                        High-Pressure Laminate
                      </span>
                    </div>
                    <div className="absolute top-3.5 right-3.5">
                      <span className="bg-black/75 backdrop-blur-md text-white text-[10px] font-medium px-2.5 py-1 rounded border border-white/10">
                        Modular Precision
                      </span>
                    </div>
                  </div>

                  <div className="p-7 space-y-5">
                    <div>
                      <span className="text-[11px] font-bold uppercase tracking-widest px-2.5 py-0.5 rounded bg-white/10 text-gray-300">
                        Value & Durability
                      </span>
                      <h3 className="font-serif text-2xl font-semibold mt-2.5 text-white">
                        Essential Luxury
                      </h3>
                      <p className="text-xs sm:text-sm mt-2 text-gray-300 leading-relaxed">
                        Heavy-duty 1mm high-pressure laminates engineered for high resistance to heat, stains, and daily wear in Dehradun kitchens.
                      </p>
                    </div>

                    <div className="space-y-2.5 pt-2 border-t border-white/10">
                      <h4 className="text-xs font-serif font-semibold uppercase tracking-tight text-[#C8A96A]">
                        Package Specifications:
                      </h4>
                      <div className="space-y-2 text-xs text-gray-300">
                        <div className="flex items-start gap-2.5">
                          <Check className="w-4 h-4 text-[#C8A96A] shrink-0 mt-0.5" />
                          <span>100% Calibrated BWP Marine Ply (IS:710) carcass</span>
                        </div>
                        <div className="flex items-start gap-2.5">
                          <Check className="w-4 h-4 text-[#C8A96A] shrink-0 mt-0.5" />
                          <span>1mm High-Pressure Gloss Laminate shutters</span>
                        </div>
                        <div className="flex items-start gap-2.5">
                          <Check className="w-4 h-4 text-[#C8A96A] shrink-0 mt-0.5" />
                          <span>Hettich soft-close hinges & tandem box runners</span>
                        </div>
                        <div className="flex items-start gap-2.5">
                          <Check className="w-4 h-4 text-[#C8A96A] shrink-0 mt-0.5" />
                          <span>SS 304 anti-rust wire baskets & cutlery tray</span>
                        </div>
                        <div className="flex items-start gap-2.5">
                          <Check className="w-4 h-4 text-[#C8A96A] shrink-0 mt-0.5" />
                          <span>Up to 5-year hardware & material warranty</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-7 pt-0 space-y-4">
                  <div className="flex items-baseline justify-between border-t border-white/10 pt-4">
                    <span className="text-[10px] text-gray-400 uppercase">Starting From</span>
                    <span className="text-xl font-bold font-serif text-[#C8A96A]">₹1.45 Lakhs*</span>
                  </div>

                  <button
                    onClick={() => handleBookVisit({ package: 'Essential Luxury' })}
                    className="w-full py-3.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs sm:text-sm transition-all cursor-pointer shadow-md flex items-center justify-center gap-2"
                  >
                    <span>Get a Quote</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Card 2: Premium Royale (Featured in Manus Black & Gold) */}
              <div className="rounded-2xl overflow-hidden transition-all duration-300 flex flex-col justify-between relative bg-[#0F0F0F] text-white border-2 border-[#C8A96A] shadow-2xl shadow-[#C8A96A]/20 scale-[1.02] z-10">
                <div className="absolute top-0 right-0 bg-[#C8A96A] text-[#0F0F0F] text-[10px] font-bold uppercase tracking-widest px-4 py-1 rounded-bl-xl shadow-lg">
                  ★ Most Popular in Dehradun
                </div>

                <div>
                  <div className="relative aspect-[16/10] overflow-hidden bg-black">
                    <img
                      src="/images/acrylic-royale.webp"
                      alt="Premium Royale Acrylic Modular Kitchen Dehradun"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                      onError={(e: any) => { e.target.src = '/images/luxury_modular_kitchen.jpg'; }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" />
                    <div className="absolute top-3.5 left-3.5">
                      <span className="gold-gradient-bg text-[#0F0F0F] text-[10px] font-bold uppercase tracking-wider px-3 py-1 rounded-md shadow-md">
                        High-Gloss Acrylic
                      </span>
                    </div>
                  </div>

                  <div className="p-7 space-y-5">
                    <div>
                      <span className="text-[11px] font-bold uppercase tracking-widest px-2.5 py-0.5 rounded bg-white/10 text-[#C8A96A] border border-[#C8A96A]/30">
                        Glass Reflection Luxe
                      </span>
                      <h3 className="font-serif text-2xl font-semibold mt-2.5 text-white">
                        Premium Royale
                      </h3>
                      <p className="text-xs sm:text-sm mt-2 text-gray-300 leading-relaxed">
                        2mm seamless anti-scratch acrylic with glass-like gloss reflection, handleless Gola channels, and Blum tandem drawer systems.
                      </p>
                    </div>

                    <div className="space-y-2.5 pt-2 border-t border-white/10">
                      <h4 className="text-xs font-serif font-semibold uppercase tracking-tight text-[#C8A96A]">
                        Package Specifications:
                      </h4>
                      <div className="space-y-2 text-xs text-gray-200">
                        <div className="flex items-start gap-2.5">
                          <Check className="w-4 h-4 text-[#C8A96A] shrink-0 mt-0.5" />
                          <span>High-Density Moisture-Resistant (HDHMR Grade 1) carcass</span>
                        </div>
                        <div className="flex items-start gap-2.5">
                          <Check className="w-4 h-4 text-[#C8A96A] shrink-0 mt-0.5" />
                          <span>2mm Seamless Anti-Scratch Acrylic or Super Matte PU</span>
                        </div>
                        <div className="flex items-start gap-2.5">
                          <Check className="w-4 h-4 text-[#C8A96A] shrink-0 mt-0.5" />
                          <span>Blum Tandembox / Antaro soft-close drawer systems</span>
                        </div>
                        <div className="flex items-start gap-2.5">
                          <Check className="w-4 h-4 text-[#C8A96A] shrink-0 mt-0.5" />
                          <span>Corner solutions: Magic corner or carousel unit included</span>
                        </div>
                        <div className="flex items-start gap-2.5">
                          <Check className="w-4 h-4 text-[#C8A96A] shrink-0 mt-0.5" />
                          <span>10-year comprehensive warranty on branded hardware</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-7 pt-0 space-y-4">
                  <div className="flex items-baseline justify-between border-t border-white/10 pt-4">
                    <span className="text-[10px] text-gray-400 uppercase">Starting From</span>
                    <span className="text-xl font-bold font-serif text-[#C8A96A]">₹2.35 Lakhs*</span>
                  </div>

                  <button
                    onClick={() => handleBookVisit({ package: 'Premium Royale' })}
                    className="w-full py-3.5 rounded-xl gold-gradient-bg text-[#0F0F0F] font-bold text-xs sm:text-sm transition-all cursor-pointer shadow-lg hover:brightness-110 flex items-center justify-center gap-2"
                  >
                    <span>Get a Quote</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Card 3: Bespoke Imperial */}
              <div className="rounded-2xl overflow-hidden transition-all duration-300 flex flex-col justify-between bg-[#14120E] border border-white/10 hover:border-[#C8A96A] shadow-md hover:shadow-xl">
                <div>
                  <div className="relative aspect-[16/10] overflow-hidden bg-black">
                    <img
                      src="/images/bespoke_imperial_kitchen.jpg"
                      alt="Bespoke Imperial PU Lacquer Modular Kitchen Dehradun"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                      onError={(e: any) => { e.target.src = '/images/imperial-01.jpg'; }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" />
                    <div className="absolute top-3.5 left-3.5">
                      <span className="gold-gradient-bg text-[#0F0F0F] text-[10px] font-bold uppercase tracking-wider px-3 py-1 rounded-md shadow-md">
                        Veneer, PU & Fluted Glass
                      </span>
                    </div>
                    <div className="absolute top-3.5 right-3.5">
                      <span className="bg-black/75 backdrop-blur-md text-white text-[10px] font-medium px-2.5 py-1 rounded border border-white/10">
                        Villa Grade
                      </span>
                    </div>
                  </div>

                  <div className="p-7 space-y-5">
                    <div>
                      <span className="text-[11px] font-bold uppercase tracking-widest px-2.5 py-0.5 rounded bg-white/10 text-amber-200">
                        Architectural Ultra-Luxury
                      </span>
                      <h3 className="font-serif text-2xl font-semibold mt-2.5 text-white">
                        Bespoke Imperial
                      </h3>
                      <p className="text-xs sm:text-sm mt-2 text-gray-300 leading-relaxed">
                        7-layer Italian polyurethane (PU) lacquer, natural bookmatched veneers, motorized touch-open bi-folds, and Hafele profile lighting.
                      </p>
                    </div>

                    <div className="space-y-2.5 pt-2 border-t border-white/10">
                      <h4 className="text-xs font-serif font-semibold uppercase tracking-tight text-[#C8A96A]">
                        Package Specifications:
                      </h4>
                      <div className="space-y-2 text-xs text-gray-300">
                        <div className="flex items-start gap-2.5">
                          <Check className="w-4 h-4 text-[#C8A96A] shrink-0 mt-0.5" />
                          <span>Boiling Waterproof IS:710 Marine + HDHMR carcass</span>
                        </div>
                        <div className="flex items-start gap-2.5">
                          <Check className="w-4 h-4 text-[#C8A96A] shrink-0 mt-0.5" />
                          <span>Natural Teak/Walnut veneer with PU finish or fluted glass shutters</span>
                        </div>
                        <div className="flex items-start gap-2.5">
                          <Check className="w-4 h-4 text-[#C8A96A] shrink-0 mt-0.5" />
                          <span>Blum Legrabox / Hafele Matrix premium drawers</span>
                        </div>
                        <div className="flex items-start gap-2.5">
                          <Check className="w-4 h-4 text-[#C8A96A] shrink-0 mt-0.5" />
                          <span>Hafele Loox LED profile lighting system</span>
                        </div>
                        <div className="flex items-start gap-2.5">
                          <Check className="w-4 h-4 text-[#C8A96A] shrink-0 mt-0.5" />
                          <span>Lifetime warranty on Blum / Hafele movement systems</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-7 pt-0 space-y-4">
                  <div className="flex items-baseline justify-between border-t border-white/10 pt-4">
                    <span className="text-[10px] text-gray-400 uppercase">Starting From</span>
                    <span className="text-xl font-bold font-serif text-[#C8A96A]">₹3.85 Lakhs*</span>
                  </div>

                  <button
                    onClick={() => handleBookVisit({ package: 'Bespoke Imperial' })}
                    className="w-full py-3.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs sm:text-sm transition-all cursor-pointer shadow-md flex items-center justify-center gap-2"
                  >
                    <span>Get a Quote</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 6. EXACT MANUS KITCHEN DESIGN GALLERY (UPLOADED KITCHEN PHOTOGRAPHS) */}
        <section id="kitchen-gallery" className="py-20 bg-[#0A0A0A] text-white border-t border-white/5">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto mb-10 space-y-3">
              <span className="text-xs font-bold uppercase tracking-wider text-[#C8A96A] bg-white/5 border border-[#C8A96A]/30 px-3 py-1 rounded">
                Modular Kitchen Layouts
              </span>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif font-semibold text-white">
                Kitchen Designs in Dehradun
              </h2>
              <p className="text-xs sm:text-sm text-gray-300 max-w-2xl mx-auto leading-relaxed">
                Explore modular kitchen layout inspiration custom-engineered for Dehradun mountain climate with 100% boiling waterproof ply, German soft-close fittings, and bespoke finishes.
              </p>
            </div>

            {/* Layout Filter Tabs */}
            <div className="flex flex-wrap items-center justify-center gap-2 mb-10">
              {[
                { id: 'all', label: 'All Kitchen Designs' },
                { id: 'l-shape', label: 'L-Shaped Kitchen' },
                { id: 'parallel', label: 'Parallel Kitchen' },
                { id: 'island', label: 'Island Kitchen' },
                { id: 'peninsula', label: 'Peninsula Kitchen' },
                { id: 'cabinetry', label: 'Living & Wall Units' },
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setGalleryFilter(tab.id as any)}
                  className={`px-4 py-2 rounded-full text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                    galleryFilter === tab.id
                      ? 'gold-gradient-bg text-[#0F0F0F] font-bold shadow-md'
                      : 'bg-neutral-900 border border-white/10 text-gray-400 hover:text-white hover:border-white/20'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Exact Gallery Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredGallery.map((item, idx) => (
                <div
                  key={item.id || idx}
                  onClick={() => setSelectedGalleryItem(item)}
                  className="bg-[#14120E] rounded-2xl overflow-hidden border border-white/10 hover:border-[#C8A96A] shadow-md hover:shadow-2xl transition-all duration-300 flex flex-col group cursor-pointer"
                >
                  <div className="relative aspect-[16/11] overflow-hidden bg-black">
                    <img
                      src={item.imageUrl}
                      alt={`${item.title} - Ishaanya Interiors Dehradun`}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-70 group-hover:opacity-50 transition-opacity" />

                    <div className="absolute top-3 left-3 flex items-center gap-2">
                      <span className="bg-[#0F0F0F]/90 backdrop-blur-md text-[#C8A96A] text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded border border-[#C8A96A]/30">
                        {item.category.toUpperCase()}
                      </span>
                    </div>

                    <div className="absolute bottom-3 left-3 right-3 text-left">
                      <div className="flex items-center gap-1.5 text-[11px] text-[#C8A96A] mb-1 font-medium">
                        <MapPin className="w-3.5 h-3.5" />
                        <span>{item.location}</span>
                      </div>
                      <h4 className="text-base font-serif font-bold text-white group-hover:text-[#F3E5AB] transition-colors leading-snug">
                        {item.title}
                      </h4>
                    </div>
                  </div>

                  <div className="p-4 bg-[#14120E] flex items-center justify-between text-xs text-gray-400 border-t border-white/5">
                    <span className="truncate">{item.finishType}</span>
                    <span className="text-[#C8A96A] font-semibold flex items-center gap-1 shrink-0">
                      <span>View Specs</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* 7. EXACT MANUS 9-STEP MODULAR KITCHEN PROCESS */}
        <section id="kitchen-process" className="py-20 bg-[#0F0F0F] text-white border-t border-white/5">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
              <span className="text-xs font-bold uppercase tracking-wider text-[#C8A96A] bg-white/5 border border-[#C8A96A]/30 px-3 py-1 rounded">
                End-to-End Execution
              </span>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif font-semibold text-white">
                Our 9-Step Modular Kitchen Process
              </h2>
              <p className="text-xs sm:text-sm text-gray-300 max-w-xl mx-auto leading-relaxed">
                From your first consultation to final handover, every step follows strict quality protocols and transparent timelines.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {MANUS_9_STEPS.map((step) => (
                <div
                  key={step.step}
                  className="bg-[#14120E] border border-white/10 rounded-2xl p-6 space-y-3 hover:border-[#C8A96A]/50 transition-all shadow-md group"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-serif font-bold text-[#C8A96A]">
                      {step.step}
                    </span>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-gray-300 bg-white/10 px-2 py-0.5 rounded border border-white/10">
                      Step {step.step}
                    </span>
                  </div>

                  <h3 className="font-serif text-lg font-semibold text-white group-hover:text-[#F3E5AB] transition-colors">
                    {step.title}
                  </h3>

                  <p className="text-xs text-gray-300 leading-relaxed">
                    {step.desc}
                  </p>
                </div>
              ))}
            </div>

            <div className="mt-12 text-center">
              <button
                onClick={() => handleBookVisit({ notes: 'Modular Kitchen 9-Step Process Consultation' })}
                className="inline-flex items-center gap-2 gold-gradient-bg text-[#0F0F0F] font-bold text-xs sm:text-sm px-8 py-4 rounded-xl hover:brightness-110 shadow-xl transition-all cursor-pointer"
              >
                <Calendar className="w-4 h-4" />
                <span>Start Your Kitchen Project with Step 1</span>
              </button>
            </div>
          </div>
        </section>

        {/* 8. EXACT MANUS ENGINEERING EXCELLENCE SECTION */}
        <section id="kitchen-engineering" className="py-20 bg-[#0A0A0A] text-white border-t border-white/5">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mx-auto text-center space-y-3 mb-16">
              <span className="text-xs font-bold uppercase tracking-wider text-[#C8A96A] bg-black/60 border border-[#C8A96A]/30 px-3 py-1 rounded">
                Engineering Excellence
              </span>
              <h2 className="text-3xl sm:text-4xl font-serif font-semibold text-white">
                Why Dehradun Homes Need Climate-Proof Kitchens
              </h2>
              <p className="text-xs sm:text-sm text-gray-300 leading-relaxed">
                Dehradun's monsoon humidity and seasonal temperature changes require durable materials and precision sealing. Here is how Ishaanya Interiors builds for resilience:
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {ENGINEERING_PILLARS.map((p, idx) => (
                <div key={idx} className="bg-[#14120E] border border-white/10 p-6 rounded-2xl space-y-3 hover:border-[#C8A96A]/40 transition-colors">
                  <p.icon className="w-8 h-8 text-[#C8A96A]" />
                  <h3 className="text-base font-semibold text-white font-serif">
                    {p.title}
                  </h3>
                  <p className="text-xs text-gray-400 leading-relaxed">
                    {p.desc}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* 9. DOORSTEP CONSULTATION LOCALITIES ACROSS DEHRADUN */}
        <section className="py-12 bg-[#0F0F0F] border-t border-white/5">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center space-y-2 mb-8">
              <h3 className="text-lg font-serif font-semibold text-white">
                Doorstep Modular Kitchen Consultations Across Dehradun
              </h3>
              <p className="text-xs text-gray-300">
                Our site measurement & 3D consultation team serves all major residential zones in Dehradun:
              </p>
            </div>

            <div className="flex flex-wrap justify-center gap-2 max-w-4xl mx-auto">
              {DEHRADUN_LOCALITIES.map((loc) => (
                <span
                  key={loc}
                  className="inline-flex items-center gap-1.5 text-xs text-gray-300 bg-white/5 border border-white/10 px-3.5 py-1.5 rounded-full shadow-sm hover:border-[#C8A96A]/40 transition-colors"
                >
                  <MapPin className="w-3 h-3 text-[#C8A96A]" />
                  <span>{loc}</span>
                </span>
              ))}
            </div>
          </div>
        </section>

        {/* 10. EXACT MANUS FAQS ACCORDION */}
        <section id="kitchen-faqs" className="py-20 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 border-t border-white/5">
          <div className="text-center space-y-3 mb-12">
            <span className="text-xs font-bold uppercase tracking-wider text-[#C8A96A] bg-white/5 border border-[#C8A96A]/30 px-3 py-1 rounded">
              Frequently Asked Questions
            </span>
            <h2 className="text-3xl font-serif font-semibold text-white">
              Dehradun Modular Kitchen FAQs
            </h2>
            <p className="text-xs sm:text-sm text-gray-300">
              Answers to common questions about costs, materials, delivery, and guarantees for homeowners in Dehradun.
            </p>
          </div>

          <div className="space-y-3">
            {MANUS_FAQS.map((faq, idx) => {
              const isOpen = openFaqIndex === idx;
              return (
                <div
                  key={idx}
                  className="border border-white/10 rounded-2xl overflow-hidden bg-white/[0.02] shadow-sm transition-all"
                >
                  <button
                    onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                    className="w-full p-5 text-left flex items-center justify-between gap-4 cursor-pointer hover:bg-white/[0.05] transition-colors"
                  >
                    <span className="text-sm sm:text-base font-semibold text-white font-serif">
                      {faq.q}
                    </span>
                    <ChevronDown className={`w-5 h-5 text-gray-400 shrink-0 transition-transform duration-300 ${isOpen ? 'rotate-180 text-[#C8A96A]' : ''}`} />
                  </button>

                  {isOpen && (
                    <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-gray-300 leading-relaxed border-t border-white/5">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>

        {/* 11. MANUS CONSULTATION BOOKING & INQUIRY FORM */}
        <section id="kitchen-inquiry" className="bg-[#0F0F0F] text-white py-20 border-t border-white/5">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center space-y-4 mb-10">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#C8A96A]/20 text-[#C8A96A] text-xs font-semibold uppercase tracking-wider">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Ready to Cook in Luxury?</span>
              </div>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif font-semibold text-white leading-tight">
                Schedule Your Free 3D Kitchen Consultation in Dehradun
              </h2>
              <p className="text-xs sm:text-sm text-gray-300 max-w-xl mx-auto">
                Founder Himanshu Kanswal and our senior kitchen designers will visit your home for laser measurements, ergonomic layout planning, and an exact quotation.
              </p>
            </div>

            {/* Direct Form Box */}
            <div className="bg-[#14120E] border border-[#C8A96A]/40 rounded-2xl p-6 sm:p-10 shadow-2xl">
              {formSuccess ? (
                <div className="text-center py-10 space-y-4">
                  <div className="w-16 h-16 rounded-full bg-[#C8A96A]/20 text-[#C8A96A] flex items-center justify-center mx-auto border border-[#C8A96A]">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h3 className="text-2xl font-serif font-bold text-white">Consultation Request Received!</h3>
                  <p className="text-xs sm:text-sm text-gray-300 max-w-md mx-auto">
                    Founder Himanshu Kanswal will connect with you within 2 hours to confirm your site measurement visit in Dehradun.
                  </p>
                  <div className="pt-4 flex flex-col sm:flex-row justify-center gap-3">
                    <a
                      href={`https://wa.me/919068377690?text=Hi%20Himanshu,%20I%20just%20submitted%20a%20modular%20kitchen%20consultation%20form%20for%20my%20home.`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-2"
                    >
                      <MessageSquare className="w-4 h-4" />
                      <span>Chat on WhatsApp Directly</span>
                    </a>
                    <button
                      onClick={() => setFormSuccess(false)}
                      className="px-6 py-3 rounded-xl bg-neutral-800 text-gray-300 hover:text-white text-xs font-semibold"
                    >
                      Submit Another Query
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleInquirySubmit} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-medium text-gray-300 block mb-1">Your Full Name *</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Rajesh Sharma"
                        value={formState.name}
                        onChange={(e) => setFormState({ ...formState, name: e.target.value })}
                        className="w-full bg-[#0A0A0A] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-[#C8A96A]"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-medium text-gray-300 block mb-1">Mobile / WhatsApp Number *</label>
                      <input
                        type="tel"
                        required
                        placeholder="+91 98765 43210"
                        value={formState.phone}
                        onChange={(e) => setFormState({ ...formState, phone: e.target.value })}
                        className="w-full bg-[#0A0A0A] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-[#C8A96A]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-medium text-gray-300 block mb-1">Dehradun Locality / Sector</label>
                      <select
                        value={formState.locality}
                        onChange={(e) => setFormState({ ...formState, locality: e.target.value })}
                        className="w-full bg-[#0A0A0A] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-[#C8A96A]"
                      >
                        {DEHRADUN_LOCALITIES.map((loc) => (
                          <option key={loc} value={loc} className="bg-neutral-900 text-white">
                            {loc}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="text-xs font-medium text-gray-300 block mb-1">Kitchen Collection / Layout</label>
                      <select
                        value={formState.service}
                        onChange={(e) => setFormState({ ...formState, service: e.target.value })}
                        className="w-full bg-[#0A0A0A] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-[#C8A96A]"
                      >
                        <option value="Premium Royale (Acrylic Kitchen)" className="bg-neutral-900 text-white">Premium Royale (High-Gloss Acrylic)</option>
                        <option value="Bespoke Imperial (PU Lacquer)" className="bg-neutral-900 text-white">Bespoke Imperial (Italian PU / Fluted Glass)</option>
                        <option value="Essential Luxury (Laminate)" className="bg-neutral-900 text-white">Essential Luxury (High-Pressure Laminate)</option>
                        <option value="Island Modular Kitchen" className="bg-neutral-900 text-white">Island Modular Kitchen</option>
                        <option value="L-Shaped Modular Kitchen" className="bg-neutral-900 text-white">L-Shaped Modular Kitchen</option>
                        <option value="Parallel Galley Kitchen" className="bg-neutral-900 text-white">Parallel Galley Kitchen</option>
                        <option value="Living Room TV Console & Paneling" className="bg-neutral-900 text-white">Living Room TV Console & Paneling</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-medium text-gray-300 block mb-1">Project Details or Site Requirements (Optional)</label>
                    <textarea
                      rows={3}
                      placeholder="e.g. 12x10 ft kitchen in new 3BHK villa, possession next month, looking for quartz countertop..."
                      value={formState.notes}
                      onChange={(e) => setFormState({ ...formState, notes: e.target.value })}
                      className="w-full bg-[#0A0A0A] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-[#C8A96A] resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={formSubmitting}
                    className="w-full py-4 rounded-xl gold-gradient-bg text-[#0F0F0F] font-bold text-xs sm:text-sm uppercase tracking-wider hover:brightness-110 shadow-xl transition-all cursor-pointer flex items-center justify-center gap-2"
                  >
                    {formSubmitting ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Booking Your Consultation...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>Book Free On-Site Consultation</span>
                      </>
                    )}
                  </button>

                  <div className="pt-2 flex flex-col sm:flex-row justify-center gap-3">
                    <a
                      href={`tel:${COMPANY_PHONE}`}
                      className="bg-neutral-800 hover:bg-neutral-700 text-white font-semibold text-xs sm:text-sm px-6 py-3.5 rounded-xl transition-colors flex items-center justify-center gap-2"
                    >
                      <Phone className="w-4 h-4 text-[#C8A96A]" />
                      <span>Call Himanshu Kanswal ({COMPANY_PHONE_DISPLAY})</span>
                    </a>

                    <a
                      href={`https://wa.me/919068377690?text=Hi%20Himanshu,%20I%20am%20interested%20in%20a%20Modular%20Kitchen%20in%20Dehradun.`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs sm:text-sm px-6 py-3.5 rounded-xl transition-colors flex items-center justify-center gap-2"
                    >
                      <MessageSquare className="w-4 h-4" />
                      <span>Chat on WhatsApp</span>
                    </a>
                  </div>

                  <p className="text-[11px] text-gray-500 text-center pt-1">
                    ✓ Free Site Visit & Laser Measurement • Transparent Quotations • Branded Hardware Warranty
                  </p>
                </form>
              )}
            </div>
          </div>
        </section>
      </main>

      {/* 12. LUXURY DARK FOOTER */}
      <footer className="bg-[#07070A] border-t border-white/10 py-12 text-xs text-gray-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
            {/* Brand column */}
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#1C1A14] to-[#121215] border border-[#C8A96A]/60 flex items-center justify-center p-2 shadow-lg">
                  <img src="/images/ishaanya_logo_dark.svg" alt="Ishaanya Interiors" className="w-full h-full object-contain" />
                </div>
                <div>
                  <div className="font-serif font-bold text-white text-base">ISHAANYA INTERIORS</div>
                  <div className="text-[9px] uppercase tracking-widest text-[#C8A96A]">Dehradun • Bespoke Modular Kitchens</div>
                </div>
              </div>
              <p className="text-gray-400 text-xs leading-relaxed">
                Dehradun's premier bespoke modular kitchen studio. Precision off-site factory fabrication, 100% BWP Marine Plywood IS:710 execution, and German soft-close fittings.
              </p>
            </div>

            {/* Quick Links */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-white">Collections</h4>
              <ul className="space-y-1.5 text-xs text-gray-400">
                <li><a href="#kitchen-packages" className="hover:text-[#C8A96A] transition-colors">Essential Luxury (Laminate)</a></li>
                <li><a href="#kitchen-packages" className="hover:text-[#C8A96A] transition-colors">Premium Royale (High-Gloss Acrylic)</a></li>
                <li><a href="#kitchen-packages" className="hover:text-[#C8A96A] transition-colors">Bespoke Imperial (Italian PU & Fluted Glass)</a></li>
                <li><a href="#kitchen-3d-configurator" className="hover:text-[#C8A96A] transition-colors">3D Kitchen Configurator</a></li>
                <li><a href="#kitchen-gallery" className="hover:text-[#C8A96A] transition-colors">Kitchen Designs & Gallery</a></li>
              </ul>
            </div>

            {/* Contact & Studio */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-white">Dehradun Studio</h4>
              <ul className="space-y-1.5 text-xs text-gray-400">
                <li className="flex items-start gap-2">
                  <MapPin className="w-3.5 h-3.5 text-[#C8A96A] shrink-0 mt-0.5" />
                  <span>Dehradun, Uttarakhand, India (Serving all residential sectors)</span>
                </li>
                <li className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-[#C8A96A] shrink-0" />
                  <a href={`tel:${COMPANY_PHONE}`} className="hover:text-white transition-colors">{COMPANY_PHONE_DISPLAY}</a>
                </li>
                <li className="flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-[#C8A96A] shrink-0" />
                  <a href={`mailto:${COMPANY_EMAIL}`} className="hover:text-white transition-colors">{COMPANY_EMAIL}</a>
                </li>
                <li className="flex items-center gap-2">
                  <Clock className="w-3.5 h-3.5 text-[#C8A96A] shrink-0" />
                  <span>Mon - Sun: 9:00 AM - 8:00 PM</span>
                </li>
              </ul>
            </div>

            {/* Warranties & Owner Portal Link */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-white">Quality Guarantees</h4>
              <p className="text-[11px] text-gray-400 leading-relaxed">
                All cabinetry engineered with 100% Boiling Waterproof Marine Plywood (IS:710), Grade-1 HDHMR, and authentic manufacturer warranty cards from Blum & Hettich.
              </p>
              <div className="pt-2">
                <a 
                  href="/owner" 
                  className="inline-flex items-center gap-1.5 text-[11px] text-neutral-500 hover:text-[#C8A96A] transition-colors border border-white/5 px-2.5 py-1 rounded"
                >
                  <ShieldCheck className="w-3 h-3" />
                  <span>Owner & Management Portal</span>
                </a>
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-gray-500">
            <div>
              © {new Date().getFullYear()} Ishaanya Interiors. All rights reserved. Founded & Supervised by Himanshu Kanswal.
            </div>
            <div className="flex items-center gap-4">
              <span>BWP Marine Grade IS:710</span>
              <span>•</span>
              <span>Dehradun Luxury Kitchens</span>
              <span>•</span>
              <span>Blum & Hettich Fitted</span>
            </div>
          </div>
        </div>
      </footer>

      {/* 13. MANUS-STYLE RESPONSIVE MOBILE STICKY ACTION BAR */}
      <div className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#0F0F0F]/95 backdrop-blur-md border-t border-white/10 px-4 py-2.5 flex items-center justify-between gap-2 shadow-2xl">
        <a
          href={`tel:${COMPANY_PHONE}`}
          className="flex-1 py-2.5 px-3 rounded-xl bg-neutral-800 text-white text-xs font-semibold flex items-center justify-center gap-1.5 border border-white/10"
        >
          <Phone className="w-3.5 h-3.5 text-[#C8A96A]" />
          <span>Call</span>
        </a>

        <a
          href={`https://wa.me/919068377690?text=Hi%20Himanshu,%20I%20am%20interested%20in%20a%20modular%20kitchen%20consultation%20in%20Dehradun.`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 py-2.5 px-3 rounded-xl bg-emerald-600 text-white text-xs font-semibold flex items-center justify-center gap-1.5"
        >
          <MessageSquare className="w-3.5 h-3.5" />
          <span>WhatsApp</span>
        </a>

        <button
          onClick={() => handleBookVisit({})}
          className="flex-1 py-2.5 px-3 rounded-xl gold-gradient-bg text-[#0F0F0F] text-xs font-bold flex items-center justify-center gap-1"
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>Book 3D</span>
        </button>
      </div>

      {/* Lightbox Modal for Kitchen Details */}
      {selectedGalleryItem && (
        <KitchenGalleryModal
          item={selectedGalleryItem}
          onClose={() => setSelectedGalleryItem(null)}
          onInquire={(item) => handleBookVisit({ notes: `Interested in ${item.title}` })}
        />
      )}
    </div>
  );
};
