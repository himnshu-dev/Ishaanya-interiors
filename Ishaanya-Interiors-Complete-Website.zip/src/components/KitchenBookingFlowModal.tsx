// @ts-nocheck
import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { 
  Calendar, 
  MapPin, 
  Phone, 
  User, 
  Mail, 
  Check, 
  Clock, 
  CheckCircle2, 
  Sparkles, 
  ArrowRight, 
  ArrowLeft, 
  Sliders, 
  X,
  MessageSquare,
  ShieldCheck,
  Home,
  IndianRupee
} from 'lucide-react';

export interface KitchenBookingData {
  layout: string;
  packageTier: string;
  finishName?: string;
  countertopName?: string;
  estimatedPrice?: number;
  propertyType: string;
  locality: string;
  projectStage: string;
  fullName: string;
  phone: string;
  email: string;
  preferredDate: string;
  preferredSlot: string;
  notes: string;
  whatsappUpdates: boolean;
}

interface KitchenBookingFlowModalProps {
  isOpen: boolean;
  onClose: () => void;
  prefillConfig?: {
    layout?: string;
    packageTier?: string;
    finishName?: string;
    countertopName?: string;
    estimatedPrice?: number;
    ledLighting?: boolean;
    serviceName?: string;
  };
}

export const KitchenBookingFlowModal: React.FC<KitchenBookingFlowModalProps> = ({
  isOpen,
  onClose,
  prefillConfig
}) => {
  const [step, setStep] = useState<number>(1);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [submitted, setSubmitted] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');

  // Form State
  const [formData, setFormData] = useState<KitchenBookingData>({
    layout: prefillConfig?.layout || 'L-Shaped Kitchen',
    packageTier: prefillConfig?.packageTier || 'Premium Royale (Acrylic)',
    finishName: prefillConfig?.finishName || 'High-Gloss Acrylic',
    countertopName: prefillConfig?.countertopName || 'Statuario Quartz',
    estimatedPrice: prefillConfig?.estimatedPrice || 235000,
    propertyType: 'Apartment / Flat',
    locality: 'Rajpur Road',
    projectStage: 'Ready for Measurement (Immediate)',
    fullName: '',
    phone: '',
    email: '',
    preferredDate: '',
    preferredSlot: 'Morning (10:00 AM - 1:00 PM)',
    notes: '',
    whatsappUpdates: true
  });

  const DEHRADUN_LOCALITIES = [
    'Rajpur Road',
    'Jakhan',
    'Vasant Vihar',
    'Sahastradhara Road',
    'Balliwala',
    'Prem Nagar',
    'Dalanwala',
    'Clement Town',
    'GMS Road',
    'Chakrata Road',
    'IT Park / Tarla Nagal',
    'Subhash Nagar',
    'Shimla Bypass',
    'Mussoorie Road',
    'Other Dehradun Area'
  ];

  const handleNext = () => {
    setErrorMsg('');
    if (step === 1 && !formData.layout) {
      setErrorMsg('Please select your kitchen layout.');
      return;
    }
    if (step === 2 && !formData.packageTier) {
      setErrorMsg('Please select your preferred finish package.');
      return;
    }
    if (step === 3 && !formData.locality) {
      setErrorMsg('Please select your Dehradun locality.');
      return;
    }
    if (step === 4) {
      if (!formData.fullName.trim()) {
        setErrorMsg('Please enter your full name.');
        return;
      }
      if (!formData.phone.trim() || formData.phone.replace(/[^0-9]/g, '').length < 10) {
        setErrorMsg('Please enter a valid 10-digit mobile number.');
        return;
      }
      handleSubmit();
      return;
    }
    setStep(prev => prev + 1);
  };

  const handleBack = () => {
    setErrorMsg('');
    setStep(prev => Math.max(1, prev - 1));
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    setErrorMsg('');

    try {
      const payload = {
        name: formData.fullName.trim(),
        phone: formData.phone.trim(),
        email: formData.email.trim() || undefined,
        service: `Modular Kitchen - ${formData.packageTier}`,
        city: `Dehradun (${formData.locality})`,
        budget: formData.estimatedPrice ? `₹${formData.estimatedPrice.toLocaleString('en-IN')}` : undefined,
        message: `[KITCHEN 3D BOOKING]
Layout: ${formData.layout}
Package: ${formData.packageTier}
Finish: ${formData.finishName || 'Custom'}
Countertop: ${formData.countertopName || 'Quartz'}
Property: ${formData.propertyType}
Locality: ${formData.locality}
Project Stage: ${formData.projectStage}
Preferred Date: ${formData.preferredDate || 'Earliest available'}
Slot: ${formData.preferredSlot}
Client Notes: ${formData.notes || 'None'}`
      };

      const res = await fetch('/api/inquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.message || 'Failed to submit booking request.');
      }

      setSubmitted(true);

      // Trigger Confetti Celebration
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#C8A96A', '#D4AF37', '#FFFFFF', '#00BB7F']
        });
      } catch {}

    } catch (err: any) {
      console.error('[BOOKING ERROR]:', err);
      setErrorMsg(err.message || 'An error occurred while scheduling your visit. Please call directly at +91 90683 77690.');
    } finally {
      setSubmitting(false);
    }
  };

  const getWhatsAppLink = () => {
    const text = `Hi Himanshu, I just scheduled a modular kitchen consultation on your website for my home in Dehradun.
Name: ${formData.fullName}
Locality: ${formData.locality}
Layout: ${formData.layout}
Package: ${formData.packageTier}
Preferred Visit: ${formData.preferredDate || 'This week'}`;
    return `https://wa.me/919068377690?text=${encodeURIComponent(text)}`;
  };

  return (
    <div
      id="kitchen-booking-modal-root"
      data-component="KitchenBookingFlowModal"
      data-mounted="true"
      data-open={isOpen ? "true" : "false"}
      className={isOpen ? "fixed inset-0 z-[260] bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto" : "hidden"}
    >
      {isOpen && (
        <div className="relative w-full max-w-2xl bg-[#0F0F12] text-white border border-[#C8A96A]/40 rounded-2xl shadow-2xl overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-200">
          {/* Header */}
          <div className="px-6 py-4 bg-[#14141A] border-b border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#C8A96A]/20 border border-[#C8A96A]/40 flex items-center justify-center text-[#C8A96A]">
                <Calendar className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold tracking-widest text-[#C8A96A]">
                  Complimentary Consultation
                </span>
                <h3 className="text-lg font-serif font-bold text-white">
                  Book Free 3D Site Visit in Dehradun
                </h3>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 text-gray-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Step Progress Bar (when not submitted) */}
          {!submitted && (
            <div className="bg-[#181820] px-6 py-2.5 border-b border-white/5 flex items-center justify-between text-xs">
              {[
                { num: 1, label: 'Layout' },
                { num: 2, label: 'Collection' },
                { num: 3, label: 'Property' },
                { num: 4, label: 'Contact' },
              ].map(s => (
                <div key={s.num} className="flex items-center gap-1.5">
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center text-[11px] font-bold transition-all ${
                      step === s.num
                        ? 'bg-[#C8A96A] text-black shadow-md'
                        : step > s.num
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                        : 'bg-neutral-800 text-gray-500'
                    }`}
                  >
                    {step > s.num ? <Check className="w-3.5 h-3.5" /> : s.num}
                  </div>
                  <span className={`text-[11px] font-medium hidden sm:inline ${step === s.num ? 'text-white' : 'text-gray-500'}`}>
                    {s.label}
                  </span>
                </div>
              ))}
            </div>
          )}

          {/* Modal Body */}
          <div className="p-6">
            {errorMsg && (
              <div className="mb-4 p-3 rounded-xl bg-red-950/40 border border-red-500/30 text-red-200 text-xs">
                {errorMsg}
              </div>
            )}

            {submitted ? (
              /* Success State */
              <div className="text-center py-6 space-y-5">
                <div className="w-16 h-16 rounded-full bg-emerald-500/20 border-2 border-emerald-500 text-emerald-400 mx-auto flex items-center justify-center shadow-lg">
                  <CheckCircle2 className="w-8 h-8" />
                </div>

                <div>
                  <span className="text-xs font-bold uppercase tracking-widest text-[#C8A96A] block mb-1">
                    Site Visit Confirmed
                  </span>
                  <h3 className="text-2xl font-serif font-bold text-white">
                    Thank You, {formData.fullName.split(' ')[0]}!
                  </h3>
                  <p className="text-xs sm:text-sm text-gray-300 max-w-md mx-auto mt-2 leading-relaxed">
                    Founder <span className="text-white font-semibold">Himanshu Kanswal</span> has received your 3D kitchen consultation request for <span className="text-[#C8A96A]">{formData.locality}, Dehradun</span>. Our design team will contact you shortly to confirm the laser measurement timing.
                  </p>
                </div>

                {/* Summary Card */}
                <div className="bg-[#181820] rounded-xl p-4 border border-white/10 max-w-md mx-auto text-left text-xs space-y-2">
                  <div className="flex justify-between border-b border-white/5 pb-1.5">
                    <span className="text-gray-400">Selected Layout:</span>
                    <span className="font-semibold text-white">{formData.layout}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-1.5">
                    <span className="text-gray-400">Finish Collection:</span>
                    <span className="font-semibold text-[#C8A96A]">{formData.packageTier}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-1.5">
                    <span className="text-gray-400">Location:</span>
                    <span className="font-semibold text-white">{formData.locality}, Dehradun</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Estimated Budget Range:</span>
                    <span className="font-semibold text-emerald-400">
                      ₹{formData.estimatedPrice?.toLocaleString('en-IN')} (approx)
                    </span>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-col sm:flex-row justify-center gap-3 pt-2">
                  <a
                    href={getWhatsAppLink()}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="py-3 px-6 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg transition-all"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>Notify Founder on WhatsApp</span>
                  </a>

                  <button
                    onClick={onClose}
                    className="py-3 px-6 rounded-xl bg-white/10 hover:bg-white/15 text-white font-semibold text-xs border border-white/10 transition-all cursor-pointer"
                  >
                    Done
                  </button>
                </div>
              </div>
            ) : (
              /* Multi-step Form Content */
              <div>
                {/* STEP 1: Layout Selection */}
                {step === 1 && (
                  <div className="space-y-4">
                    <div>
                      <h4 className="text-base font-serif font-bold text-white">What kitchen layout fits your space?</h4>
                      <p className="text-xs text-gray-400 mt-0.5">Select the approximate layout shape for your Dehradun residence.</p>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                      {[
                        { id: 'L-Shaped Kitchen', desc: 'Most versatile corner design', popular: true },
                        { id: 'U-Shaped Kitchen', desc: 'Maximized counter & storage' },
                        { id: 'Parallel (Galley) Kitchen', desc: 'Dual opposite counters' },
                        { id: 'Island Kitchen', desc: 'Central counter + breakfast bar' },
                        { id: 'Straight-Line Kitchen', desc: 'Clean, linear modern wall' },
                        { id: 'Custom / Undecided', desc: 'Needs designer guidance' },
                      ].map(item => (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => setFormData({ ...formData, layout: item.id })}
                          className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                            formData.layout === item.id
                              ? 'border-[#C8A96A] bg-[#C8A96A]/15 text-white shadow-md'
                              : 'border-white/10 bg-[#16161D] text-gray-400 hover:border-white/20'
                          }`}
                        >
                          <div className="text-xs font-bold text-white mb-1">{item.id}</div>
                          <div className="text-[11px] text-gray-400">{item.desc}</div>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* STEP 2: Package & Finish */}
                {step === 2 && (
                  <div className="space-y-4">
                    <div>
                      <h4 className="text-base font-serif font-bold text-white">Select your desired finish collection</h4>
                      <p className="text-xs text-gray-400 mt-0.5">All packages include 100% BWP Marine Grade IS:710 plywood carcasses.</p>
                    </div>

                    <div className="space-y-3">
                      {[
                        {
                          name: 'Essential Luxury (Laminate)',
                          price: 'Starting ₹1.45 Lakhs',
                          desc: '1mm Heavy-duty High-Pressure Gloss/Textured Laminate with 5-Year Warranty.',
                          badge: 'Scratch Resistant'
                        },
                        {
                          name: 'Premium Royale (Acrylic)',
                          price: 'Starting ₹2.35 Lakhs',
                          desc: '2mm Glass-like Optical Gloss Acrylic with Gola profile handleless channels & 10-Year Warranty.',
                          badge: 'Most Popular',
                          highlight: true
                        },
                        {
                          name: 'Bespoke Imperial (Super Matte PU)',
                          price: 'Starting ₹3.85 Lakhs',
                          desc: '7-Layer Italian Polyurethane (PU) Lacquer with seamless zero-edge joints & 12-Year Warranty.',
                          badge: 'Ultra Luxury'
                        }
                      ].map(p => (
                        <button
                          key={p.name}
                          type="button"
                          onClick={() => setFormData({ ...formData, packageTier: p.name })}
                          className={`w-full p-4 rounded-xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                            formData.packageTier === p.name
                              ? 'border-[#C8A96A] bg-[#C8A96A]/15 text-white shadow-md'
                              : 'border-white/10 bg-[#16161D] text-gray-300 hover:border-white/20'
                          }`}
                        >
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-bold text-white">{p.name}</span>
                              <span className="text-[10px] bg-black/40 text-[#C8A96A] px-2 py-0.5 rounded border border-[#C8A96A]/30">
                                {p.badge}
                              </span>
                            </div>
                            <p className="text-xs text-gray-400 mt-1 max-w-md">{p.desc}</p>
                          </div>
                          <div className="text-right shrink-0 ml-3">
                            <span className="text-xs font-bold text-[#C8A96A]">{p.price}</span>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* STEP 3: Property & Locality */}
                {step === 3 && (
                  <div className="space-y-4">
                    <div>
                      <h4 className="text-base font-serif font-bold text-white">Where is your property in Dehradun?</h4>
                      <p className="text-xs text-gray-400 mt-0.5">Complimentary laser measurement available across all Dehradun sectors.</p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="text-xs font-semibold text-gray-300 mb-1.5 block">Select Locality / Area</label>
                        <select
                          value={formData.locality}
                          onChange={e => setFormData({ ...formData, locality: e.target.value })}
                          className="w-full bg-[#181822] border border-white/15 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#C8A96A]"
                        >
                          {DEHRADUN_LOCALITIES.map(loc => (
                            <option key={loc} value={loc} className="bg-[#181822] text-white">
                              {loc}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="text-xs font-semibold text-gray-300 mb-1.5 block">Property Type</label>
                        <select
                          value={formData.propertyType}
                          onChange={e => setFormData({ ...formData, propertyType: e.target.value })}
                          className="w-full bg-[#181822] border border-white/15 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#C8A96A]"
                        >
                          <option value="Apartment / Flat">Apartment / Flat (2BHK, 3BHK, 4BHK)</option>
                          <option value="Independent Villa / Kothi">Independent Villa / Kothi</option>
                          <option value="Builder Floor / Penthouse">Builder Floor / Penthouse</option>
                          <option value="Commercial / Farmhouse">Commercial / Farmhouse Kitchen</option>
                        </select>
                      </div>

                      <div className="sm:col-span-2">
                        <label className="text-xs font-semibold text-gray-300 mb-1.5 block">Current Site Status</label>
                        <div className="grid grid-cols-3 gap-2">
                          {[
                            'Ready for Measurement (Immediate)',
                            'Civil Work in Progress (1-2 Weeks)',
                            'Renovating Existing Kitchen'
                          ].map(stg => (
                            <button
                              key={stg}
                              type="button"
                              onClick={() => setFormData({ ...formData, projectStage: stg })}
                              className={`p-2.5 rounded-xl border text-center text-xs transition-all cursor-pointer ${
                                formData.projectStage === stg
                                  ? 'border-[#C8A96A] bg-[#C8A96A]/15 text-white font-medium'
                                  : 'border-white/10 bg-[#16161D] text-gray-400 hover:border-white/20'
                              }`}
                            >
                              {stg.split('(')[0]}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* STEP 4: Contact & Appointment Date */}
                {step === 4 && (
                  <div className="space-y-4">
                    <div>
                      <h4 className="text-base font-serif font-bold text-white">Your Contact Details</h4>
                      <p className="text-xs text-gray-400 mt-0.5">We will call to confirm the exact time slot before visiting.</p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                      <div>
                        <label className="text-xs font-semibold text-gray-300 mb-1 block">Full Name *</label>
                        <input
                          type="text"
                          placeholder="e.g. Ananya Sharma"
                          value={formData.fullName}
                          onChange={e => setFormData({ ...formData, fullName: e.target.value })}
                          className="w-full bg-[#181822] border border-white/15 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#C8A96A]"
                        />
                      </div>

                      <div>
                        <label className="text-xs font-semibold text-gray-300 mb-1 block">Mobile Number *</label>
                        <input
                          type="tel"
                          placeholder="e.g. 9876543210"
                          value={formData.phone}
                          onChange={e => setFormData({ ...formData, phone: e.target.value })}
                          className="w-full bg-[#181822] border border-white/15 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#C8A96A]"
                        />
                      </div>

                      <div>
                        <label className="text-xs font-semibold text-gray-300 mb-1 block">Preferred Date (Optional)</label>
                        <input
                          type="date"
                          value={formData.preferredDate}
                          onChange={e => setFormData({ ...formData, preferredDate: e.target.value })}
                          className="w-full bg-[#181822] border border-white/15 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#C8A96A]"
                        />
                      </div>

                      <div>
                        <label className="text-xs font-semibold text-gray-300 mb-1 block">Preferred Time Window</label>
                        <select
                          value={formData.preferredSlot}
                          onChange={e => setFormData({ ...formData, preferredSlot: e.target.value })}
                          className="w-full bg-[#181822] border border-white/15 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#C8A96A]"
                        >
                          <option value="Morning (10:00 AM - 1:00 PM)">Morning (10:00 AM - 1:00 PM)</option>
                          <option value="Afternoon (1:00 PM - 4:00 PM)">Afternoon (1:00 PM - 4:00 PM)</option>
                          <option value="Evening (4:00 PM - 7:00 PM)">Evening (4:00 PM - 7:00 PM)</option>
                        </select>
                      </div>

                      <div className="sm:col-span-2">
                        <label className="text-xs font-semibold text-gray-300 mb-1 block">Any Specific Requirements</label>
                        <input
                          type="text"
                          placeholder="e.g. Tall pantry needed, chimney venting location, island size"
                          value={formData.notes}
                          onChange={e => setFormData({ ...formData, notes: e.target.value })}
                          className="w-full bg-[#181822] border border-white/15 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#C8A96A]"
                        />
                      </div>
                    </div>

                    <label className="flex items-center gap-2 cursor-pointer pt-1">
                      <input
                        type="checkbox"
                        checked={formData.whatsappUpdates}
                        onChange={e => setFormData({ ...formData, whatsappUpdates: e.target.checked })}
                        className="rounded accent-[#C8A96A] w-4 h-4"
                      />
                      <span className="text-xs text-gray-300">
                        Receive 2D/3D kitchen drawings & quote updates via WhatsApp
                      </span>
                    </label>
                  </div>
                )}

                {/* Navigation Controls */}
                <div className="flex items-center justify-between pt-6 mt-6 border-t border-white/10">
                  {step > 1 ? (
                    <button
                      type="button"
                      onClick={handleBack}
                      className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 font-semibold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                      <span>Back</span>
                    </button>
                  ) : (
                    <div />
                  )}

                  <button
                    type="button"
                    onClick={handleNext}
                    disabled={submitting}
                    className="px-6 py-2.5 rounded-xl gold-gradient-bg text-black font-bold text-xs flex items-center gap-2 transition-all hover:brightness-110 shadow-lg shadow-[#C8A96A]/20 cursor-pointer disabled:opacity-50"
                  >
                    {submitting ? (
                      <>
                        <div className="w-3.5 h-3.5 border-2 border-black border-t-transparent rounded-full animate-spin" />
                        <span>Scheduling Visit...</span>
                      </>
                    ) : step === 4 ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Confirm & Book Free Visit</span>
                      </>
                    ) : (
                      <>
                        <span>Continue</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
