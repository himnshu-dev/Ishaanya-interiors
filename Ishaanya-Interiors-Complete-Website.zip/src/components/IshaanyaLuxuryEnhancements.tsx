// @ts-nocheck
import React, { useState, useEffect } from 'react';
import { ThreeKitchenConfigurator } from './ThreeKitchenConfigurator';
import { PackageCollectionsModal } from './PackageCollectionsModal';
import { KitchenBookingFlowModal } from './KitchenBookingFlowModal';
import { Box, Sparkles, Calendar, Layers, Sliders, PhoneCall, ShieldCheck, Check } from 'lucide-react';

export const IshaanyaLuxuryEnhancements: React.FC = () => {
  const [isConfiguratorOpen, setIsConfiguratorOpen] = useState(false);
  const [isPackagesModalOpen, setIsPackagesModalOpen] = useState(false);
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [bookingPrefill, setBookingPrefill] = useState<any>(null);
  const [activePackage, setActivePackage] = useState<'essential' | 'royale' | 'imperial'>('royale');
  const [currentPath, setCurrentPath] = useState('');

  useEffect(() => {
    const updatePath = () => {
      setCurrentPath(window.location.pathname.toLowerCase() + window.location.hash.toLowerCase());
    };
    updatePath();
    window.addEventListener('popstate', updatePath);
    window.addEventListener('hashchange', updatePath);

    // Global window hooks for triggering modals from anywhere in the app
    window.open3DConfigurator = (pkg = 'royale') => {
      setActivePackage(pkg);
      setIsConfiguratorOpen(true);
    };

    window.openKitchenBooking = (prefillData = {}) => {
      setBookingPrefill(prefillData);
      setIsBookingModalOpen(true);
    };

    window.openPackageCollections = () => {
      setIsPackagesModalOpen(true);
    };

    // Attach click listener to any buttons or links with data attributes
    const handleGlobalClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const btn = target.closest('[data-action]');
      if (!btn) return;

      const action = btn.getAttribute('data-action');
      if (action === 'open-3d-configurator') {
        e.preventDefault();
        window.open3DConfigurator();
      } else if (action === 'open-kitchen-booking') {
        e.preventDefault();
        window.openKitchenBooking();
      } else if (action === 'open-packages-modal') {
        e.preventDefault();
        window.openPackageCollections();
      }
    };
    document.addEventListener('click', handleGlobalClick);

    return () => {
      window.removeEventListener('popstate', updatePath);
      window.removeEventListener('hashchange', updatePath);
      document.removeEventListener('click', handleGlobalClick);
    };
  }, []);

  const isOwnerPage = 
    currentPath.includes('owner') || 
    window.location.hash.includes('owner') ||
    currentPath.includes('reset-password');

  return (
    <div 
      id="ishaanya-luxury-enhancements-root" 
      data-component="IshaanyaLuxuryEnhancements" 
      data-mounted="true"
    >
      {/* 1. Floating Desktop & Mobile 3D Quick Action Trigger */}
      {!isOwnerPage && (
        <aside aria-label="3D Kitchen Studio Launcher" className="fixed bottom-20 sm:bottom-6 right-4 sm:right-6 z-[140] flex flex-col items-end gap-2.5 pointer-events-auto">
          {/* 3D Configurator Pill */}
          <button
            id="floating-3d-studio-btn"
            onClick={() => setIsConfiguratorOpen(true)}
            className="group relative flex items-center gap-2.5 px-4 py-2.5 rounded-full bg-gradient-to-r from-[#18181F] via-[#222129] to-[#18181F] text-white border border-[#C8A96A]/60 shadow-2xl hover:border-[#C8A96A] transition-all duration-300 hover:scale-105 cursor-pointer backdrop-blur-md"
          >
            <span className="absolute -top-1 -right-1 flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#C8A96A] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-[#C8A96A]"></span>
            </span>
            <div className="w-7 h-7 rounded-full bg-[#C8A96A]/20 flex items-center justify-center text-[#C8A96A]">
              <Box className="w-4 h-4 animate-spin [animation-duration:8s]" />
            </div>
            <div className="text-left">
              <div className="text-[10px] uppercase font-bold tracking-widest text-[#C8A96A]">Live 3D Studio</div>
              <div className="text-xs font-bold text-white group-hover:text-[#F3E5AB]">3D Configurator</div>
            </div>
          </button>

          {/* Quick Packages & Booking Button */}
          <button
            id="floating-site-visit-btn"
            onClick={() => setIsBookingModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2 rounded-full gold-gradient-bg text-black font-bold text-xs shadow-xl hover:brightness-110 transition-all cursor-pointer hover:scale-105"
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Book Free Site Visit</span>
          </button>
        </aside>
      )}

      {/* 2. Full-Screen 3D Configurator Modal */}
      {isConfiguratorOpen && (
        <div id="three-configurator-modal-container" className="fixed inset-0 z-[240] bg-black/90 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto animate-in fade-in duration-200">
          <div className="w-full max-w-6xl my-auto">
            <ThreeKitchenConfigurator
              isModal={true}
              initialPackage={activePackage}
              onClose={() => setIsConfiguratorOpen(false)}
              onBookDesign={(config) => {
                setIsConfiguratorOpen(false);
                setBookingPrefill({
                  notes: `3D Configurator Selection: ${config.layout.toUpperCase()} Layout, ${config.packageTier.toUpperCase()} Collection, Shutter: ${config.finishName}, Countertop: ${config.countertopName}, Est: ₹${config.estimatedPrice.toLocaleString('en-IN')}`
                });
                setIsBookingModalOpen(true);
              }}
            />
          </div>
        </div>
      )}

      {/* 3. Package Collections Modal */}
      <PackageCollectionsModal
        isOpen={isPackagesModalOpen}
        onClose={() => setIsPackagesModalOpen(false)}
        onOpenConfigurator={(pkg) => {
          setActivePackage(pkg);
          setIsConfiguratorOpen(true);
        }}
        onBookPackage={(pkgName) => {
          setBookingPrefill({ packageTier: pkgName });
          setIsBookingModalOpen(true);
        }}
      />

      {/* 4. Kitchen Booking Flow Modal */}
      <KitchenBookingFlowModal
        isOpen={isBookingModalOpen}
        onClose={() => {
          setIsBookingModalOpen(false);
          setBookingPrefill(null);
        }}
        prefillConfig={bookingPrefill}
      />
    </div>
  );
};
