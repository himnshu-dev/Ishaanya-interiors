// @ts-nocheck
import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { 
  RotateCw, 
  Maximize2, 
  Camera, 
  Sparkles, 
  Layers, 
  Palette, 
  Eye, 
  Lightbulb, 
  Check, 
  Calendar, 
  ChevronRight, 
  Sliders, 
  Home, 
  IndianRupee,
  Box
} from 'lucide-react';

export type KitchenLayoutType = 'l-shape' | 'u-shape' | 'parallel' | 'island' | 'straight';
export type PackageTierType = 'essential' | 'royale' | 'imperial';

interface ThreeKitchenConfiguratorProps {
  initialLayout?: KitchenLayoutType;
  initialPackage?: PackageTierType;
  onBookDesign?: (config: {
    layout: KitchenLayoutType;
    packageTier: PackageTierType;
    finishName: string;
    countertopName: string;
    estimatedPrice: number;
    ledLighting: boolean;
  }) => void;
  isModal?: boolean;
  onClose?: () => void;
}

export const ThreeKitchenConfigurator: React.FC<ThreeKitchenConfiguratorProps> = ({
  initialLayout = 'l-shape',
  initialPackage = 'royale',
  onBookDesign,
  isModal = false,
  onClose
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const kitchenGroupRef = useRef<THREE.Group | null>(null);
  const underCabinetLightRef = useRef<THREE.PointLight | null>(null);
  const animFrameIdRef = useRef<number | null>(null);
  const doorsRef = useRef<THREE.Mesh[]>([]);

  // State
  const [layout, setLayout] = useState<KitchenLayoutType>(initialLayout);
  const [packageTier, setPackageTier] = useState<PackageTierType>(initialPackage);
  const [finishColor, setFinishColor] = useState<string>('#F7FAFC');
  const [finishName, setFinishName] = useState<string>('High-Gloss Pearl White');
  const [countertopType, setCountertopType] = useState<string>('quartz-statuario');
  const [ledLighting, setLedLighting] = useState<boolean>(true);
  const [doorsOpen, setDoorsOpen] = useState<boolean>(false);
  const [cameraView, setCameraView] = useState<'perspective' | 'top' | 'front' | 'island'>('perspective');
  const [isRotating, setIsRotating] = useState<boolean>(true);
  const [snapshotTaken, setSnapshotTaken] = useState<boolean>(false);

  // Material Palettes per Tier (Manus Luxury Style)
  const FINISH_PALETTES = {
    essential: [
      { id: 'walnut', name: 'Warm Walnut Laminate', color: '#5C4033', roughness: 0.65, metalness: 0.05, desc: 'Natural woodgrain texture' },
      { id: 'oak', name: 'Natural Scandinavian Oak', color: '#C8B282', roughness: 0.6, metalness: 0.05, desc: 'Organic light woodgrain' },
      { id: 'slate', name: 'Matte Slate Grey', color: '#4A5568', roughness: 0.7, metalness: 0.1, desc: 'Durable anti-scratch laminate' },
      { id: 'charcoal', name: 'Charcoal Texture Laminate', color: '#2D3748', roughness: 0.65, metalness: 0.05, desc: 'Deep modern tone' }
    ],
    royale: [
      { id: 'gloss-white', name: 'High-Gloss Pearl White', color: '#F7FAFC', roughness: 0.1, metalness: 0.15, desc: 'Optical reflection acrylic' },
      { id: 'champagne', name: 'Champagne Metallic Acrylic', color: '#D4AF37', roughness: 0.2, metalness: 0.45, desc: 'Subtle metallic shimmer' },
      { id: 'midnight-emerald', name: 'Midnight Emerald Acrylic', color: '#0F382A', roughness: 0.15, metalness: 0.25, desc: 'Jewel-tone luxury reflection' },
      { id: 'deep-navy', name: 'Imperial Sapphire Acrylic', color: '#1A2A44', roughness: 0.15, metalness: 0.2, desc: 'Sophisticated royal blue' }
    ],
    imperial: [
      { id: 'matte-black', name: 'Monochrome Super-Matte PU', color: '#18181A', roughness: 0.85, metalness: 0.0, desc: 'Italian 7-layer seamless lacquer' },
      { id: 'cashmere', name: 'Cashmere Velvet PU', color: '#E2D9D0', roughness: 0.8, metalness: 0.0, desc: 'Warm minimalist silk touch' },
      { id: 'sage-green', name: 'Nordic Sage Matte PU', color: '#6A7F73', roughness: 0.82, metalness: 0.0, desc: 'Muted architectural green' },
      { id: 'terracotta', name: 'Tuscan Terracotta PU', color: '#8A4B38', roughness: 0.85, metalness: 0.0, desc: 'Earthy luxury statement' }
    ]
  };

  const COUNTERTOP_OPTIONS = [
    { id: 'quartz-statuario', name: 'Statuario Gold Quartz', color: '#F5F5F0', veinColor: '#C8A96A', roughness: 0.2, metalness: 0.1 },
    { id: 'black-granite', name: 'Jet Black Granite', color: '#1A1A1A', roughness: 0.15, metalness: 0.25 },
    { id: 'nanowhite', name: 'Pure Nano-White Composite', color: '#FFFFFF', roughness: 0.1, metalness: 0.05 },
    { id: 'travertine', name: 'Warm Travertine Stone', color: '#D9C8A9', roughness: 0.4, metalness: 0.05 }
  ];

  // Price Estimator (Dehradun standard luxury rates)
  const calculateEstimate = () => {
    let base = 145000;
    if (layout === 'l-shape') base = 195000;
    else if (layout === 'u-shape') base = 265000;
    else if (layout === 'parallel') base = 235000;
    else if (layout === 'island') base = 330000;
    else if (layout === 'straight') base = 150000;

    let tierMultiplier = 1.0;
    if (packageTier === 'royale') tierMultiplier = 1.45;
    else if (packageTier === 'imperial') tierMultiplier = 1.95;

    let stoneExtra = 0;
    if (countertopType === 'quartz-statuario') stoneExtra = 28000;
    else if (countertopType === 'nanowhite') stoneExtra = 24000;

    const ledExtra = ledLighting ? 8500 : 0;
    return Math.round(base * tierMultiplier + stoneExtra + ledExtra);
  };

  // Sync default finish when package changes
  useEffect(() => {
    const defaultColor = FINISH_PALETTES[packageTier][0];
    setFinishColor(defaultColor.color);
    setFinishName(defaultColor.name);
  }, [packageTier]);

  // Set up Three.js Scene
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth || 800;
    const height = container.clientHeight || 520;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#0F0F0F');
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(7, 5.5, 7.5);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    rendererRef.current = renderer;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Grid Floor
    const gridHelper = new THREE.GridHelper(14, 28, 0xC8A96A, 0x1F1F1F);
    gridHelper.position.y = -0.01;
    scene.add(gridHelper);

    // Floor Plane
    const floorGeo = new THREE.PlaneGeometry(16, 16);
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0x111111,
      roughness: 0.3,
      metalness: 0.1,
    });
    const floorMesh = new THREE.Mesh(floorGeo, floorMat);
    floorMesh.rotation.x = -Math.PI / 2;
    floorMesh.receiveShadow = true;
    scene.add(floorMesh);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xFFFFFF, 0.95);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xFFF6EA, 1.8);
    keyLight.position.set(8, 12, 6);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0xC8D8FF, 0.8);
    fillLight.position.set(-6, 8, -6);
    scene.add(fillLight);

    // Warm Under-Cabinet LED glow
    const underLight = new THREE.PointLight(0xFFAA44, 2.5, 5);
    underLight.position.set(0, 1.8, 0);
    scene.add(underLight);
    underCabinetLightRef.current = underLight;

    // Mouse Interaction
    let isDragging = false;
    let prevMouseX = 0;
    let prevMouseY = 0;
    let spherical = { radius: 10, theta: Math.PI / 4, phi: Math.PI / 3.5 };

    const updateCameraFromSpherical = () => {
      camera.position.x = spherical.radius * Math.sin(spherical.phi) * Math.sin(spherical.theta);
      camera.position.y = spherical.radius * Math.cos(spherical.phi);
      camera.position.z = spherical.radius * Math.sin(spherical.phi) * Math.cos(spherical.theta);
      camera.lookAt(0, 1.2, 0);
    };
    updateCameraFromSpherical();

    const onMouseDown = (e: MouseEvent) => {
      isDragging = true;
      setIsRotating(false);
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      const deltaX = e.clientX - prevMouseX;
      const deltaY = e.clientY - prevMouseY;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;

      spherical.theta -= deltaX * 0.008;
      spherical.phi = Math.max(0.2, Math.min(Math.PI / 2 - 0.05, spherical.phi - deltaY * 0.008));
      updateCameraFromSpherical();
    };

    const onMouseUp = () => {
      isDragging = false;
    };

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      spherical.radius = Math.max(4, Math.min(15, spherical.radius + e.deltaY * 0.01));
      updateCameraFromSpherical();
    };

    // Touch support for mobile
    let touchStartDist = 0;
    const onTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 1) {
        isDragging = true;
        setIsRotating(false);
        prevMouseX = e.touches[0].clientX;
        prevMouseY = e.touches[0].clientY;
      } else if (e.touches.length === 2) {
        touchStartDist = Math.hypot(
          e.touches[0].clientX - e.touches[1].clientX,
          e.touches[0].clientY - e.touches[1].clientY
        );
      }
    };

    const onTouchMove = (e: TouchEvent) => {
      if (e.touches.length === 1 && isDragging) {
        const deltaX = e.touches[0].clientX - prevMouseX;
        const deltaY = e.touches[0].clientY - prevMouseY;
        prevMouseX = e.touches[0].clientX;
        prevMouseY = e.touches[0].clientY;
        spherical.theta -= deltaX * 0.008;
        spherical.phi = Math.max(0.2, Math.min(Math.PI / 2 - 0.05, spherical.phi - deltaY * 0.008));
        updateCameraFromSpherical();
      } else if (e.touches.length === 2) {
        const dist = Math.hypot(
          e.touches[0].clientX - e.touches[1].clientX,
          e.touches[0].clientY - e.touches[1].clientY
        );
        const diff = touchStartDist - dist;
        touchStartDist = dist;
        spherical.radius = Math.max(4, Math.min(15, spherical.radius + diff * 0.02));
        updateCameraFromSpherical();
      }
    };

    const onTouchEnd = () => {
      isDragging = false;
    };

    const dom = renderer.domElement;
    dom.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    dom.addEventListener('wheel', onWheel, { passive: false });
    dom.addEventListener('touchstart', onTouchStart, { passive: true });
    window.addEventListener('touchmove', onTouchMove, { passive: true });
    window.addEventListener('touchend', onTouchEnd);

    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    const animate = () => {
      animFrameIdRef.current = requestAnimationFrame(animate);

      if (kitchenGroupRef.current && isRotating && !isDragging) {
        spherical.theta += 0.0025;
        updateCameraFromSpherical();
      }

      renderer.render(scene, camera);
    };
    animate();

    return () => {
      if (animFrameIdRef.current) cancelAnimationFrame(animFrameIdRef.current);
      window.removeEventListener('resize', handleResize);
      dom.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      dom.removeEventListener('wheel', onWheel);
      dom.removeEventListener('touchstart', onTouchStart);
      window.removeEventListener('touchmove', onTouchMove);
      window.removeEventListener('touchend', onTouchEnd);
      renderer.dispose();
    };
  }, []);

  // Camera preset switch
  useEffect(() => {
    const camera = cameraRef.current;
    if (!camera) return;

    if (cameraView === 'perspective') {
      camera.position.set(7, 5.5, 7.5);
      camera.lookAt(0, 1.2, 0);
    } else if (cameraView === 'top') {
      camera.position.set(0, 10, 0.001);
      camera.lookAt(0, 0, 0);
    } else if (cameraView === 'front') {
      camera.position.set(0, 2.2, 8);
      camera.lookAt(0, 1.4, 0);
    } else if (cameraView === 'island') {
      camera.position.set(4, 3, 5);
      camera.lookAt(0, 1.2, 0);
    }
  }, [cameraView]);

  // Update LED Light
  useEffect(() => {
    if (underCabinetLightRef.current) {
      underCabinetLightRef.current.intensity = ledLighting ? 2.8 : 0;
    }
  }, [ledLighting]);

  // Re-build Kitchen 3D Model
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    if (kitchenGroupRef.current) {
      scene.remove(kitchenGroupRef.current);
    }

    const kitchenGroup = new THREE.Group();
    kitchenGroupRef.current = kitchenGroup;
    doorsRef.current = [];

    const tierPalette = FINISH_PALETTES[packageTier] || FINISH_PALETTES.royale;
    const currentFinish = tierPalette.find(p => p.color.toLowerCase() === finishColor.toLowerCase()) || tierPalette[0];
    const currentCounter = COUNTERTOP_OPTIONS.find(c => c.id === countertopType) || COUNTERTOP_OPTIONS[0];

    const cabinetMaterial = new THREE.MeshStandardMaterial({
      color: new THREE.Color(finishColor),
      roughness: currentFinish.roughness,
      metalness: currentFinish.metalness,
    });

    const carcassMaterial = new THREE.MeshStandardMaterial({
      color: 0x1A1A1A,
      roughness: 0.5,
      metalness: 0.1
    });

    const counterMaterial = new THREE.MeshStandardMaterial({
      color: new THREE.Color(currentCounter.color),
      roughness: currentCounter.roughness,
      metalness: currentCounter.metalness
    });

    const handleMaterial = new THREE.MeshStandardMaterial({
      color: packageTier === 'imperial' ? 0x1A1A1A : 0xC8A96A,
      roughness: 0.3,
      metalness: 0.85
    });

    const backsplashMaterial = new THREE.MeshStandardMaterial({
      color: 0x1F1F24,
      roughness: 0.3,
      metalness: 0.2
    });

    const createBaseCabinet = (x: number, z: number, w: number, d: number, rotationY = 0) => {
      const unit = new THREE.Group();
      unit.position.set(x, 0, z);
      unit.rotation.y = rotationY;

      const h = 0.86;
      const boxGeo = new THREE.BoxGeometry(w, h, d);
      const box = new THREE.Mesh(boxGeo, carcassMaterial);
      box.position.set(0, h / 2, 0);
      box.castShadow = true;
      box.receiveShadow = true;
      unit.add(box);

      const numDoors = w > 0.7 ? 2 : 1;
      const doorW = (w - 0.02 * (numDoors + 1)) / numDoors;
      const doorH = h - 0.08;
      const doorThick = 0.02;

      for (let i = 0; i < numDoors; i++) {
        const doorGeo = new THREE.BoxGeometry(doorW, doorH, doorThick);
        const door = new THREE.Mesh(doorGeo, cabinetMaterial);
        const offset = -w / 2 + 0.02 + doorW / 2 + i * (doorW + 0.02);
        door.position.set(offset, h / 2, d / 2 + doorThick / 2);
        door.castShadow = true;

        if (doorsOpen) {
          door.rotation.y = (i % 2 === 0 ? 1 : -1) * 0.75;
          door.position.z += 0.08;
        }

        doorsRef.current.push(door);
        unit.add(door);

        if (packageTier !== 'imperial') {
          const handleGeo = new THREE.CylinderGeometry(0.007, 0.007, 0.16, 12);
          const handle = new THREE.Mesh(handleGeo, handleMaterial);
          handle.rotation.z = Math.PI / 2;
          handle.position.set(offset, h / 2 + 0.22, d / 2 + doorThick + 0.015);
          unit.add(handle);
        } else {
          const golaGeo = new THREE.BoxGeometry(doorW, 0.025, 0.015);
          const gola = new THREE.Mesh(golaGeo, handleMaterial);
          gola.position.set(offset, h - 0.04, d / 2 + doorThick / 2);
          unit.add(gola);
        }
      }

      const counterGeo = new THREE.BoxGeometry(w + 0.04, 0.04, d + 0.06);
      const counter = new THREE.Mesh(counterGeo, counterMaterial);
      counter.position.set(0, h + 0.02, 0.02);
      counter.castShadow = true;
      counter.receiveShadow = true;
      unit.add(counter);

      return unit;
    };

    const createWallCabinet = (x: number, z: number, w: number, d: number, rotationY = 0) => {
      const unit = new THREE.Group();
      unit.position.set(x, 1.55, z);
      unit.rotation.y = rotationY;

      const h = 0.75;
      const boxGeo = new THREE.BoxGeometry(w, h, d);
      const box = new THREE.Mesh(boxGeo, cabinetMaterial);
      box.position.set(0, h / 2, 0);
      box.castShadow = true;
      unit.add(box);

      const ledGeo = new THREE.BoxGeometry(w - 0.05, 0.012, 0.03);
      const ledMat = new THREE.MeshBasicMaterial({
        color: ledLighting ? 0xFFE0A0 : 0x333333
      });
      const led = new THREE.Mesh(ledGeo, ledMat);
      led.position.set(0, -0.006, d / 2 - 0.05);
      unit.add(led);

      return unit;
    };

    const addSinkAndFaucet = (x: number, y: number, z: number) => {
      const sinkGroup = new THREE.Group();
      sinkGroup.position.set(x, y, z);

      const basinGeo = new THREE.BoxGeometry(0.65, 0.01, 0.42);
      const basinMat = new THREE.MeshStandardMaterial({ color: 0x1A1A1A, metalness: 0.9, roughness: 0.2 });
      const basin = new THREE.Mesh(basinGeo, basinMat);
      basin.position.set(0, 0.025, 0);
      sinkGroup.add(basin);

      const curve = new THREE.CatmullRomCurve3([
        new THREE.Vector3(0, 0, 0),
        new THREE.Vector3(0, 0.35, 0),
        new THREE.Vector3(0.08, 0.45, 0),
        new THREE.Vector3(0.18, 0.42, 0),
        new THREE.Vector3(0.2, 0.32, 0)
      ]);
      const faucetGeo = new THREE.TubeGeometry(curve, 20, 0.014, 12, false);
      const faucetMat = new THREE.MeshStandardMaterial({ color: 0xC8A96A, metalness: 0.95, roughness: 0.15 });
      const faucet = new THREE.Mesh(faucetGeo, faucetMat);
      faucet.position.set(-0.1, 0.02, -0.15);
      sinkGroup.add(faucet);

      kitchenGroup.add(sinkGroup);
    };

    const addHobAndChimney = (x: number, y: number, z: number) => {
      const hobGroup = new THREE.Group();
      hobGroup.position.set(x, y, z);

      const hobGeo = new THREE.BoxGeometry(0.72, 0.015, 0.48);
      const hobMat = new THREE.MeshStandardMaterial({ color: 0x0A0A0A, roughness: 0.1, metalness: 0.9 });
      const hob = new THREE.Mesh(hobGeo, hobMat);
      hob.position.set(0, 0.028, 0);
      hobGroup.add(hob);

      const burnerGeo = new THREE.CylinderGeometry(0.065, 0.07, 0.01, 24);
      const burnerMat = new THREE.MeshStandardMaterial({ color: 0x222222, metalness: 0.8, roughness: 0.3 });
      const offsets = [
        [-0.2, -0.1],
        [-0.2, 0.1],
        [0.2, -0.1],
        [0.2, 0.1]
      ];
      offsets.forEach(([bx, bz]) => {
        const burner = new THREE.Mesh(burnerGeo, burnerMat);
        burner.position.set(bx, 0.035, bz);
        hobGroup.add(burner);
      });

      kitchenGroup.add(hobGroup);

      const chimneyGroup = new THREE.Group();
      chimneyGroup.position.set(x, 1.85, z);

      const hoodGeo = new THREE.ConeGeometry(0.48, 0.3, 4);
      hoodGeo.rotateY(Math.PI / 4);
      const hoodMat = new THREE.MeshStandardMaterial({ color: 0x2A2A2E, metalness: 0.9, roughness: 0.2 });
      const hood = new THREE.Mesh(hoodGeo, hoodMat);
      hood.rotation.x = Math.PI;
      chimneyGroup.add(hood);

      const pipeGeo = new THREE.BoxGeometry(0.24, 0.75, 0.24);
      const pipe = new THREE.Mesh(pipeGeo, hoodMat);
      pipe.position.set(0, 0.45, 0);
      chimneyGroup.add(pipe);

      kitchenGroup.add(chimneyGroup);
    };

    const addTallPantry = (x: number, z: number) => {
      const pantry = new THREE.Group();
      pantry.position.set(x, 0, z);

      const h = 2.3;
      const w = 0.7;
      const d = 0.65;
      const boxGeo = new THREE.BoxGeometry(w, h, d);
      const box = new THREE.Mesh(boxGeo, cabinetMaterial);
      box.position.set(0, h / 2, 0);
      box.castShadow = true;
      pantry.add(box);

      const ovenGeo = new THREE.BoxGeometry(w - 0.06, 0.55, d + 0.02);
      const ovenMat = new THREE.MeshStandardMaterial({ color: 0x080808, roughness: 0.1, metalness: 0.8 });
      const oven = new THREE.Mesh(ovenGeo, ovenMat);
      oven.position.set(0, 1.35, 0);
      pantry.add(oven);

      kitchenGroup.add(pantry);
    };

    // Layout Architecture
    if (layout === 'straight') {
      kitchenGroup.add(createBaseCabinet(-1.5, -1, 1.0, 0.65));
      kitchenGroup.add(createBaseCabinet(-0.5, -1, 1.0, 0.65));
      kitchenGroup.add(createBaseCabinet(0.5, -1, 1.0, 0.65));
      kitchenGroup.add(createBaseCabinet(1.5, -1, 1.0, 0.65));

      kitchenGroup.add(createWallCabinet(-1.5, -1, 1.0, 0.35));
      kitchenGroup.add(createWallCabinet(-0.5, -1, 1.0, 0.35));
      kitchenGroup.add(createWallCabinet(0.5, -1, 1.0, 0.35));
      kitchenGroup.add(createWallCabinet(1.5, -1, 1.0, 0.35));

      addSinkAndFaucet(-1.2, 0.86, -1);
      addHobAndChimney(0.5, 0.86, -1);
      addTallPantry(2.4, -1);

      const wallGeo = new THREE.BoxGeometry(5.2, 2.7, 0.08);
      const wall = new THREE.Mesh(wallGeo, backsplashMaterial);
      wall.position.set(0.3, 1.35, -1.35);
      kitchenGroup.add(wall);

    } else if (layout === 'l-shape') {
      kitchenGroup.add(createBaseCabinet(-1.5, -1.2, 1.0, 0.65));
      kitchenGroup.add(createBaseCabinet(-0.5, -1.2, 1.0, 0.65));
      kitchenGroup.add(createBaseCabinet(0.5, -1.2, 1.0, 0.65));
      kitchenGroup.add(createBaseCabinet(1.5, -1.2, 1.0, 0.65));

      kitchenGroup.add(createWallCabinet(-1.5, -1.2, 1.0, 0.35));
      kitchenGroup.add(createWallCabinet(-0.5, -1.2, 1.0, 0.35));
      kitchenGroup.add(createWallCabinet(0.5, -1.2, 1.0, 0.35));
      kitchenGroup.add(createWallCabinet(1.5, -1.2, 1.0, 0.35));

      kitchenGroup.add(createBaseCabinet(-1.8, -0.3, 1.0, 0.65, Math.PI / 2));
      kitchenGroup.add(createBaseCabinet(-1.8, 0.7, 1.0, 0.65, Math.PI / 2));

      addSinkAndFaucet(-1.8, 0.86, 0.2);
      addHobAndChimney(0.5, 0.86, -1.2);
      addTallPantry(2.4, -1.2);

      const backWallGeo = new THREE.BoxGeometry(5.2, 2.7, 0.08);
      const backWall = new THREE.Mesh(backWallGeo, backsplashMaterial);
      backWall.position.set(0.3, 1.35, -1.55);
      kitchenGroup.add(backWall);

      const sideWallGeo = new THREE.BoxGeometry(0.08, 2.7, 3.2);
      const sideWall = new THREE.Mesh(sideWallGeo, backsplashMaterial);
      sideWall.position.set(-2.2, 1.35, 0.0);
      kitchenGroup.add(sideWall);

    } else if (layout === 'u-shape') {
      kitchenGroup.add(createBaseCabinet(-0.8, -1.2, 1.0, 0.65));
      kitchenGroup.add(createBaseCabinet(0.2, -1.2, 1.0, 0.65));

      kitchenGroup.add(createWallCabinet(-0.8, -1.2, 1.0, 0.35));
      kitchenGroup.add(createWallCabinet(0.2, -1.2, 1.0, 0.35));

      kitchenGroup.add(createBaseCabinet(-1.6, -0.4, 1.0, 0.65, Math.PI / 2));
      kitchenGroup.add(createBaseCabinet(-1.6, 0.6, 1.0, 0.65, Math.PI / 2));

      kitchenGroup.add(createBaseCabinet(1.0, -0.4, 1.0, 0.65, -Math.PI / 2));
      kitchenGroup.add(createBaseCabinet(1.0, 0.6, 1.0, 0.65, -Math.PI / 2));

      addSinkAndFaucet(-0.3, 0.86, -1.2);
      addHobAndChimney(-1.6, 0.86, 0.1);
      addTallPantry(1.0, 1.5);

      const backWallGeo = new THREE.BoxGeometry(4.0, 2.7, 0.08);
      const backWall = new THREE.Mesh(backWallGeo, backsplashMaterial);
      backWall.position.set(-0.3, 1.35, -1.55);
      kitchenGroup.add(backWall);

    } else if (layout === 'parallel') {
      kitchenGroup.add(createBaseCabinet(-1.4, -1.0, 1.0, 0.65));
      kitchenGroup.add(createBaseCabinet(-0.4, -1.0, 1.0, 0.65));
      kitchenGroup.add(createBaseCabinet(0.6, -1.0, 1.0, 0.65));
      kitchenGroup.add(createBaseCabinet(1.6, -1.0, 1.0, 0.65));

      kitchenGroup.add(createWallCabinet(-1.4, -1.0, 1.0, 0.35));
      kitchenGroup.add(createWallCabinet(-0.4, -1.0, 1.0, 0.35));
      kitchenGroup.add(createWallCabinet(0.6, -1.0, 1.0, 0.35));

      kitchenGroup.add(createBaseCabinet(-1.4, 1.0, 1.0, 0.65, Math.PI));
      kitchenGroup.add(createBaseCabinet(-0.4, 1.0, 1.0, 0.65, Math.PI));
      kitchenGroup.add(createBaseCabinet(0.6, 1.0, 1.0, 0.65, Math.PI));

      addHobAndChimney(0.1, 0.86, -1.0);
      addSinkAndFaucet(-0.4, 0.86, 1.0);
      addTallPantry(2.3, -1.0);

      const wallGeo = new THREE.BoxGeometry(4.8, 2.7, 0.08);
      const wall = new THREE.Mesh(wallGeo, backsplashMaterial);
      wall.position.set(0.1, 1.35, -1.35);
      kitchenGroup.add(wall);

    } else if (layout === 'island') {
      kitchenGroup.add(createBaseCabinet(-1.5, -1.3, 1.0, 0.65));
      kitchenGroup.add(createBaseCabinet(-0.5, -1.3, 1.0, 0.65));
      kitchenGroup.add(createBaseCabinet(0.5, -1.3, 1.0, 0.65));
      kitchenGroup.add(createBaseCabinet(1.5, -1.3, 1.0, 0.65));

      kitchenGroup.add(createWallCabinet(-1.5, -1.3, 1.0, 0.35));
      kitchenGroup.add(createWallCabinet(-0.5, -1.3, 1.0, 0.35));
      kitchenGroup.add(createWallCabinet(0.5, -1.3, 1.0, 0.35));
      kitchenGroup.add(createWallCabinet(1.5, -1.3, 1.0, 0.35));

      addHobAndChimney(0.5, 0.86, -1.3);
      addTallPantry(2.4, -1.3);

      const islandW = 1.8;
      const islandD = 0.95;
      kitchenGroup.add(createBaseCabinet(0, 0.6, islandW, islandD));
      addSinkAndFaucet(0, 0.86, 0.6);

      [-0.5, 0.5].forEach(sx => {
        const stoolGroup = new THREE.Group();
        stoolGroup.position.set(sx, 0, 1.35);

        const legMat = new THREE.MeshStandardMaterial({ color: 0x111111, metalness: 0.9, roughness: 0.2 });
        const legGeo = new THREE.CylinderGeometry(0.012, 0.012, 0.65);
        const leg = new THREE.Mesh(legGeo, legMat);
        leg.position.y = 0.325;
        stoolGroup.add(leg);

        const seatGeo = new THREE.CylinderGeometry(0.18, 0.18, 0.06, 24);
        const seatMat = new THREE.MeshStandardMaterial({ color: 0xC8A96A, roughness: 0.6 });
        const seat = new THREE.Mesh(seatGeo, seatMat);
        seat.position.y = 0.65;
        stoolGroup.add(seat);

        kitchenGroup.add(stoolGroup);
      });

      const wallGeo = new THREE.BoxGeometry(5.2, 2.7, 0.08);
      const wall = new THREE.Mesh(wallGeo, backsplashMaterial);
      wall.position.set(0.3, 1.35, -1.65);
      kitchenGroup.add(wall);
    }

    scene.add(kitchenGroup);
  }, [layout, packageTier, finishColor, countertopType, ledLighting, doorsOpen]);

  // Take 3D Snapshot
  const handleTakeSnapshot = () => {
    if (!rendererRef.current) return;
    const canvas = rendererRef.current.domElement;
    const dataUrl = canvas.toDataURL('image/png');
    const link = document.createElement('a');
    link.download = `Ishaanya-Kitchen-${layout}-${packageTier}.png`;
    link.href = dataUrl;
    link.click();
    setSnapshotTaken(true);
    setTimeout(() => setSnapshotTaken(false), 2500);
  };

  const estimatedPrice = calculateEstimate();

  const handleBookNow = () => {
    if (onBookDesign) {
      onBookDesign({
        layout,
        packageTier,
        finishName,
        countertopName: COUNTERTOP_OPTIONS.find(c => c.id === countertopType)?.name || 'Statuario Quartz',
        estimatedPrice,
        ledLighting
      });
    }
  };

  return (
    <div className={`relative w-full bg-[#0F0F0F] text-white overflow-hidden rounded-2xl border border-[#C8A96A]/30 shadow-2xl ${isModal ? 'max-h-[92vh] flex flex-col' : 'my-4'}`}>
      {/* Top Configurator Header in Manus Style */}
      <div className="flex flex-wrap items-center justify-between gap-4 px-6 py-4 bg-[#14120E] border-b border-[#C8A96A]/20 z-20">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#C8A96A]/15 border border-[#C8A96A]/40 flex items-center justify-center text-[#C8A96A]">
            <Box className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#C8A96A] bg-white/5 border border-[#C8A96A]/30 px-2 py-0.5 rounded">
                Live 3D Studio
              </span>
              <span className="text-xs text-gray-400">Interactive Modular Kitchen Simulator</span>
            </div>
            <h3 className="text-lg sm:text-xl font-serif font-semibold text-white">
              Bespoke Kitchen Simulator
            </h3>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setIsRotating(!isRotating)}
            className={`p-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer border ${
              isRotating ? 'bg-[#C8A96A]/20 text-[#C8A96A] border-[#C8A96A]/40' : 'bg-neutral-900 text-gray-300 border-white/10'
            }`}
            title="Toggle 360 Auto-Rotate"
          >
            <RotateCw className={`w-3.5 h-3.5 ${isRotating ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">{isRotating ? 'Auto Orbit' : 'Orbit Paused'}</span>
          </button>

          <button
            onClick={handleTakeSnapshot}
            className="p-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 bg-neutral-900 hover:bg-neutral-800 text-gray-300 border border-white/10 transition-all cursor-pointer"
            title="Capture High-Res 3D Image"
          >
            <Camera className="w-3.5 h-3.5 text-[#C8A96A]" />
            <span className="hidden sm:inline">{snapshotTaken ? 'Saved!' : 'Save 3D Photo'}</span>
          </button>

          {isModal && onClose && (
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-white hover:bg-white/10 rounded-lg transition-all cursor-pointer ml-2 text-sm font-bold"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* Main Studio Body: 3D Viewport + Customizer Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 flex-1 min-h-[500px]">
        {/* 3D Canvas Viewport (7 Cols) */}
        <div className="lg:col-span-7 relative bg-[#0D0D11] min-h-[380px] sm:min-h-[460px] flex items-center justify-center">
          <div ref={mountRef} className="w-full h-full min-h-[380px] sm:min-h-[460px] cursor-grab active:cursor-grabbing" />

          {/* Interactive Floating Camera View Selector */}
          <div className="absolute bottom-4 left-4 z-10 flex items-center gap-1.5 bg-[#0F0F0F]/90 backdrop-blur-md p-1 rounded-xl border border-white/10">
            {[
              { id: 'perspective', label: 'Perspective', icon: Maximize2 },
              { id: 'front', label: 'Front View', icon: Eye },
              { id: 'top', label: 'Top / 2D', icon: Layers },
              { id: 'island', label: 'Counter Zoom', icon: Home },
            ].map(v => (
              <button
                key={v.id}
                onClick={() => {
                  setCameraView(v.id as any);
                  setIsRotating(false);
                }}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
                  cameraView === v.id
                    ? 'gold-gradient-bg text-[#0F0F0F] font-bold shadow-md'
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <v.icon className="w-3 h-3" />
                <span className="hidden sm:inline">{v.label}</span>
              </button>
            ))}
          </div>

          {/* Toggles: LED Lighting & Doors Open */}
          <div className="absolute top-4 left-4 z-10 flex flex-col gap-2">
            <button
              onClick={() => setLedLighting(!ledLighting)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 backdrop-blur-md transition-all cursor-pointer border ${
                ledLighting
                  ? 'bg-amber-400/20 text-amber-300 border-amber-400/40 shadow-lg'
                  : 'bg-neutral-900/80 text-gray-400 border-white/10'
              }`}
            >
              <Lightbulb className={`w-3.5 h-3.5 ${ledLighting ? 'text-amber-300' : 'text-gray-500'}`} />
              <span>Under-Cab LED: {ledLighting ? 'ON' : 'OFF'}</span>
            </button>

            <button
              onClick={() => setDoorsOpen(!doorsOpen)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 backdrop-blur-md transition-all cursor-pointer border ${
                doorsOpen
                  ? 'bg-[#C8A96A]/20 text-[#C8A96A] border-[#C8A96A]/40'
                  : 'bg-neutral-900/80 text-gray-400 border-white/10'
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>{doorsOpen ? 'Close Cabinets' : 'Inspect Cabinets (Open)'}</span>
            </button>
          </div>

          {/* Real-time Dimensions Badge */}
          <div className="absolute top-4 right-4 z-10 bg-black/75 backdrop-blur-md border border-white/10 px-3 py-1.5 rounded-lg text-[11px] text-gray-300 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#C8A96A] animate-ping" />
            <span>Room Scale: 12ft × 9ft Calibrated</span>
          </div>

          <div className="absolute bottom-4 right-4 z-10 text-[10px] text-gray-500 bg-black/60 px-2 py-1 rounded backdrop-blur">
            Drag to Rotate • Scroll to Zoom
          </div>
        </div>

        {/* Customization Control Panel (5 Cols) in Manus Dark/Gold styling */}
        <div className="lg:col-span-5 bg-[#14120E] border-t lg:border-t-0 lg:border-l border-white/10 p-5 sm:p-6 overflow-y-auto max-h-[560px] space-y-6">
          {/* 1. Layout Selection */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-[#C8A96A] flex items-center justify-between mb-2.5">
              <span>1. Room Architecture & Layout</span>
              <span className="text-[11px] text-gray-400 lowercase font-normal">customizable dimensions</span>
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
              {[
                { id: 'l-shape', label: 'L-Shaped', sub: 'Popular' },
                { id: 'u-shape', label: 'U-Shaped', sub: 'Spacious' },
                { id: 'parallel', label: 'Parallel', sub: 'Galley' },
                { id: 'island', label: 'Island', sub: 'Luxury' },
                { id: 'straight', label: 'Straight', sub: 'Compact' },
              ].map(l => (
                <button
                  key={l.id}
                  onClick={() => setLayout(l.id as any)}
                  className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center ${
                    layout === l.id
                      ? 'bg-[#C8A96A]/20 border-[#C8A96A] text-white font-bold shadow-lg shadow-[#C8A96A]/10'
                      : 'bg-neutral-900 border-white/10 text-gray-400 hover:text-white hover:border-white/20'
                  }`}
                >
                  <span className="text-xs font-semibold">{l.label}</span>
                  <span className="text-[10px] text-gray-400 font-normal">{l.sub}</span>
                </button>
              ))}
            </div>
          </div>

          {/* 2. Collection Tier Selection */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-[#C8A96A] flex items-center justify-between mb-2.5">
              <span>2. Material & Finish Collection</span>
              <span className="text-[11px] text-gray-400 font-normal">German Hardware Included</span>
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'essential', name: 'Essential', finish: 'Laminate', warranty: '5 Yrs' },
                { id: 'royale', name: 'Royale', finish: 'Acrylic', warranty: '10 Yrs' },
                { id: 'imperial', name: 'Imperial', finish: 'Super PU', warranty: '12 Yrs' },
              ].map(pkg => (
                <button
                  key={pkg.id}
                  onClick={() => setPackageTier(pkg.id as any)}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer relative ${
                    packageTier === pkg.id
                      ? 'bg-[#C8A96A]/20 border-[#C8A96A] text-white shadow-lg'
                      : 'bg-neutral-900 border-white/10 text-gray-400 hover:text-white hover:border-white/20'
                  }`}
                >
                  {packageTier === pkg.id && (
                    <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-[#C8A96A]" />
                  )}
                  <div className="text-xs font-bold">{pkg.name}</div>
                  <div className="text-[11px] text-[#C8A96A] font-medium">{pkg.finish}</div>
                  <div className="text-[10px] text-gray-400 mt-1">{pkg.warranty} Warranty</div>
                </button>
              ))}
            </div>
          </div>

          {/* 3. Color & Texture Swatches */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-[#C8A96A] flex items-center justify-between mb-2.5">
              <span>3. Shutter Color Palette</span>
              <span className="text-xs text-white font-medium">{finishName}</span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {FINISH_PALETTES[packageTier].map(swatch => {
                const isSelected = finishColor.toLowerCase() === swatch.color.toLowerCase();
                return (
                  <button
                    key={swatch.id}
                    onClick={() => {
                      setFinishColor(swatch.color);
                      setFinishName(swatch.name);
                    }}
                    className={`p-2 rounded-xl border flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                      isSelected
                        ? 'border-[#C8A96A] bg-[#C8A96A]/15 text-white'
                        : 'border-white/10 bg-neutral-900 text-gray-400 hover:border-white/30'
                    }`}
                  >
                    <div
                      className="w-full h-8 rounded-lg shadow-inner relative flex items-center justify-center border border-white/20"
                      style={{ backgroundColor: swatch.color }}
                    >
                      {isSelected && <Check className="w-4 h-4 text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)]" />}
                    </div>
                    <span className="text-[11px] font-medium text-center line-clamp-1">{swatch.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 4. Countertop Selection */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-[#C8A96A] mb-2.5 block">
              4. Countertop Stone Choice
            </label>
            <div className="grid grid-cols-2 gap-2">
              {COUNTERTOP_OPTIONS.map(c => (
                <button
                  key={c.id}
                  onClick={() => setCountertopType(c.id)}
                  className={`p-2.5 rounded-xl border text-left flex items-center gap-2.5 transition-all cursor-pointer ${
                    countertopType === c.id
                      ? 'border-[#C8A96A] bg-[#C8A96A]/15 text-white'
                      : 'border-white/10 bg-neutral-900 text-gray-400 hover:border-white/20'
                  }`}
                >
                  <div className="w-5 h-5 rounded-full border border-white/30 shrink-0" style={{ backgroundColor: c.color }} />
                  <span className="text-xs font-medium line-clamp-1">{c.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Price & Booking Call to Action */}
          <div className="p-4 rounded-xl bg-gradient-to-br from-[#1C1A14] to-[#121215] border border-[#C8A96A]/40 space-y-3">
            <div className="flex items-baseline justify-between">
              <div>
                <span className="text-[10px] uppercase font-bold tracking-widest text-[#C8A96A] block">
                  Estimated Fabrication & Hardware Cost
                </span>
                <span className="text-xs text-gray-400">Includes BWP IS:710 Marine Ply + Fitting</span>
              </div>
              <div className="text-right">
                <div className="text-xl sm:text-2xl font-bold font-serif text-[#C8A96A] flex items-center justify-end">
                  <IndianRupee className="w-4 h-4" />
                  {estimatedPrice.toLocaleString('en-IN')}*
                </div>
                <span className="text-[10px] text-gray-400">Exact quote after laser site visit</span>
              </div>
            </div>

            <button
              onClick={handleBookNow}
              className="w-full py-3.5 px-4 rounded-xl gold-gradient-bg text-[#0F0F0F] font-bold text-xs sm:text-sm tracking-wide hover:brightness-110 shadow-lg shadow-[#C8A96A]/20 transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <Calendar className="w-4 h-4" />
              <span>Book Free On-Site Consultation</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
