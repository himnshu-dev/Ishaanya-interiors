// @ts-nocheck
import React, { useState, useEffect } from 'react';
import { 
  fetchAuditLogs, 
  exportAuditLogsCSV, 
  exportAuditLogsJSON, 
  AUDIT_CATEGORIES, 
  AUDIT_SQL_SCHEMA, 
  AuditLog 
} from '../lib/audit-logs';

interface SecurityAuditViewProps {
  supabase: any;
  currentActorEmail?: string;
}

export const SecurityAuditView: React.FC<SecurityAuditViewProps> = ({ supabase, currentActorEmail }) => {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('ALL');
  const [selectedSeverity, setSelectedSeverity] = useState('all');
  const [selectedLog, setSelectedLog] = useState<AuditLog | null>(null);
  const [showSqlModal, setShowSqlModal] = useState(false);
  const [copiedSql, setCopiedSql] = useState(false);

  const loadLogs = async () => {
    setLoading(true);
    try {
      const data = await fetchAuditLogs(supabase);
      setLogs(data);
    } catch (err) {
      console.warn('Failed to fetch audit logs:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadLogs();
  }, [supabase]);

  // Filter logs
  const filteredLogs = logs.filter(l => {
    if (selectedCategory !== 'ALL' && l.category !== selectedCategory) return false;
    if (selectedSeverity !== 'all' && l.severity !== selectedSeverity) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      const matchAction = (l.action || '').toLowerCase().includes(q);
      const matchActor = (l.actor_email || '').toLowerCase().includes(q);
      const matchDetails = JSON.stringify(l.details || {}).toLowerCase().includes(q);
      if (!matchAction && !matchActor && !matchDetails) return false;
    }
    return true;
  });

  // Calculate summary metrics
  const totalEvents = logs.length;
  const authEvents = logs.filter(l => l.category === 'AUTH').length;
  const contentMutations = logs.filter(l => l.category === 'CMS' || l.category === 'PROJECTS' || l.category === 'LEADS').length;
  const criticalWarnings = logs.filter(l => l.severity === 'critical' || l.severity === 'warning').length;

  const copySql = () => {
    navigator.clipboard.writeText(AUDIT_SQL_SCHEMA);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2500);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-gray-200/80 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold mb-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            Real-Time Audit Trail Active
          </div>
          <h2 className="text-2xl font-serif font-bold text-[#0F0F0F]">Security & Operational Audit</h2>
          <p className="text-xs text-gray-600 mt-1">
            Tracking all owner actions, authentication changes, CMS updates, and database operations.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => setShowSqlModal(true)}
            className="px-3.5 py-2 text-xs font-semibold rounded-lg border border-gray-300 hover:border-[#C8A96A] bg-white text-gray-700 hover:text-[#0F0F0F] transition-all flex items-center gap-1.5 shadow-sm cursor-pointer"
          >
            <span>📜</span> SQL Schema
          </button>
          <button
            onClick={() => exportAuditLogsCSV(filteredLogs)}
            className="px-3.5 py-2 text-xs font-semibold rounded-lg border border-gray-300 hover:border-gray-400 bg-white text-gray-700 transition-all flex items-center gap-1.5 shadow-sm cursor-pointer"
          >
            <span>📥</span> Export CSV
          </button>
          <button
            onClick={() => exportAuditLogsJSON(filteredLogs)}
            className="px-3.5 py-2 text-xs font-semibold rounded-lg border border-gray-300 hover:border-gray-400 bg-white text-gray-700 transition-all flex items-center gap-1.5 shadow-sm cursor-pointer"
          >
            <span>{ }</span> JSON
          </button>
          <button
            onClick={loadLogs}
            disabled={loading}
            className="gold-gradient-bg text-[#0F0F0F] font-bold text-xs px-4 py-2 rounded-lg hover:brightness-110 shadow-md transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
          >
            <span className={loading ? "animate-spin" : ""}>🔄</span> Refresh
          </button>
        </div>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-sm space-y-1">
          <p className="text-[11px] font-semibold text-gray-500 uppercase tracking-wider">Total Audit Events</p>
          <p className="text-2xl font-bold font-serif text-[#0F0F0F]">{totalEvents}</p>
          <p className="text-[10px] text-gray-400">Recorded in Supabase trail</p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-sm space-y-1">
          <p className="text-[11px] font-semibold text-gray-500 uppercase tracking-wider">Auth Logins & Syncs</p>
          <p className="text-2xl font-bold font-serif text-sky-700">{authEvents}</p>
          <p className="text-[10px] text-gray-400">Owner session activities</p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-sm space-y-1">
          <p className="text-[11px] font-semibold text-gray-500 uppercase tracking-wider">Business & CMS Changes</p>
          <p className="text-2xl font-bold font-serif text-[#C8A96A]">{contentMutations}</p>
          <p className="text-[10px] text-gray-400">Content, leads & projects</p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-sm space-y-1">
          <p className="text-[11px] font-semibold text-gray-500 uppercase tracking-wider">Warnings & Alerts</p>
          <p className="text-2xl font-bold font-serif text-rose-600">{criticalWarnings}</p>
          <p className="text-[10px] text-gray-400">Requires review</p>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm space-y-3">
        <div className="flex flex-col md:flex-row gap-3">
          <div className="flex-1 relative">
            <input
              type="text"
              placeholder="Search by action, actor email, or details..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-[#F5F5F5] border border-gray-200 rounded-lg px-3.5 py-2 text-xs focus:outline-none focus:border-[#C8A96A] text-[#1A1A1A]"
            />
            {search && (
              <button 
                onClick={() => setSearch('')}
                className="absolute right-3 top-2 text-gray-400 hover:text-gray-600 text-xs"
              >
                ✕
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <select
              value={selectedSeverity}
              onChange={(e) => setSelectedSeverity(e.target.value)}
              className="bg-[#F5F5F5] border border-gray-200 rounded-lg px-3 py-2 text-xs text-[#1A1A1A] focus:outline-none focus:border-[#C8A96A]"
            >
              <option value="all">All Severities</option>
              <option value="info">Info</option>
              <option value="warning">Warning</option>
              <option value="critical">Critical</option>
            </select>
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex flex-wrap gap-1.5 pt-1">
          {AUDIT_CATEGORIES.map(cat => {
            const active = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1 rounded-full text-[11px] font-medium transition-colors cursor-pointer ${
                  active 
                    ? 'bg-[#0F0F0F] text-[#C8A96A] font-semibold' 
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {cat.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Logs Table */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-neutral-50 text-gray-500 border-b border-gray-200 font-semibold uppercase text-[10px] tracking-wider">
                <th className="py-3 px-4">Timestamp</th>
                <th className="py-3 px-4">Actor</th>
                <th className="py-3 px-4">Action</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Severity</th>
                <th className="py-3 px-4">Details Summary</th>
                <th className="py-3 px-4 text-right">Inspect</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 text-gray-700">
              {loading ? (
                <tr>
                  <td colSpan={7} className="text-center py-12 text-gray-400">
                    <span className="inline-block animate-spin mr-2">🔄</span> Loading audit records from Supabase...
                  </td>
                </tr>
              ) : filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-12 text-gray-400">
                    No audit records matching current filter.
                  </td>
                </tr>
              ) : (
                filteredLogs.map(log => {
                  const severityBadge = 
                    log.severity === 'critical' 
                      ? 'bg-rose-50 text-rose-700 border-rose-200' 
                      : log.severity === 'warning'
                      ? 'bg-amber-50 text-amber-700 border-amber-200'
                      : 'bg-sky-50 text-sky-700 border-sky-200';

                  const dateObj = new Date(log.timestamp);
                  const timeStr = dateObj.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
                  const dateStr = dateObj.toLocaleDateString('en-IN', { month: 'short', day: 'numeric' });

                  return (
                    <tr key={log.id} className="hover:bg-neutral-50/80 transition-colors">
                      <td className="py-3 px-4 whitespace-nowrap font-mono text-[11px]">
                        <span className="font-semibold text-gray-900">{dateStr}</span>{' '}
                        <span className="text-gray-400">{timeStr}</span>
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap font-medium text-gray-800">
                        {log.actor_email || 'Owner'}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span className="font-mono font-semibold text-[#0F0F0F] bg-gray-100 px-2 py-0.5 rounded text-[11px]">
                          {log.action}
                        </span>
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-neutral-100 text-neutral-600">
                          {log.category}
                        </span>
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase border ${severityBadge}`}>
                          {log.severity}
                        </span>
                      </td>
                      <td className="py-3 px-4 max-w-xs truncate text-gray-600 font-mono text-[11px]">
                        {typeof log.details === 'object' 
                          ? JSON.stringify(log.details)
                          : String(log.details || '-')}
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <button
                          onClick={() => setSelectedLog(log)}
                          className="text-[#C8A96A] hover:text-[#9A7D3A] font-semibold text-xs cursor-pointer"
                        >
                          Details →
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Inspect Log Modal */}
      {selectedLog && (
        <div className="fixed inset-0 z-[300] bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-[#C8A96A]/40 max-w-xl w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-gray-200 pb-3">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-gray-500">Audit Event Details</span>
                <h3 className="text-lg font-serif font-bold text-[#0F0F0F]">{selectedLog.action}</h3>
              </div>
              <button
                onClick={() => setSelectedLog(null)}
                className="text-gray-400 hover:text-gray-700 p-1 text-sm cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs bg-[#F5F5F5] p-3.5 rounded-xl border border-gray-200">
              <div>
                <span className="text-gray-500 block text-[10px] uppercase font-bold">Event ID</span>
                <span className="font-mono text-gray-800">{selectedLog.id}</span>
              </div>
              <div>
                <span className="text-gray-500 block text-[10px] uppercase font-bold">Exact Timestamp</span>
                <span className="font-mono text-gray-800">{new Date(selectedLog.timestamp).toISOString()}</span>
              </div>
              <div>
                <span className="text-gray-500 block text-[10px] uppercase font-bold">Actor Email</span>
                <span className="font-semibold text-gray-800">{selectedLog.actor_email}</span>
              </div>
              <div>
                <span className="text-gray-500 block text-[10px] uppercase font-bold">Category & Severity</span>
                <span className="font-bold uppercase text-[#0F0F0F]">{selectedLog.category} • {selectedLog.severity}</span>
              </div>
            </div>

            <div>
              <span className="text-xs font-bold text-[#0F0F0F] block mb-1">Payload Metadata (JSON)</span>
              <pre className="bg-[#0F0F0F] text-[#C8A96A] p-4 rounded-xl text-xs font-mono overflow-x-auto max-h-60 border border-neutral-800">
                {JSON.stringify(selectedLog.details || {}, null, 2)}
              </pre>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setSelectedLog(null)}
                className="bg-[#0F0F0F] text-white px-5 py-2 rounded-lg text-xs font-semibold hover:bg-neutral-800 transition-colors cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SQL Setup Modal */}
      {showSqlModal && (
        <div className="fixed inset-0 z-[300] bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-[#C8A96A]/40 max-w-2xl w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-gray-200 pb-3">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700">Supabase SQL DDL</span>
                <h3 className="text-lg font-serif font-bold text-[#0F0F0F]">Dedicated audit_logs Table Setup</h3>
              </div>
              <button
                onClick={() => setShowSqlModal(false)}
                className="text-gray-400 hover:text-gray-700 p-1 text-sm cursor-pointer"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-gray-600">
              Copy this SQL script and execute it in your <strong>Supabase Dashboard &gt; SQL Editor</strong> to create the dedicated <code className="bg-gray-100 px-1 py-0.5 rounded text-gray-800">public.audit_logs</code> table with indexes and RLS policies. The system is already operating safely with the dual-write layer.
            </p>

            <div className="relative">
              <pre className="bg-[#0F0F0F] text-[#C8A96A] p-4 rounded-xl text-xs font-mono overflow-x-auto max-h-72 border border-neutral-800 leading-relaxed select-all">
                {AUDIT_SQL_SCHEMA}
              </pre>
              <button
                onClick={copySql}
                className="absolute top-3 right-3 bg-[#C8A96A] text-[#0F0F0F] font-bold text-xs px-3.5 py-1.5 rounded-md hover:brightness-110 shadow-md cursor-pointer transition-all"
              >
                {copiedSql ? '✓ Copied!' : '📋 Copy SQL'}
              </button>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setShowSqlModal(false)}
                className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg text-xs font-semibold hover:bg-gray-200 cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
