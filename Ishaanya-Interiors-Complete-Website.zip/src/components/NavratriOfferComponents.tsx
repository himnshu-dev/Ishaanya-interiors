import React, { useState } from 'react';
import { Sparkles, Clock, Tag, ArrowUpRight, Check, AlertCircle, Copy, CheckCheck } from 'lucide-react';
import { 
  NAVRATRI_OFFER_CONFIG, 
  useNavratriCountdown 
} from '../lib/navratri-offer';

interface NavratriBannerProps {
  onClaimOffer: () => void;
  className?: string;
}

/**
 * Top announcement strip for Navratri Special Offer
 */
export const NavratriOfferBanner: React.FC<NavratriBannerProps> = ({ onClaimOffer, className = '' }) => {
  const status = useNavratriCountdown();
  const [copied, setCopied] = useState(false);

  const copyCode = (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      navigator.clipboard.writeText(NAVRATRI_OFFER_CONFIG.code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {}
  };

  return (
    <div 
      className={`relative z-30 border-b border-[#c8a96a]/25 bg-gradient-to-r from-[#171614] via-[#201d17] to-[#171614] text-white px-4 py-2.5 transition-all ${className}`}
      role="region"
      aria-label="Navratri Special Offer Announcement"
    >
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3 text-xs">
        {/* Left: Festive Headline & Code */}
        <div className="flex flex-wrap items-center justify-center md:justify-start gap-2.5 text-center md:text-left">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#c8a96a]/20 border border-[#c8a96a]/50 text-[#f3e5ab] font-bold text-[10px] tracking-wider uppercase">
            <Sparkles size={11} className="text-[#c8a96a] animate-pulse" />
            Navratri Special
          </span>
          <span className="font-medium text-white/95">
            Get <strong className="text-[#f3e5ab] font-bold">10% OFF</strong> on Modular Kitchens
          </span>
          <button 
            type="button"
            onClick={copyCode}
            title="Click to copy code"
            className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-black/50 border border-[#c8a96a]/40 text-[#f3e5ab] font-mono text-[11px] hover:border-[#c8a96a] transition-colors cursor-pointer"
          >
            <Tag size={11} className="text-[#c8a96a]" />
            <code>{NAVRATRI_OFFER_CONFIG.code}</code>
            {copied ? <CheckCheck size={11} className="text-emerald-400" /> : <Copy size={10} className="text-white/60" />}
          </button>
        </div>

        {/* Right: Live Countdown or Expired status & CTA */}
        <div className="flex flex-wrap items-center justify-center md:justify-end gap-3">
          {status.isExpired ? (
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded bg-red-950/70 border border-red-500/40 text-red-200 font-semibold text-xs tracking-wide">
              <AlertCircle size={13} className="text-red-400" />
              <span>Offer Expired</span>
            </div>
          ) : (
            <div className="inline-flex items-center gap-2 bg-black/60 px-3 py-1 rounded border border-white/10 font-mono text-xs text-[#f3e5ab]">
              <Clock size={12} className="text-[#c8a96a]" />
              <span className="tracking-wider">
                {String(status.days).padStart(2, '0')}d : {String(status.hours).padStart(2, '0')}h : {String(status.minutes).padStart(2, '0')}m : {String(status.seconds).padStart(2, '0')}s
              </span>
            </div>
          )}

          {!status.isExpired ? (
            <button
              type="button"
              onClick={onClaimOffer}
              className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded bg-[#c8a96a] hover:bg-[#d8b97a] text-black font-bold text-xs tracking-wide transition-all shadow-sm hover:scale-[1.02] cursor-pointer"
            >
              <span>Claim Your Offer</span>
              <ArrowUpRight size={13} />
            </button>
          ) : (
            <span className="text-[11px] text-gray-400 italic">
              Concluded on 20 Oct 2026
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

interface OffersAndDiscountsSectionProps {
  onClaimOffer: () => void;
  sectionId?: string;
  className?: string;
}

/**
 * Public-facing "Offers & Discounts" Section for Homepage and /modular-kitchen-dehradun
 */
export const OffersAndDiscountsSection: React.FC<OffersAndDiscountsSectionProps> = ({ 
  onClaimOffer,
  sectionId = 'offers-discounts',
  className = ''
}) => {
  const status = useNavratriCountdown();
  const [copied, setCopied] = useState(false);

  const handleCopyCode = () => {
    try {
      navigator.clipboard.writeText(NAVRATRI_OFFER_CONFIG.code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {}
  };

  return (
    <section 
      id={sectionId} 
      className={`showroom-offers-section relative py-16 px-4 sm:px-6 bg-[#111110] text-[#f5f2eb] border-y border-[#c8a96a]/20 overflow-hidden ${className}`}
      aria-label="Offers & Discounts"
    >
      {/* Background ambient lighting */}
      <div 
        className="pointer-events-none absolute -top-40 left-1/2 -translate-x-1/2 w-[700px] h-[360px] bg-[radial-gradient(ellipse_at_center,rgba(200,169,106,0.12)_0%,transparent_70%)] blur-2xl" 
        aria-hidden="true" 
      />

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Section Tag */}
        <div className="showroom-section-tag flex items-center justify-between mb-4 text-[11px] tracking-widest text-[#c8a96a] uppercase font-bold border-b border-white/10 pb-2">
          <span>/ OFFERS &amp; DISCOUNTS — FESTIVE SEASON</span>
          <span className="hidden sm:inline text-white/50">DEHRADUN · UTTARAKHAND</span>
        </div>

        {/* Section Heading */}
        <div className="mb-10 text-center max-w-2xl mx-auto">
          <span className="text-xs font-semibold text-[#c8a96a] tracking-widest uppercase block mb-1">
            LIMITED-PERIOD FESTIVE BENEFIT
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif text-white leading-tight">
            Navratri Special — <br className="hidden sm:inline" />
            <em className="text-[#c8a96a] not-italic italic font-normal">Get 10% OFF on Modular Kitchens</em>
          </h2>
          <p className="mt-3 text-sm text-[#9e9589] leading-relaxed">
            {NAVRATRI_OFFER_CONFIG.subheadline}
          </p>
        </div>

        {/* Main Offer Card */}
        <div className="relative rounded-2xl bg-gradient-to-b from-[#1c1b18] via-[#161614] to-[#121210] border border-[#c8a96a]/40 p-6 sm:p-10 shadow-2xl backdrop-blur-sm">
          {/* Subtle Top Watermark Badge */}
          <div className="absolute top-4 right-4 sm:top-6 sm:right-6">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#c8a96a]/15 border border-[#c8a96a]/50 text-[#f3e5ab] text-xs font-semibold">
              <Sparkles size={13} className="text-[#c8a96a]" />
              10% Instant Savings
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left Column: Offer Details & Code */}
            <div className="lg:col-span-7 space-y-5">
              <div>
                <span className="text-[11px] uppercase tracking-widest text-emerald-400 font-semibold block mb-1">
                  ✓ Verified Festive Privilege
                </span>
                <h3 className="text-2xl sm:text-3xl font-serif text-white font-normal">
                  10% OFF on Modular Kitchens
                </h3>
                <p className="text-xs sm:text-sm text-[#9e9589] mt-2 leading-relaxed">
                  Applies across all layout formats (Island, L-Shape, U-Shape, Parallel) and finishes (Laminate, Acrylic, Super Matte PU, and Natural Wood Veneer).
                </p>
              </div>

              {/* Offer Code & Copy Action */}
              <div className="flex flex-wrap items-center gap-3 pt-1">
                <span className="text-xs text-[#9e9589] font-medium">Use Offer Code:</span>
                <div className="flex items-center rounded-lg bg-black/60 border border-[#c8a96a]/60 px-3.5 py-1.5 gap-2.5">
                  <span className="font-mono text-sm sm:text-base font-bold text-[#f3e5ab] tracking-wider select-all">
                    {NAVRATRI_OFFER_CONFIG.code}
                  </span>
                  <button
                    type="button"
                    onClick={handleCopyCode}
                    className="text-xs text-[#c8a96a] hover:text-white flex items-center gap-1 transition-colors cursor-pointer"
                    title="Copy offer code"
                  >
                    {copied ? (
                      <>
                        <CheckCheck size={14} className="text-emerald-400" />
                        <span className="text-emerald-400 font-medium">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy size={13} />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Offer Validity Info */}
              <div className="pt-2 text-xs text-[#9e9589] space-y-1 border-t border-white/5">
                <div className="flex items-center gap-2">
                  <span className="font-medium text-white/80">Validity:</span>
                  <span className="text-[#f3e5ab] font-medium">{NAVRATRI_OFFER_CONFIG.validityText}</span>
                </div>
                <div className="flex items-center gap-2 text-[11px] text-[#9e9589]">
                  <span>Timezone:</span>
                  <span className="font-mono">Asia/Kolkata (IST · UTC+05:30)</span>
                </div>
              </div>

              {/* Feature Highlights */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3">
                <div className="flex items-start gap-2 text-xs text-white/90">
                  <Check size={14} className="text-[#c8a96a] shrink-0 mt-0.5" />
                  <span>100% Waterproof IS:710 Marine Plywood</span>
                </div>
                <div className="flex items-start gap-2 text-xs text-white/90">
                  <Check size={14} className="text-[#c8a96a] shrink-0 mt-0.5" />
                  <span>Free 3D Design &amp; Site Laser Measurement</span>
                </div>
                <div className="flex items-start gap-2 text-xs text-white/90">
                  <Check size={14} className="text-[#c8a96a] shrink-0 mt-0.5" />
                  <span>10-Year Blum / Hettich Warranty</span>
                </div>
              </div>
            </div>

            {/* Right Column: Live Countdown Box & Claim CTA */}
            <div className="lg:col-span-5 bg-[#0e0e0d] p-6 sm:p-7 rounded-xl border border-white/10 text-center space-y-5">
              <div>
                <span className="text-[11px] font-bold tracking-widest uppercase text-[#c8a96a] block">
                  {status.isExpired ? 'FESTIVE OFFER STATUS' : status.isPending ? 'COUNTDOWN TO LAUNCH' : 'OFFER CLOSES IN'}
                </span>
                <p className="text-xs text-white/60 mt-0.5">
                  {status.isExpired 
                    ? 'Validity ended on 20 October 2026, 11:59 PM IST'
                    : 'Indian Standard Time (IST)'}
                </p>
              </div>

              {/* Countdown Display Units or Expired Message */}
              {status.isExpired ? (
                <div className="py-6 px-4 rounded-xl bg-red-950/40 border border-red-500/40 text-center space-y-2">
                  <AlertCircle size={28} className="text-red-400 mx-auto" />
                  <div className="text-2xl font-serif font-bold text-red-200 tracking-wide uppercase">
                    Offer Expired
                  </div>
                  <p className="text-xs text-red-300/80 max-w-xs mx-auto">
                    The Navratri Special 10% discount has ended. You may still request a standard consultation with our studio craftsmen.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-4 gap-2 sm:gap-3">
                  <div className="bg-[#1b1a17] border border-[#c8a96a]/30 rounded-lg p-2.5 sm:p-3">
                    <span className="block text-2xl sm:text-3xl font-mono font-bold text-white">
                      {String(status.days).padStart(2, '0')}
                    </span>
                    <span className="text-[10px] uppercase tracking-wider text-[#9e9589] block mt-1">Days</span>
                  </div>
                  <div className="bg-[#1b1a17] border border-[#c8a96a]/30 rounded-lg p-2.5 sm:p-3">
                    <span className="block text-2xl sm:text-3xl font-mono font-bold text-white">
                      {String(status.hours).padStart(2, '0')}
                    </span>
                    <span className="text-[10px] uppercase tracking-wider text-[#9e9589] block mt-1">Hours</span>
                  </div>
                  <div className="bg-[#1b1a17] border border-[#c8a96a]/30 rounded-lg p-2.5 sm:p-3">
                    <span className="block text-2xl sm:text-3xl font-mono font-bold text-white">
                      {String(status.minutes).padStart(2, '0')}
                    </span>
                    <span className="text-[10px] uppercase tracking-wider text-[#9e9589] block mt-1">Mins</span>
                  </div>
                  <div className="bg-[#1b1a17] border border-[#c8a96a]/30 rounded-lg p-2.5 sm:p-3">
                    <span className="block text-2xl sm:text-3xl font-mono font-bold text-[#f3e5ab]">
                      {String(status.seconds).padStart(2, '0')}
                    </span>
                    <span className="text-[10px] uppercase tracking-wider text-[#9e9589] block mt-1">Secs</span>
                  </div>
                </div>
              )}

              {/* Claim Action Button */}
              <div>
                {!status.isExpired ? (
                  <button
                    type="button"
                    onClick={onClaimOffer}
                    className="w-full py-3.5 px-6 rounded-lg bg-gradient-to-r from-[#c8a96a] via-[#e2c585] to-[#c8a96a] text-black font-bold text-sm tracking-wide transition-all shadow-lg shadow-[#c8a96a]/15 hover:brightness-110 active:scale-[0.99] flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>Claim Your Offer</span>
                    <ArrowUpRight size={17} />
                  </button>
                ) : (
                  <button
                    type="button"
                    disabled
                    className="w-full py-3 px-6 rounded-lg bg-white/5 border border-white/10 text-gray-500 font-semibold text-xs cursor-not-allowed"
                  >
                    Offer Expired — Unavailable
                  </button>
                )}
                <span className="text-[11px] text-[#9e9589] block mt-2">
                  {!status.isExpired 
                    ? 'Populates "Navratri10%" in your design enquiry form below' 
                    : 'Standard modular kitchen bookings remain open'}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
