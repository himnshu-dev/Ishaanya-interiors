// @ts-nocheck
import React, { useEffect, useRef, useState, useCallback } from 'react';
import { createRoot } from 'react-dom/client';
import { 
  ArrowUpRight, Check, ChevronRight, Clock3, Compass, Gem, 
  Instagram, Layers3, MapPin, Menu, MessageCircle, Phone, 
  Ruler, Send, Sparkles, X, Zap 
} from 'lucide-react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import './index.css';

import { SecurityAuditView } from './components/SecurityAuditView';
import { ExecutiveReportsView } from './components/ExecutiveReportsView';
import { AiStudioSaveModal, AiGenerationsHistoryGrid } from './components/AiStudioEnhancements';
import { DatabaseMigrationModal } from './components/DatabaseMigrationModal';
import { recordAuditLog, fetchAuditLogs } from './lib/audit-logs';
import { checkDedicatedTablesAvailability, migrateLegacyToDedicatedTables } from './lib/business-records';

if (typeof window !== 'undefined') {
  window.SecurityAuditView = SecurityAuditView;
  window.ExecutiveReportsView = ExecutiveReportsView;
  window.AiStudioSaveModal = AiStudioSaveModal;
  window.AiGenerationsHistoryGrid = AiGenerationsHistoryGrid;
  window.DatabaseMigrationModal = DatabaseMigrationModal;
  window.recordAuditLog = recordAuditLog;
  window.fetchAuditLogs = fetchAuditLogs;
  window.checkDedicatedTablesAvailability = checkDedicatedTablesAvailability;
  window.migrateLegacyToDedicatedTables = migrateLegacyToDedicatedTables;
}

const ASSET = '/images/';
const isPublicPath = () => typeof window !== 'undefined' && !/^\/(owner|owner-dashboard|reset-password)/.test(window.location.pathname);

export const KITCHEN_PACKAGES = [
  'Essential Luxury — Laminate / HPL',
  'Premium Royale — Acrylic',
  'Bespoke Imperial — PU Finish'
];

export const KITCHEN_LAYOUTS = [
  'Straight Kitchen',
  'Parallel / Galley Kitchen',
  'L-Shaped Kitchen',
  'U-Shaped Kitchen',
  'Island Kitchen',
  'Peninsula Kitchen',
  'Custom Layout / Not Sure Yet'
];

function KitchenStage({ kitchenPage = false }: { kitchenPage?: boolean }) {
  return (
    <div className="showroom-stage" aria-label="3D kitchen visualisation">
      <div className="showroom-stage-glow" />
      <div className="showroom-stage-label"><span>01</span> YOUR FUTURE KITCHEN</div>
      <img className="showroom-brand-watermark" src={`${ASSET}ishaanya-brand-logo.png`} alt="Ishaanya Interiors" />
      <div className="showroom-real-space"><img src={`${ASSET}luxury_modular_kitchen.jpg`} alt="Ishaanya Interiors modular kitchen" /></div>
      <div className="showroom-room">
        <div className="showroom-wall-grid" />
        <div className="showroom-pendant p-one"><i /></div>
        <div className="showroom-pendant p-two"><i /></div>
        <div className="showroom-back-cabinets"><b /><b /><b /><b /><b /><b /></div>
        <div className="showroom-counter"><span /><span /><span /></div>
        <div className="showroom-island"><div className="island-top" /><div className="island-front"><span /><span /><span /></div><div className="island-shadow" /></div>
        <div className="showroom-stool stool-a" /><div className="showroom-stool stool-b" />
        <div className="showroom-floor" />
      </div>
      <a className="showroom-float-card card-finish showroom-float-link" href={kitchenPage ? "#configurator" : "/modular-kitchen-dehradun#configurator"} aria-label="Explore kitchen finishes">
        <small>YOUR SELECTED LOOK</small>
        <strong>Walnut / Sand</strong>
        <span><i /> Warm natural veneer <ArrowUpRight size={13} /></span>
      </a>
      <a className="showroom-float-card card-dim showroom-float-link" href={kitchenPage ? "#contact" : "/modular-kitchen-dehradun#contact"} aria-label="Plan a kitchen for your space">
        <Ruler size={15} />
        <span>MADE FOR<br /><b>YOUR SPACE</b></span>
        <ArrowUpRight size={13} />
      </a>
      <div className="showroom-orbit orbit-a" />
      <div className="showroom-orbit orbit-b" />
    </div>
  );
}

function KitchenConfigurator() {
  const mountRef = useRef<HTMLDivElement>(null);
  const [layout, setLayout] = useState('island');
  const [finish, setFinish] = useState('walnut');
  const [countertop, setCountertop] = useState('marble');

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#171715');
    scene.fog = new THREE.Fog('#171715', 8, 22);

    const camera = new THREE.PerspectiveCamera(34, mount.clientWidth / mount.clientHeight, .1, 100);
    camera.position.set(7.8, 5.5, 8.4);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(mount.clientWidth, mount.clientHeight);
    renderer.shadowMap.enabled = true;
    // Updated shadow map type to fix deprecation warning
    renderer.shadowMap.type = THREE.PCFShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.25;
    mount.appendChild(renderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = .07;
    controls.minDistance = 5;
    controls.maxDistance = 15;
    controls.maxPolarAngle = Math.PI / 2.05;
    controls.target.set(0, 1.3, 0);

    const group = new THREE.Group();
    scene.add(group);

    const finishColors: Record<string, number> = { 
      walnut: 0x6f4b36, 
      ivory: 0xd9d1bf, 
      sage: 0x56645c, 
      charcoal: 0x252523, 
      glossy: 0xeee9dc 
    };
    const body = new THREE.MeshStandardMaterial({ 
      color: finishColors[finish], 
      roughness: finish === 'glossy' ? .08 : .32, 
      metalness: finish === 'glossy' ? .18 : .06 
    });

    const counterColors: Record<string, number> = { 
      marble: 0xe9e4d8, 
      quartz: 0xcfc8ba, 
      stone: 0x45413b 
    };
    const top = new THREE.MeshStandardMaterial({ 
      color: counterColors[countertop], 
      roughness: countertop === 'marble' ? .18 : .28, 
      metalness: .08 
    });

    const brass = new THREE.MeshStandardMaterial({ color: 0xc8a96a, roughness: .2, metalness: .75 });
    const dark = new THREE.MeshStandardMaterial({ color: 0x191816, roughness: .55 });

    const box = (w:number,h:number,d:number,x:number,y:number,z:number,material:THREE.Material) => {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(w,h,d), material);
      mesh.position.set(x,y,z);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      group.add(mesh);
      const edge = new THREE.LineSegments(new THREE.EdgesGeometry(mesh.geometry), new THREE.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: .08 }));
      edge.position.copy(mesh.position);
      group.add(edge);
      return mesh;
    };

    const cabinet = (x:number,z:number,w=1.08,h=1.65,d=.62) => {
      box(w,h,d,x,h/2+.18,z,body);
      box(w+.035,.055,d+.035,x,h+.19,z,top);
      const door = box(w-.09,h-.14,.045,x,.94,z-d/2-.035,body);
      box(w-.2,h-.25,.018,x,.94,z-d/2-.065,body);
      box(w*.58,.035,.035,x,.86,z-d/2-.085,brass);
      box(w*.9,.035,.035,x,.21,z-d/2-.08,dark);
      return door;
    };

    const sideCabinet = (x:number,z:number,w=1.08,h=1.65,d=.62) => {
      const facing = x >= 0 ? -1 : 1;
      const frontX = x + facing * (d / 2 + .035);
      box(d,h,w,x,h/2+.18,z,body);
      box(d+.035,.055,w+.035,x,h+.19,z,top);
      box(.045,h-.14,w-.09,frontX,.94,z,body);
      box(.018,h-.25,w-.2,x + facing * (d / 2 + .065),.94,z,body);
      box(.035,.035,w*.58,x + facing * (d / 2 + .085),.86,z,brass);
      box(.035,.035,w*.9,x + facing * (d / 2 + .08),.21,z,dark);
    };

    const wallCabinet = (x:number,z:number,w=1.08) => {
      box(w,1.15,.48,x,3.42,z,body);
      box(w+.03,.045,.52,x,4.02,z,top);
      box(w-.08,.98,.04,x,3.42,z-.27,body);
      box(w*.58,.03,.035,x,3.42,z-.31,brass);
    };

    const sideWallCabinet = (x:number,z:number,w=1.08) => {
      const facing = x >= 0 ? -1 : 1;
      box(.48,1.15,w,x,3.42,z,body);
      box(.52,.045,w+.03,x,4.02,z,top);
      box(.04,.98,w-.08,x + facing * .27,3.42,z,body);
      box(.035,.03,w*.58,x + facing * .31,3.42,z,brass);
    };

    const addRun = (start:number, count:number, z:number, step=1.08) => {
      for(let i=0;i<count;i++) { cabinet(start+i*step,z); wallCabinet(start+i*step,z+.04); }
      box(count*step-.03,.12,.78,start+(count-1)*step/2,.15,z,dark);
    };

    const addCountertop = (w:number,d:number,x:number,z:number,mat=top) => box(w,.13,d,x,1.93,z,mat);

    const burner = (x:number,z:number) => {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(.14,.025,12,32), dark);
      ring.rotation.x=Math.PI/2;
      ring.position.set(x,2.02,z);
      ring.castShadow=true;
      group.add(ring);
      const cap = new THREE.Mesh(new THREE.CylinderGeometry(.035,.035,.018,16), brass);
      cap.position.set(x,2.04,z);
      group.add(cap);
    };

    const addHob = (x:number,z:number) => {
      box(.92,.035,.58,x,2.01,z,dark);
      burner(x-.23,z-.15); burner(x+.23,z-.15); burner(x-.23,z+.15); burner(x+.23,z+.15);
    };

    const addChimney = (x:number,z:number) => {
      box(1.02,.12,.58,x,3.56,z,dark);
      box(.22,1.15,.22,x,4.12,z,brass);
      box(.92,.06,.52,x,3.62,z,body);
    };

    const addSinkAndFaucet = (x:number,z:number) => {
      box(.78,.035,.5,x,2.01,z,dark);
      const faucetStem = new THREE.Mesh(new THREE.CylinderGeometry(.035,.035,.48,16), brass);
      faucetStem.position.set(x+.22,2.25,z-.12);
      group.add(faucetStem);
      const faucetArc = new THREE.Mesh(new THREE.TorusGeometry(.2,.035,12,24,Math.PI), brass);
      faucetArc.rotation.z=Math.PI/2;
      faucetArc.position.set(x+.22,2.43,z-.12);
      group.add(faucetArc);
    };

    const addLRunAppliances = (xStart=-2.2,z=-1.2,count=4) => {
      addRun(xStart,count,z);
      addCountertop(count*1.08-.05,.82,xStart+(count-1)*.54,z);
      addHob(xStart+1.08,z);
      addChimney(xStart+1.08,z+.04);
      addSinkAndFaucet(xStart+3.0,z);
    };

    if(layout === 'island') {
      addLRunAppliances(-2.35,-1.65,5);
      for(let i=-1;i<=1;i++) cabinet(i*1.08,1.08,.98,1.42,.72);
      addCountertop(3.42,1.0,0,1.08); addHob(0,1.08); addChimney(0,1.08);
    }
    if(layout === 'l') {
      addLRunAppliances(-2.2,-1.25,4);
      for(let i=0;i<3;i++) sideCabinet(2.1,-.2+i*1.08,1.08,1.65,.62);
      for(let i=0;i<3;i++) sideWallCabinet(2.1,-.2+i*1.08+.04,1.08);
      addCountertop(.82,3.28,2.1,.88); addSinkAndFaucet(2.1,.25);
    }
    if(layout === 'u') {
      addRun(-2.2,4,-1.3); addCountertop(4.25,.82,-.6,-1.3); addHob(-.6,-1.3); addChimney(-.6,-1.3);
      for(let i=0;i<3;i++) { 
        sideCabinet(2.1,-.2+i*1.08,1.08,1.65,.62); 
        sideCabinet(-2.1,-.2+i*1.08,1.08,1.65,.62); 
        sideWallCabinet(2.1,-.2+i*1.08+.04,1.08); 
        sideWallCabinet(-2.1,-.2+i*1.08+.04,1.08); 
      }
      addCountertop(.82,3.28,2.1,.88); addCountertop(.82,3.28,-2.1,.88); addSinkAndFaucet(2.1,.25);
    }
    if(layout === 'peninsula') {
      addLRunAppliances(-2.2,-1.3,4);
      for(let i=0;i<3;i++) sideCabinet(1.9,.0+i*1.08,1.08,1.65,.7);
      addCountertop(2.9,.88,.85,.0); addSinkAndFaucet(.2,0);
    }

    const floor = new THREE.Mesh(new THREE.PlaneGeometry(22,22), new THREE.MeshStandardMaterial({ color: 0x29251f, roughness: .72 }));
    floor.rotation.x = -Math.PI/2;
    floor.receiveShadow = true;
    scene.add(floor);

    const back = new THREE.Mesh(new THREE.PlaneGeometry(22,10), new THREE.MeshStandardMaterial({ color: 0x22211e, roughness: .9 }));
    back.position.set(0,5,-2.15);
    scene.add(back);

    const grid = new THREE.GridHelper(22, 22, 0x6b5940, 0x322c25);
    grid.position.y = .012;
    (grid.material as THREE.Material).transparent = true;
    (grid.material as THREE.Material).opacity = .25;
    scene.add(grid);

    scene.add(new THREE.HemisphereLight(0xf4e6c7, 0x17120e, 2.2));
    const key = new THREE.DirectionalLight(0xffe7bb, 4.2);
    key.position.set(-4,8,5);
    key.castShadow = true;
    key.shadow.mapSize.set(1024,1024);
    scene.add(key);

    const rim = new THREE.PointLight(0xc8a96a, 18, 8);
    rim.position.set(4,3,3);
    scene.add(rim);

    let frame = 0;
    const resize = () => {
      if (!mount) return;
      camera.aspect = mount.clientWidth / mount.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(mount.clientWidth,mount.clientHeight);
    };
    window.addEventListener('resize', resize);

    const animate = () => {
      frame = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene,camera);
    };
    animate();

    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener('resize', resize);
      scene.traverse((obj) => {
        if (obj instanceof THREE.Mesh) {
          obj.geometry?.dispose();
          if (Array.isArray(obj.material)) {
            obj.material.forEach((m) => m.dispose());
          } else if (obj.material) {
            obj.material.dispose();
          }
        }
      });
      controls.dispose();
      renderer.dispose();
      if (renderer.domElement && mount.contains(renderer.domElement)) {
        mount.removeChild(renderer.domElement);
      }
    };
  }, [layout, finish, countertop]);

  return (
    <div className="configurator-shell" id="configurator">
      <div className="configurator-canvas" ref={mountRef}>
        <div className="configurator-hint"><Compass size={15} /> DRAG TO ROTATE · SCROLL TO ZOOM</div>
        <div className="configurator-live"><span /> LIVE 3D PREVIEW</div>
      </div>
      <aside className="configurator-panel">
        <div className="configurator-panel-label">MAKE IT YOURS / LIVE PREVIEW</div>
        <h2>See your<br /><em>kitchen come alive.</em></h2>
        <p>Choose the layout, cabinet finish and countertop that feel right for your home. When you are ready, our designers will tailor every detail to your room.</p>
        <div className="configurator-control">
          <label><span>01</span> KITCHEN SHAPE</label>
          <div className="configurator-options configurator-options-four">
            {[['island','Island'],['l','L-Shape'],['u','U-Shape'],['peninsula','Peninsula']].map(([id,label]) => (
              <button className={layout===id?'active':''} onClick={() => setLayout(id)} key={id}>
                <span className={`layout-icon layout-${id}`} />{label}
              </button>
            ))}
          </div>
        </div>
        <div className="configurator-control">
          <label><span>02</span> CABINET FINISH</label>
          <div className="finish-options">
            {[['walnut','Walnut'],['ivory','Ivory'],['sage','Sage'],['glossy','Glossy']].map(([id,label]) => (
              <button className={finish===id?'active':''} onClick={() => setFinish(id)} key={id}>
                <i className={`finish-dot finish-${id}`} />{label}
              </button>
            ))}
          </div>
        </div>
        <div className="configurator-control">
          <label><span>03</span> COUNTERTOP MATERIAL</label>
          <div className="finish-options">
            {[['marble','Marble'],['quartz','Quartz'],['stone','Dark Stone']].map(([id,label]) => (
              <button className={countertop===id?'active':''} onClick={() => setCountertop(id)} key={id}>
                <i className={`finish-dot finish-${id}`} />{label}
              </button>
            ))}
          </div>
        </div>
        <a href="#contact" className="showroom-button primary configurator-cta">Talk to a designer <ArrowUpRight size={17} /></a>
        <small className="configurator-note"><Zap size={13} /> Your choices are a starting point. We tailor them to your room, budget and way of living.</small>
      </aside>
    </div>
  );
}

function PublicSite() {
  const isKitchenPage = typeof window !== 'undefined' && window.location.pathname.includes('modular-kitchen');
  
  // Grand Diwali Festive Offer configuration: 10% OFF
  const OFFER_CODE = 'DIWALI10%OFF';
  // Timing: 25 Oct 12:00 AM IST to 09 Nov 11:59 PM IST (Delhi Time Zone)
  const OFFER_START = new Date('2026-10-25T00:00:00+05:30').getTime();
  const OFFER_END = new Date('2026-11-09T23:59:59+05:30').getTime();

  const [menuOpen, setMenuOpen] = useState(false);
  const [sent, setSent] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [now, setNow] = useState(() => Date.now());
  const [offerOpen, setOfferOpen] = useState(false);
  const [selectedPackage, setSelectedPackage] = useState<string | null>(null);
  const [selectedCollection, setSelectedCollection] = useState<string | null>(null);
  const [selectedMaterial, setSelectedMaterial] = useState<string | null>(null);
  const [selectedLayout, setSelectedLayout] = useState<string | null>(null);
  const [openStep, setOpenStep] = useState<string | null>(null);

  // Form state supporting both Package and Layout independent selections
  const [form, setForm] = useState({
    name: '',
    phone: '',
    service: 'Modular Kitchen',
    kitchenPackage: '',
    kitchenLayout: '',
    offerCode: '',
    notes: ''
  });

  // Handle cross-page and in-page anchor scrolling smoothly (accounting for sticky navigation)
  useEffect(() => {
    const handleHash = () => {
      const hash = window.location.hash;
      if (!hash) return;
      const targetId = hash.replace('#', '');
      
      // Look for standard ID or alternative alias
      const elem = document.getElementById(targetId) || 
                   (targetId === 'kitchen-designs' ? document.getElementById('designs') : null) ||
                   (targetId === 'designs' ? document.getElementById('kitchen-designs') : null);
      
      if (elem) {
        setTimeout(() => {
          const navOffset = 90;
          const elemPosition = elem.getBoundingClientRect().top + window.pageYOffset;
          window.scrollTo({
            top: elemPosition - navOffset,
            behavior: 'smooth'
          });
        }, 120);
      }
    };

    handleHash();
    window.addEventListener('hashchange', handleHash);
    return () => window.removeEventListener('hashchange', handleHash);
  }, []);

  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setSubmitError('');
    try {
      const payloadBody = {
        name: form.name,
        phone: form.phone,
        service: form.service || 'Modular Kitchen',
        kitchen_package: form.kitchenPackage || null,
        kitchen_layout: form.kitchenLayout || null,
        kitchenPackage: form.kitchenPackage || null,
        kitchenLayout: form.kitchenLayout || null,
        offer_code: form.offerCode || null,
        notes: [
          form.kitchenPackage ? `Kitchen Package: ${form.kitchenPackage}` : '',
          form.kitchenLayout ? `Kitchen Layout: ${form.kitchenLayout}` : '',
          form.offerCode ? `Offer code: ${form.offerCode}` : '',
          form.notes ? form.notes : ''
        ].filter(Boolean).join('\n'),
        source: isKitchenPage ? 'modular-kitchen-page' : '3d-public-website'
      };

      const response = await fetch('/api/inquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payloadBody)
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok || !payload.success) {
        throw new Error(payload.error || payload.message || 'We could not save your enquiry. Please try again.');
      }
      setSent(true);
    } catch (error) {
      setSubmitError(error instanceof Error ? error.message : 'We could not save your enquiry. Please try again.');
    }
  };

  const update = (key: string, value: string) => setForm((current) => ({ ...current, [key]: value }));

  const isUpcoming = now < OFFER_START;
  const offerActive = now >= OFFER_START && now <= OFFER_END;
  const isExpired = now > OFFER_END;
  const remaining = Math.max(0, (offerActive ? OFFER_END : (isUpcoming ? OFFER_START : 0)) - now);
  const countdown = {
    days: Math.floor(remaining / 86400000),
    hours: Math.floor((remaining / 3600000) % 24),
    mins: Math.floor((remaining / 60000) % 60),
    secs: Math.floor((remaining / 1000) % 60)
  };

  const openOfferCta = () => {
    if (!isExpired) setOfferOpen(true);
  };

  const applyOffer = () => {
    setForm((current) => ({ ...current, offerCode: OFFER_CODE }));
    setOfferOpen(false);
    document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' });
  };

  const heading = isKitchenPage 
    ? 'Your dream kitchen,\ndesigned around you.' 
    : 'Beautiful spaces,\nmade for everyday life.';

  const packages = [
    { 
      name: 'Essential Luxury', 
      finish: 'Laminate / HPL', 
      detail: 'Smart, refined and made for everyday living with durable 100% waterproof BWP ply.', 
      image: 'essential-01.jpg', 
      tone: 'laminate', 
      gallery: ['essential-01.jpg','essential-02.jpg','essential-03.jpg','essential-04.jpg','essential-05.jpg'] 
    },
    { 
      name: 'Premium Royale', 
      finish: 'Acrylic finish', 
      detail: 'High-gloss surfaces with seamless laser-edge banding and contemporary presence.', 
      image: 'royale-01.jpg', 
      tone: 'acrylic', 
      gallery: ['royale-01.jpg','royale-02.jpg','royale-03.jpg','royale-04.jpg','royale-05.jpg'] 
    },
    { 
      name: 'Bespoke Imperial', 
      finish: 'PU finish', 
      detail: 'Our most expressive artisanal finish with seamless satin edges for signature luxury.', 
      image: 'imperial-01.jpg', 
      tone: 'pu', 
      gallery: ['imperial-01.jpg','imperial-02.jpg','imperial-03.jpg','imperial-04.jpg','imperial-05.jpg'] 
    },
  ];

  const designs = [
    ['Straight Kitchen', 'A refined single-wall composition for compact living.', 'galleries/straight-acrylic-01.jpg', 'straight'],
    ['Parallel / Galley', 'Two balanced runs with an effortless central flow.', 'galleries/galley-acrylic-01.jpg', 'galley'],
    ['L-Shape Kitchen', 'Effortless flow for open, everyday living.', 'galleries/l-shape-acrylic-01.jpg', 'l-shape'],
    ['U-Shape Kitchen', 'More storage, more worktop, more room to create.', 'galleries/u-shape-acrylic-01.jpg', 'u-shape'],
    ['Island Kitchen', 'A social centrepiece for the heart of your home.', 'galleries/island-acrylic-01.jpg', 'island'],
    ['Peninsula Kitchen', 'A connected layout with a little more definition.', 'galleries/peninsula-acrylic-01.jpg', 'peninsula'],
  ];

  const gallerySets: Record<string, {file:string; finish:string}[]> = {
    'l-shape': [{file:'l-shape-laminate-01.jpg',finish:'Laminate'}, {file:'l-shape-acrylic-01.jpg',finish:'Acrylic'}, {file:'l-shape-acrylic-02.jpg',finish:'Acrylic'}, {file:'l-shape-pu-01.jpg',finish:'PU'}, {file:'l-shape-pu-02.jpg',finish:'PU'}],
    'u-shape': [{file:'u-shape-laminate-01.jpg',finish:'Laminate'}, {file:'u-shape-acrylic-01.jpg',finish:'Acrylic'}, {file:'u-shape-acrylic-02.jpg',finish:'Acrylic'}, {file:'u-shape-pu-01.jpg',finish:'PU'}, {file:'u-shape-pu-02.jpg',finish:'PU'}],
    'galley': [{file:'galley-laminate-01.jpg',finish:'Laminate'}, {file:'galley-acrylic-01.jpg',finish:'Acrylic'}, {file:'galley-acrylic-02.jpg',finish:'Acrylic'}, {file:'galley-pu-01.jpg',finish:'PU'}, {file:'galley-pu-02.jpg',finish:'PU'}],
    'island': [{file:'island-laminate-01.jpg',finish:'Laminate'}, {file:'island-acrylic-01.jpg',finish:'Acrylic'}, {file:'island-acrylic-02.jpg',finish:'Acrylic'}, {file:'island-pu-01.jpg',finish:'PU'}, {file:'island-pu-02.jpg',finish:'PU'}],
    'peninsula': [{file:'peninsula-laminate-01.jpg',finish:'Laminate'}, {file:'peninsula-acrylic-01.jpg',finish:'Acrylic'}, {file:'peninsula-acrylic-02.jpg',finish:'Acrylic'}, {file:'peninsula-pu-01.jpg',finish:'PU'}, {file:'peninsula-pu-02.jpg',finish:'PU'}],
    'straight': [{file:'straight-laminate-01.jpg',finish:'Laminate'}, {file:'straight-acrylic-01.jpg',finish:'Acrylic'}, {file:'straight-acrylic-02.jpg',finish:'Acrylic'}, {file:'straight-pu-01.jpg',finish:'PU'}, {file:'straight-pu-02.jpg',finish:'PU'}],
  };

  return (
    <div className="showroom-site">
      {/* Grand Diwali 10% Off Top Banner */}
      <button 
        className={`navratri-top-offer ${!isExpired ? '' : 'is-expired'}`} 
        onClick={openOfferCta} 
        disabled={isExpired} 
        aria-label="Open Diwali Festive offer"
      >
        <span className="navratri-top-copy">
          <Sparkles size={13} /> 🪔 SHUBH DEEPAWALI · DIWALI OFFER <b>10% OFF</b>
        </span>
        <span className="navratri-top-countdown">
          {!isExpired 
            ? `${String(countdown.days).padStart(2, '0')}D : ${String(countdown.hours).padStart(2, '0')}H : ${String(countdown.mins).padStart(2, '0')}M : ${String(countdown.secs).padStart(2, '0')}S` 
            : 'OFFER EXPIRED'}
        </span>
        <span className="navratri-top-note">
          {isUpcoming 
            ? 'COUNTDOWN TO 25 OCT 12:00 AM · VALID TILL 09 NOV IST' 
            : 'VALID TILL 09 NOV · 11:59 PM IST (DELHI TIME)'}
        </span>
      </button>

      {/* Topline bar */}
      <div className="showroom-topline">
        <span><Sparkles size={13} /> DEHRADUN · UTTARAKHAND</span>
        <span>PREMIUM MODULAR KITCHENS. <b>5 YEAR MANUFACTURING WARRANTY.</b></span>
        <a href="tel:+919068377690"><Phone size={13} /> +91 90683 77690</a>
      </div>

      {/* Main Navigation */}
      <header className="showroom-nav">
        <a href="/" className="showroom-logo">
          <img src={`${ASSET}ishaanya-brand-logo.png`} alt="Ishaanya Interiors" />
          <span>INTERIORS / 01</span>
        </a>
        <nav className={menuOpen ? 'is-open' : ''}>
          {/* Navigation links configured per User Request 1 */}
          <a href="/modular-kitchen-dehradun" onClick={() => setMenuOpen(false)}>Modular Kitchens</a>
          <a href={isKitchenPage ? '#designs' : '/modular-kitchen-dehradun#kitchen-designs'} onClick={() => setMenuOpen(false)}>Kitchen Design</a>
          <a href={isKitchenPage ? '#contact' : '/modular-kitchen-dehradun#contact'} onClick={() => setMenuOpen(false)}>Plan My Kitchen</a>
          <a href={isKitchenPage ? '#designs' : '/modular-kitchen-dehradun#kitchen-designs'} onClick={() => setMenuOpen(false)}>See Our Kitchens</a>
          <a href="#offers" onClick={() => setMenuOpen(false)}>Offers</a>
          <a href="#contact" onClick={() => setMenuOpen(false)}>Contact</a>
        </nav>
        <a className="showroom-nav-cta" href={isKitchenPage ? '#contact' : '/modular-kitchen-dehradun#contact'}>
          Book Free Consultation &amp; Site Visit <ArrowUpRight size={16} />
        </a>
        <button className="showroom-menu" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle menu">
          {menuOpen ? <X /> : <Menu />}
        </button>
      </header>

      <main id="top">
        {/* Hero Section */}
        <section className={`showroom-hero showroom-photo-hero-page ${isKitchenPage ? 'showroom-kitchen-hero' : 'showroom-home-hero'}`}>
          <div className="showroom-hero-copy">
            <div className="showroom-hero-brand">
              <img src={`${ASSET}ishaanya-brand-logo.png`} alt="Ishaanya Interiors" />
              <span>BESPOKE KITCHENS &amp; INTERIORS / DEHRADUN</span>
            </div>
            <div className="showroom-kicker"><span /> DESIGNED AROUND YOUR LIFE</div>
            <h1>{heading.split('\n').map((line, i) => <React.Fragment key={line}>{i > 0 && <br />}<em>{line}</em></React.Fragment>)}</h1>
            <p>A beautiful, practical kitchen made around your family, your space and the way you live. Explore your possibilities, then let our designers make them real.</p>
            <div className="showroom-actions">
              <a className="showroom-button primary" href={isKitchenPage ? "#contact" : "/modular-kitchen-dehradun#contact"}>
                Plan my kitchen <ArrowUpRight size={17} />
              </a>
              <a className="showroom-button ghost" href={isKitchenPage ? "#designs" : "/modular-kitchen-dehradun#kitchen-designs"}>
                See our kitchens <ChevronRight size={17} />
              </a>
            </div>
            <div className="showroom-micro-proof">
              <span><Check size={14} /> 70+ happy homes</span>
              <span><Check size={14} /> 2 years of craft</span>
              <span><Check size={14} /> 15-day delivery</span>
            </div>
          </div>
          <KitchenStage kitchenPage={isKitchenPage} />
          <div className="showroom-scroll">SCROLL TO EXPLORE <span /></div>
        </section>

        {/* Grand Diwali 10% Off Section with Mata Lakshmi background */}
        <section id="offers" className={`navratri-offer-section ${!isExpired ? '' : 'is-expired'}`}>
          <div className="navratri-offer-art" aria-hidden="true" />
          <div className="navratri-offer-content">
            <div className="showroom-section-tag">/ OFFERS &amp; DISCOUNTS <span>SHUBH DEEPAWALI · DEHRADUN</span></div>
            <div className="navratri-offer-grid">
              <div>
                <span className="navratri-eyebrow">🪔 SHUBH DEEPAWALI SPECIAL PRIVILEGE</span>
                <h2>Grand Diwali<br /><em>10% off.</em></h2>
                <p>Bring auspicious light, prosperity, and timeless elegance into your home. Enjoy an exclusive 10% Diwali festive privilege on bespoke modular kitchens crafted with 100% waterproof BWP ply and German hardware.</p>
                <div className="navratri-date">Valid from 25 October, 12:00 AM to 09 November, 11:59 PM IST (Delhi Time) · Benefit Code: <b>{OFFER_CODE}</b></div>
              </div>
              <div className="navratri-countdown-card">
                <span className="navratri-card-label">
                  {isUpcoming ? 'OFFER GOES LIVE IN (25 OCT · 12:00 AM)' : (offerActive ? 'FESTIVE PRIVILEGE WINDOW CLOSES IN' : 'THIS FESTIVE OFFER HAS ENDED')}
                </span>
                {!isExpired ? (
                  <div className="navratri-countdown-grid">
                    {[['days','DAYS'],['hours','HOURS'],['mins','MINS'],['secs','SECS']].map(([key,label]) => (
                      <div key={key}>
                        <strong>{String(countdown[key as keyof typeof countdown]).padStart(2, '0')}</strong>
                        <span>{label}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="navratri-expired-large">OFFER<br /><em>EXPIRED</em></div>
                )}
                <button className="navratri-claim-button" onClick={openOfferCta} disabled={isExpired}>
                  {!isExpired ? <>Claim {OFFER_CODE} <ArrowUpRight size={17} /></> : 'Offer expired'}
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* 3D Kitchen Configurator (shown on modular kitchen page) */}
        {isKitchenPage && (
          <section className="configurator-section">
            <div className="showroom-section-tag">/ 001 — MAKE IT YOURS <span>EXPLORE YOUR KITCHEN OPTIONS</span></div>
            <div className="configurator-heading">
              <h2>Your kitchen.<br /><em>Your way.</em></h2>
              <p>Move around the room, try a shape and pick a finish you love. Then our team will turn your direction into a measured, beautifully finished kitchen.</p>
            </div>
            <KitchenConfigurator />
          </section>
        )}

        {/* Packages section (shown on modular kitchen page) */}
        {isKitchenPage && (
          <>
            <section className="kitchen-packages" id="packages">
              <div className="showroom-section-tag">/ 002 — THE ISHAANYA COLLECTION <span>THREE WAYS TO MAKE IT YOURS</span></div>
              <div className="kitchen-page-heading">
                <h2>Find the finish<br /><em>that feels like you.</em></h2>
                <p>Each package is a complete visual world. Explore five kitchen references, then book the finish that feels right for your home.</p>
              </div>
              <div className="package-grid">
                {packages.map((item) => (
                  <article className={`package-card package-${item.tone}`} key={item.name}>
                    <div className="package-image" onClick={() => setSelectedCollection(item.name)}>
                      <img src={`${ASSET}${item.image}`} alt={`${item.name} modular kitchen`} />
                      <span className="package-index">0{packages.indexOf(item)+1}</span>
                      <span className="package-arrow"><ArrowUpRight size={20} /></span>
                    </div>
                    <div className="package-copy">
                      <span className="package-finish">{item.finish}</span>
                      <h3>{item.name}</h3>
                      <p>{item.detail}</p>
                      <div className="package-actions">
                        <button onClick={() => setSelectedCollection(item.name)}>View collection <ArrowUpRight size={15} /></button>
                        <button className="package-book" onClick={() => {
                          setSelectedPackage(item.name);
                          setForm(curr => ({ ...curr, kitchenPackage: item.name }));
                        }}>Book this package <ArrowUpRight size={15} /></button>
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            </section>

            {/* Designs & Layouts section */}
            <section className="kitchen-designs" id="designs">
              <span id="kitchen-designs" style={{ position: 'relative', top: '-100px', display: 'block', visibility: 'hidden' }} />
              <div className="showroom-section-tag">/ 003 — KITCHEN DESIGNS <span>SHAPED AROUND YOUR ROOM</span></div>
              <div className="kitchen-page-heading compact">
                <h2>Every room has<br /><em>its own rhythm.</em></h2>
                <p>Choose a starting point. We will refine the proportions, storage and details around the way you live.</p>
              </div>
              <div className="designs-strip">
                {designs.map(([name, detail, image, slug], index) => (
                  <button key={name} className="design-card design-card-button" onClick={() => setSelectedLayout(slug)} aria-label={`Open ${name} gallery`}>
                    <img src={`${ASSET}${image}`} alt={name} />
                    <div className="design-overlay">
                      <span>0{index+1} / DESIGN TYPE</span>
                      <h3>{name}</h3>
                      <p>{detail}</p>
                      <b>View 5 luxury designs <ArrowUpRight size={15} /></b>
                    </div>
                  </button>
                ))}
              </div>
            </section>
          </>
        )}

        {/* Showroom Intro */}
        <section className="showroom-intro">
          <div className="showroom-section-tag">/ 001 — THE POINT OF VIEW</div>
          <div className="showroom-intro-grid">
            <h2>Good design is felt<br /><em>before it is explained.</em></h2>
            <div>
              <p>We compose kitchens and interiors around light, movement and the way you live. Every line has a job. Every material earns its place.</p>
              <a href="#contact" className="showroom-text-link">Talk to the studio <ArrowUpRight size={16} /></a>
            </div>
          </div>
          <div className="showroom-stat-row">
            <div><strong>100%</strong><span>WATERPROOF BWP PLY</span></div>
            <div><strong>3D</strong><span>WALKTHROUGH BEFORE BUILD</span></div>
            <div><strong>01</strong><span>DEDICATED SITE ENGINEER</span></div>
          </div>
        </section>

        {/* Selected Spaces */}
        <section id="work" className="showroom-work">
          <div className="showroom-section-tag">/ 002 — SELECTED SPACES <span>DRAG YOUR EYE ACROSS THE ROOM</span></div>
          <div className="showroom-work-head">
            <h2>Made to be <em>lived in.</em></h2>
            <p>Not catalogue kitchens. Thoughtful, tactile spaces that make the everyday feel considered.</p>
          </div>
          <div className="showroom-gallery">
            <article className="gallery-feature">
              <a className="gallery-feature-link" href="/modular-kitchen-dehradun" aria-label="Explore modular kitchens">
                <img src={`${ASSET}essential-03.jpg`} alt="Essential Luxury laminate modular kitchen" />
                <div>
                  <span>01 / MODULAR KITCHEN</span>
                  <h3>Essential Luxury. Calm, considered.</h3>
                  <span className="gallery-cta">Explore modular kitchens <ArrowUpRight size={16} /></span>
                </div>
              </a>
            </article>
            <article className="gallery-interactive">
              <a href="/modular-kitchen-dehradun#kitchen-designs" aria-label="Explore Imperial kitchen designs">
                <img src={`${ASSET}bespoke_imperial_kitchen.jpg`} alt="Bespoke imperial kitchen" />
                <div>
                  <span>02 / IMPERIAL SERIES</span>
                  <h3>Bold lines, soft light.</h3>
                  <b>Explore designs <ArrowUpRight size={15} /></b>
                </div>
              </a>
            </article>
            <article className="gallery-interactive">
              <a href="/modular-kitchen-dehradun#kitchen-designs" aria-label="Explore kitchen spaces">
                <img src={`${ASSET}luxury_tv_unit.jpg`} alt="Luxury kitchen living space" />
                <div>
                  <span>03 / LIVING SPACES</span>
                  <h3>Everything in its place.</h3>
                  <b>Explore spaces <ArrowUpRight size={15} /></b>
                </div>
              </a>
            </article>
          </div>
        </section>

        {/* Material Library */}
        <section id="materials" className="showroom-materials">
          <div className="showroom-section-tag">/ 003 — MATERIAL LIBRARY</div>
          <div className="showroom-material-head">
            <h2>Touch the <em>difference.</em></h2>
            <p>Surfaces selected for how they age, feel and live—not just how they photograph.</p>
          </div>
          <div className="showroom-material-grid">
            <button className="material-card material-card-button wood" onClick={() => setSelectedMaterial('veneer')}>
              <img className="material-photo" src={`${ASSET}natural-veneer-kitchen.webp`} alt="Real natural wood veneer modular kitchen" />
              <span>01 / GRAIN <ArrowUpRight size={15} /></span>
              <h3>Natural veneer</h3>
              <p>Warmth, depth and a touch of the organic.</p>
              <b className="material-explore">Tap to explore material</b>
            </button>
            <button className="material-card material-card-button stone" onClick={() => setSelectedMaterial('stone')}>
              <img className="material-photo" src={`${ASSET}quartz-marble-countertop.jpg`} alt="Real quartz marble kitchen countertop and backsplash" />
              <span>02 / SURFACE <ArrowUpRight size={15} /></span>
              <h3>Quartz &amp; marble</h3>
              <p>Real stone character, veining and a resilient worktop finish.</p>
              <b className="material-explore">Tap to explore material</b>
            </button>
            <button className="material-card material-card-button brass" onClick={() => setSelectedMaterial('hardware')}>
              <img className="material-photo material-hardware-photo" src={`${ASSET}blum-aventos-official.jpg`} alt="Official Blum AVENTOS lift system" />
              <img className="hardware-detail-photo" src={`${ASSET}hettich-innotech-official.jpg`} alt="Official Hettich InnoTech drawer system" />
              <span>03 / DETAIL <ArrowUpRight size={15} /></span>
              <h3>Blum &amp; Hettich hardware</h3>
              <p>Original lift systems, hinges and InnoTech drawer channels used in modular kitchens.</p>
              <b className="material-explore">Tap to explore hardware</b>
            </button>
          </div>
        </section>

        {/* Process */}
        <section id="process" className="showroom-process">
          <div className="showroom-section-tag">/ 004 — HOW IT COMES TO LIFE</div>
          <div className="showroom-process-grid">
            <h2>From first line<br />to <em>last detail.</em></h2>
            <div className="showroom-steps">
              {[
                ['01','Listen','We understand how you move, cook and live.'],
                ['02','Visualise','You walk through your kitchen in 3D before anything is made.'],
                ['03','Build','Precision factory production, on-site execution, zero guesswork.'],
                ['04','Hand over','A finished space, cleaned, checked and ready for your life.']
              ].map(([num,title,text]) => (
                <button 
                  className={`showroom-step ${openStep === num ? 'is-open' : ''}`} 
                  onClick={() => setOpenStep(openStep === num ? null : num)} 
                  key={num}
                >
                  <span>{num}</span>
                  <div>
                    <h3>{title}</h3>
                    <p>{text}</p>
                  </div>
                  <ArrowUpRight size={18} />
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* Contact & Consultation Form (Updated per User Request 2) */}
        <section id="contact" className="showroom-contact">
          <div className="contact-orb" />
          <div className="showroom-section-tag">/ 005 — YOUR NEXT ROOM</div>
          <div className="showroom-contact-grid">
            <div>
              <h2>Let’s make<br /><em>space for life.</em></h2>
              <p>Tell us what you are imagining. We’ll bring the tape measure, the material samples and a clear next step.</p>
              <div className="contact-direct">
                <a href="tel:+919068377690"><Phone size={17} /> +91 90683 77690</a>
                <a href="https://wa.me/919068377690" target="_blank" rel="noreferrer"><MessageCircle size={17} /> WhatsApp the studio</a>
              </div>
              <div className="contact-socials" aria-label="Social links">
                <a href="https://wa.me/919068377690" target="_blank" rel="noreferrer" aria-label="Chat on WhatsApp"><MessageCircle size={16} /><span>WhatsApp</span></a>
                <a href="https://www.instagram.com/ishaanya_interiors?vrfl=MTNrbnEzcXhpZTdxMA==" target="_blank" rel="noreferrer" aria-label="Visit Instagram"><Instagram size={16} /><span>Instagram</span></a>
                <a href="https://maps.app.goo.gl/bYQPuhuYKddekYTdA?g_st=ac" target="_blank" rel="noreferrer" aria-label="View Google Business Profile"><MapPin size={16} /><span>View on Google</span></a>
              </div>
            </div>

            <form onSubmit={submit}>
              {sent ? (
                <div className="showroom-success">
                  <Check size={30} />
                  <h3>We’ve got it.</h3>
                  <p>The studio will call you shortly to set up your free design conversation.</p>
                  <a href="#top">Back to the top <ArrowUpRight size={15} /></a>
                </div>
              ) : (
                <>
                  <label>
                    Your name
                    <input 
                      required 
                      value={form.name} 
                      onChange={e => update('name', e.target.value)} 
                      placeholder="Ankit Sharma" 
                    />
                  </label>
                  
                  <label>
                    Phone number
                    <input 
                      required 
                      value={form.phone} 
                      onChange={e => update('phone', e.target.value)} 
                      placeholder="+91 98765 43210" 
                    />
                  </label>

                  {/* Field A: Select Your Kitchen Package (single selection, optional) */}
                  <label>
                    Select Your Kitchen Package (optional)
                    <select 
                      value={form.kitchenPackage} 
                      onChange={e => update('kitchenPackage', e.target.value)}
                    >
                      <option value="">Select Kitchen Package (Optional)</option>
                      {KITCHEN_PACKAGES.map(pkg => (
                        <option key={pkg} value={pkg}>{pkg}</option>
                      ))}
                    </select>
                  </label>

                  {/* Field B: Select Your Kitchen Layout / Design (single selection, optional) */}
                  <label>
                    Select Your Kitchen Layout / Design (optional)
                    <select 
                      value={form.kitchenLayout} 
                      onChange={e => update('kitchenLayout', e.target.value)}
                    >
                      <option value="">Select Kitchen Layout / Design (Optional)</option>
                      {KITCHEN_LAYOUTS.map(lyt => (
                        <option key={lyt} value={lyt}>{lyt}</option>
                      ))}
                    </select>
                  </label>

                  <label>
                    Offers &amp; Discounts
                    <input 
                      value={form.offerCode} 
                      onChange={e => update('offerCode', e.target.value)} 
                      placeholder="Claim an offer to autofill the code" 
                      readOnly={Boolean(form.offerCode)} 
                    />
                  </label>

                  <label>
                    Anything we should know?
                    <textarea 
                      value={form.notes} 
                      onChange={e => update('notes', e.target.value)} 
                      placeholder="Tell us about your space, dimensions, or preferences..." 
                    />
                  </label>

                  {submitError && <p className="showroom-form-error" role="alert">{submitError}</p>}
                  
                  <button className="showroom-submit" type="submit">
                    Request a free consultation &amp; site visit <ArrowUpRight size={18} />
                  </button>
                </>
              )}
            </form>
          </div>
        </section>
      </main>

      {/* Grand Diwali 10% Off Modal */}
      {offerOpen && (
        <div className="navratri-modal-backdrop" onClick={() => setOfferOpen(false)}>
          <div className="navratri-modal" onClick={e => e.stopPropagation()}>
            <button className="package-modal-close" onClick={() => setOfferOpen(false)}><X size={20} /></button>
            <span className="navratri-eyebrow">🪔 SHUBH DEEPAWALI PRIVILEGE</span>
            <h2>Unlock your<br /><em>Diwali 10% saving.</em></h2>
            <p>Your Diwali festive privilege code is ready. Use it in the enquiry form and our studio will confirm your 10% festive benefit on your modular kitchen journey.</p>
            <label className="navratri-code-label">
              OFFER CODE
              <input value={OFFER_CODE} readOnly />
            </label>
            <button className="showroom-submit" onClick={applyOffer}>Use this offer <ArrowUpRight size={17} /></button>
          </div>
        </div>
      )}

      {/* Package Collection Modal */}
      {selectedCollection && (
        <div className="package-modal-backdrop" onClick={() => setSelectedCollection(null)}>
          <div className="collection-modal" onClick={e => e.stopPropagation()}>
            <button className="package-modal-close" onClick={() => setSelectedCollection(null)}><X size={20} /></button>
            <span className="package-finish">{packages.find(p => p.name === selectedCollection)?.finish}</span>
            <h2>{selectedCollection}<br /><em>the collection.</em></h2>
            <p>Five directions in one signature finish. Tap any image to see the full visual language of this package.</p>
            <div className="collection-grid">
              {packages.find(p => p.name === selectedCollection)?.gallery.map((image, index) => (
                <img key={image} src={`${ASSET}${image}`} alt={`${selectedCollection} reference ${index+1}`} />
              ))}
            </div>
            <button className="showroom-submit" onClick={() => {
              setSelectedCollection(null);
              setSelectedPackage(selectedCollection);
              setForm(curr => ({ ...curr, kitchenPackage: selectedCollection }));
            }}>
              Book this package <ArrowUpRight size={17} />
            </button>
          </div>
        </div>
      )}

      {/* Layout Designs Gallery Modal */}
      {selectedLayout && (
        <div className="package-modal-backdrop" onClick={() => setSelectedLayout(null)}>
          <div className="layout-gallery-modal" onClick={e => e.stopPropagation()}>
            <button className="package-modal-close" onClick={() => setSelectedLayout(null)}><X size={20} /></button>
            <span className="package-finish">KITCHEN DESIGN GALLERY / 05 REFERENCES</span>
            <h2>{designs.find(d => d[3] === selectedLayout)?.[0]}<br /><em>luxury directions.</em></h2>
            <p>One layout, five considered finish directions: 1 laminate, 2 acrylic and 2 PU kitchens.</p>
            <div className="layout-gallery-grid">
              {(gallerySets[selectedLayout] || []).map((item, i) => (
                <a key={item.file} href={`${ASSET}galleries/${item.file}`} target="_blank" rel="noreferrer">
                  <img src={`${ASSET}galleries/${item.file}`} alt={`${designs.find(d => d[3] === selectedLayout)?.[0]} ${item.finish} luxury kitchen`} />
                  <span>0{i+1} · {item.finish} finish <ArrowUpRight size={14} /></span>
                </a>
              ))}
            </div>
            <a className="showroom-submit" href="#contact" onClick={() => {
              const matchedLayout = designs.find(d => d[3] === selectedLayout)?.[0];
              if (matchedLayout) {
                setForm(curr => ({ ...curr, kitchenLayout: matchedLayout }));
              }
              setSelectedLayout(null);
            }}>
              Discuss this layout <ArrowUpRight size={17} />
            </a>
          </div>
        </div>
      )}

      {/* Material Library Modal */}
      {selectedMaterial && (
        <div className="package-modal-backdrop" onClick={() => setSelectedMaterial(null)}>
          <div className="material-detail-modal" onClick={e => e.stopPropagation()}>
            <button className="package-modal-close" onClick={() => setSelectedMaterial(null)}><X size={20} /></button>
            <span className="package-finish">MATERIAL LIBRARY / 0{selectedMaterial === 'veneer' ? '1' : selectedMaterial === 'stone' ? '2' : '3'}</span>
            <h2>
              {selectedMaterial === 'veneer' ? <>Natural <em>veneer.</em></> : selectedMaterial === 'stone' ? <>Quartz &amp; <em>marble.</em></> : <>Blum &amp; Hettich <em>hardware.</em></>}
            </h2>
            {selectedMaterial === 'hardware' ? (
              <div className="material-detail-grid">
                <img src={`${ASSET}blum-clip-top-official.jpg`} alt="Official Blum CLIP top hinge" />
                <img src={`${ASSET}hettich-innotech-official.jpg`} alt="Official Hettich InnoTech drawer system" />
                <img src={`${ASSET}blum-aventos-official.jpg`} alt="Official Blum AVENTOS lift system" />
              </div>
            ) : selectedMaterial === 'stone' ? (
              <div className="countertop-detail-grid">
                <figure><img src={`${ASSET}quartz-marble-countertop.jpg`} alt="White quartz countertop" /><figcaption>White quartz</figcaption></figure>
                <figure><img src={`${ASSET}marble-kitchen-countertop.png`} alt="White marble countertop" /><figcaption>White marble</figcaption></figure>
                <figure><img src={`${ASSET}full-body-tile-countertop.jpg`} alt="Black full body tile countertop" /><figcaption>Black full-body tile</figcaption></figure>
              </div>
            ) : (
              <img className="material-detail-hero" src={`${ASSET}natural-veneer-kitchen.webp`} alt="Selected kitchen material" />
            )}
            <p>
              {selectedMaterial === 'hardware' 
                ? 'We specify genuine Blum and Hettich systems for smooth movement, soft-close performance and long-term everyday reliability. Final hardware depends on the selected kitchen package and site requirements.' 
                : selectedMaterial === 'veneer' 
                ? 'Natural grain, depth and warmth for kitchens that feel tactile and quietly luxurious. We match the finish to your light, layout and lifestyle.' 
                : 'A resilient worktop language with authentic veining and a refined surface that is made for daily cooking, cleaning and living.'}
            </p>
            <a className="showroom-submit" href="#contact" onClick={() => setSelectedMaterial(null)}>Discuss this material <ArrowUpRight size={17} /></a>
          </div>
        </div>
      )}

      {/* Package Booking Modal */}
      {selectedPackage && (
        <div className="package-modal-backdrop" onClick={() => setSelectedPackage(null)}>
          <div className="package-modal" onClick={e => e.stopPropagation()}>
            <button className="package-modal-close" onClick={() => setSelectedPackage(null)}><X size={20} /></button>
            <span className="package-finish">{packages.find(p => p.name === selectedPackage)?.finish}</span>
            <h2>Let’s create your<br /><em>{selectedPackage} kitchen.</em></h2>
            <p>Tell us a little about your home and our designer will help you explore this package.</p>
            <form onSubmit={(event) => {
              event.preventDefault();
              setSelectedPackage(null);
              document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' });
            }}>
              <input 
                required 
                placeholder="Your name" 
                value={form.name} 
                onChange={e => update('name', e.target.value)} 
              />
              <input 
                required 
                placeholder="Phone number" 
                value={form.phone} 
                onChange={e => update('phone', e.target.value)} 
              />
              <input 
                value={selectedPackage} 
                readOnly 
                aria-label="Selected package" 
              />
              <select 
                value={form.kitchenLayout} 
                onChange={e => update('kitchenLayout', e.target.value)}
              >
                <option value="">Choose your preferred layout (optional)</option>
                {KITCHEN_LAYOUTS.map(l => (
                  <option key={l} value={l}>{l}</option>
                ))}
              </select>
              <button className="showroom-submit" type="submit">Book a design conversation <ArrowUpRight size={17} /></button>
            </form>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="showroom-footer">
        <img src={`${ASSET}ishaanya-brand-logo.png`} alt="Ishaanya Interiors" />
        <span>DESIGNED FOR THE EVERYDAY / DEHRADUN, INDIA</span>
        <div className="footer-socials">
          <a href="https://wa.me/919068377690" target="_blank" rel="noreferrer" aria-label="WhatsApp"><MessageCircle size={14} /></a>
          <a href="https://www.instagram.com/ishaanya_interiors?vrfl=MTNrbnEzcXhpZTdxMA==" target="_blank" rel="noreferrer" aria-label="Instagram"><Instagram size={14} /></a>
          <a href="https://maps.app.goo.gl/bYQPuhuYKddekYTdA?g_st=ac" target="_blank" rel="noreferrer" aria-label="Google Business Profile"><MapPin size={14} /></a>
        </div>
        <div className="flex items-center gap-4">
          <a href="/download" target="_blank" rel="noreferrer" className="text-xs text-[#C8A96A] font-semibold underline tracking-wide">📦 Download Website ZIP</a>
          <a href="#top">Back to top ↑</a>
        </div>
      </footer>
    </div>
  );
}

function boot() {
  const root = document.getElementById('root');
  if (!root) return;
  if (isPublicPath()) {
    createRoot(root).render(<PublicSite />);
  } else {
    document.body.classList.add('owner-shell');
    import('./app-bundle.js');
  }
}

boot();
